# Requisitos — Fábrica de la Fase 02 (Plan / Diseño) de SDD

## Introducción

Este documento define qué debe cumplir la "fábrica" de la Fase 02 (Plan/Diseño) de la
metodología SDD: el conjunto de artefactos (steering ampliado, subagente de fase, skills,
plantillas e instructivos) que permiten generar los documentos de diseño de cualquier
proyecto, de forma consistente con la Fase 01 ya existente.

La fase incorpora, además del catálogo PL-01…PL-11, un **documento marco PL-00**
(clasificación 🟢 auto-generable / 🔵 decisión del arquitecto / 🟣 auto-derivado) y una
**guía de la reunión de diseño PL-G**. El modelo de decisión establece que las decisiones
técnicas (stack, ambiente) **no las infiere ni inventa el agente**: las toma el arquitecto
en una reunión de diseño y el agente las registra como `DEC-D`, aplica las reglas duras de
derivación (el backend fija la arquitectura, el ambiente permitido y el mecanismo de
configuración) y genera los artefactos que sí se derivan de los requerimientos. Entre estos
últimos se incluye **PL-M**, el prompt de diseño visual (para Claude): un artefacto 🟢 que
lista las pantallas (de RQ-05/RQ-07) y arma el prompt para que Claude genere el sistema de
diseño y los mockups, con la paleta de Grupo Salinas por defecto, como apoyo no bloqueante
antes de la reunión.

El "producto" aquí **no es software de aplicación**, sino el conjunto de archivos de
configuración y documentación que conforman la fábrica. Por coherencia metodológica, los
criterios de aceptación se escriben en EARS (en español), igual que exige la propia
metodología.

### Alcance

**Incluido:** ampliar `sdd-convenciones.md`; crear el subagente `sdd-02-plan-diseno`;
crear 15 skills (`pl-00`, `pl-g`, `pl-m`, `pl-01`…`pl-11` + `pl-revision-consistencia`);
crear 14 plantillas (`PL-00`, `PL-G`, `PL-M`, `PL-01`…`PL-11`); crear 3 instructivos (PL-05,
PL-06, PL-11);
actualizar el README con el uso de la Fase 02; reflejar el modelo de decisión 🟢/🔵/🟣 con
la reunión de diseño.

**Excluido:** generar documentos PL de un proyecto real (eso es uso de la fábrica, no su
construcción); modificar las skills/plantillas de la Fase 01 salvo la alineación de la
ruta de salida; construir las fases 03–07; dibujar diagramas draw.io.

### Glosario

- **Fábrica:** el conjunto steering + subagente + skills + plantillas + instructivos que
  produce los documentos de una fase.
- **Documento PL:** un entregable de diseño de la Fase 02 (PL-01…PL-11) para un proyecto.
- **Diagrama maestro:** diagrama draw.io del arquitecto con todos los elementos posibles,
  del cual se copian elementos por proyecto.
- **`DEC-D`:** registro de una decisión de diseño técnica (formato tipo ADR).

## Requisitos

### REQ-01 — Convenciones comunes (steering ampliado)

**Historia de usuario:** Como arquitecto del equipo, quiero que las reglas de la Fase 02
vivan en la misma fuente única que la Fase 01, para no duplicar convenciones ni crear
contradicciones.

#### Criterios de aceptación

1. CUANDO se amplíe `sdd-convenciones.md`, el sistema DEBERÁ agregar una tabla de los
   documentos PL-01…PL-11 que indique, por documento, qué contiene y qué NO contiene
   (con el destino de lo que no le corresponde), con el mismo formato que la tabla de la
   Fase 01.
2. CUANDO se amplíe el steering, el sistema DEBERÁ registrar los prefijos `AMB`, `DEC-D`,
   `ENT`, `CAM`, `EP`, `ERR`, `VIS`, `RUT` y `TPR` en la sección de identificadores, cada
   uno con su dueño y un ejemplo.
3. CUANDO se amplíe el steering, el sistema DEBERÁ definir el patrón de nombre de archivo
   `<COD>_PL-NN_<nombre>.md` y la ubicación de salida `documentacion/02-plan-diseno/`.
4. El sistema NO DEBERÁ duplicar las reglas de marcadores, encabezado, estados ni idioma:
   esas secciones se reusan tal cual de la Fase 01.
5. SI un artefacto de la Fase 02 contradice al steering, ENTONCES el steering DEBERÁ
   prevalecer (misma regla de precedencia que la Fase 01).
6. DONDE la Fase 01 referencie la ruta de salida, el sistema DEBERÁ alinearla a
   `documentacion/01-requerimientos/` para que ambas fases usen subcarpeta por fase.

### REQ-02 — Subagente de fase `sdd-02-plan-diseno`

**Historia de usuario:** Como usuario de la metodología, quiero un único subagente que
orqueste la generación de los documentos de diseño, para obtener un diseño trazable y
consistente sin coordinar varias herramientas.

#### Criterios de aceptación

1. El subagente DEBERÁ declararse en `.kiro/agents/sdd-02-plan-diseno.md` con el mismo
   formato de frontmatter que la Fase 01 (`name`, `description`, `tools`, `resources`).
2. El subagente DEBERÁ declarar en `resources` el steering y las 15 skills de la fase
   (`pl-00`, `pl-g`, `pl-m`, `pl-01`…`pl-11` y `pl-revision-consistencia`).
3. El subagente DEBERÁ declarar `tools: ["read", "write"]` (solo texto; no dibuja
   diagramas).
4. CUANDO el usuario invoque el subagente sin haber dado el código de proyecto, el
   sistema DEBERÁ pedirlo y detenerse antes de crear archivos.
5. CUANDO el subagente arranque, el sistema DEBERÁ verificar que RQ-04…RQ-08 del proyecto
   existan, estén en estado `Approved` y sin `PEN` críticos abiertos.
6. SI la precondición de Fase 01 no se cumple, ENTONCES el subagente DEBERÁ detenerse,
   explicar qué documento falta o en qué estado está, y NO crear ningún archivo.
7. El subagente DEBERÁ ofrecer cuatro modos alineados con la reunión de diseño: **Modo A
   pre-reunión** (PL-00 → PL-05 · PL-06 · PL-M borradores → PL-G), **Modo B post-reunión**
   (con la transcripción de la reunión: PL-01 · PL-02 con `DEC-D` → PL-08 · PL-09 derivadas
   → PL-03 · PL-04 → PL-07 · PL-10 · PL-11 + revisión), documento específico y propagación
   de cambios.
8. CUANDO se solicite un documento PL cuyos insumos (PL previos o documentos RQ) no
   existan, el sistema DEBERÁ explicar cuáles faltan y ofrecer generarlos primero.
9. CUANDO el subagente termine una entrega, el sistema DEBERÁ listar los archivos
   creados o actualizados con su versión y estado, y el siguiente paso recomendado.

### REQ-03 — Skills por documento

**Historia de usuario:** Como mantenedor de la fábrica, quiero una skill por documento con
estructura homogénea, para que cada entregable se genere con el mismo rigor y sea fácil de
mantener.

#### Criterios de aceptación

1. El sistema DEBERÁ crear 15 skills en `.kiro/skills/pl-NN-<nombre>/SKILL.md`
   (`pl-00`, `pl-g`, `pl-m`, `pl-01`…`pl-11` y `pl-revision-consistencia`).
2. Cada skill DEBERÁ incluir frontmatter con `name` y `description`, y un cuerpo con las
   secciones Insumos, Procedimiento, "Lo que NO va aquí" y Checklist final.
3. Cada skill DEBERÁ aplicar el steering sin repetir sus reglas.
4. Cada skill DEBERÁ indicar qué IDs de Fase 01 (o de PL previos) debe citar el documento
   que genera, de modo que la trazabilidad hacia atrás quede obligada.
5. Las skills `pl-03` y `pl-04` DEBERÁN producir una guía/checklist de qué elementos o
   flujos dibujar y un campo para el `.drawio` adjunto; NO DEBERÁN generar el diagrama.
6. Las skills `pl-08` y `pl-09` DEBERÁN mantenerse a nivel de capas, módulos y
   responsabilidades, y NO DEBERÁN incluir firmas exactas de métodos.
7. La skill `pl-revision-consistencia` DEBERÁ verificar IDs, cobertura RQ→PL, referencias,
   estados y nombres de archivo, y reportar los hallazgos en el chat (no genera un
   documento de proyecto).

### REQ-04 — Plantillas

**Historia de usuario:** Como persona que valida un documento de diseño, quiero plantillas
limpias con solo la estructura, para llenarlas o revisarlas sin ruido de instrucciones de
IA.

#### Criterios de aceptación

1. El sistema DEBERÁ crear 14 plantillas en `templates/02-plan-diseno/`: `PL-00`
   (clasificación), `PL-G` (guía de reunión), `PL-M` (prompt de diseño visual) y
   `PL-01`…`PL-11`.
2. Cada plantilla DEBERÁ contener solo la estructura del documento, sin instrucciones
   dirigidas a la IA (esas viven en la skill).
3. Cada plantilla DEBERÁ abrir con la tabla de encabezado del steering §6 y cerrar con la
   sección `## Historial de cambios`.
4. Los nombres de archivo DEBERÁN usar los nombres oficiales en minúsculas, sin acentos y
   con guion definidos en el diseño.
5. Las plantillas PL-03 y PL-04 DEBERÁN incluir un campo para referenciar el `.drawio`
   adjunto.

### REQ-05 — Instructivos para personas

**Historia de usuario:** Como integrante del equipo que llena los documentos más
delicados, quiero una guía con ejemplos y errores comunes, para evitar inconsistencias.

#### Criterios de aceptación

1. El sistema DEBERÁ crear instructivos para PL-05, PL-06 y PL-11 en
   `instructivos/PL-NN_<nombre>_instructivo.md`.
2. Cada instructivo DEBERÁ seguir el estilo del instructivo de la Fase 01 (qué es,
   insumos, detalle campo por campo, ejemplo bien llenado, errores comunes, checklist).
3. Cada instructivo DEBERÁ indicar quién genera el borrador (el subagente) y quién lo
   valida (el responsable del documento).
4. El sistema NO DEBERÁ crear instructivos para los demás documentos PL en esta entrega.

### REQ-06 — Trazabilidad y consistencia entre fases

**Historia de usuario:** Como arquitecto, quiero poder comprobar que el diseño cubre todos
los requisitos aprobados y que nada del diseño aparece sin origen, para confiar en que el
plan es completo.

#### Criterios de aceptación

1. CUANDO una skill PL genere un documento, el sistema DEBERÁ exigir que cada elemento
   cite el o los IDs de Fase 01 (o de PL previos) que lo originan.
2. CUANDO se ejecute la revisión de consistencia, el sistema DEBERÁ señalar todo requisito
   aprobado de Fase 01 que no esté cubierto por ningún documento PL.
3. CUANDO se ejecute la revisión de consistencia, el sistema DEBERÁ señalar todo elemento
   de diseño que no cite ningún origen válido.
4. SI cambia un requisito de Fase 01 (se cierra un `PEN` o cambia una `RN`), ENTONCES el
   modo de propagación DEBERÁ identificar los documentos PL afectados, actualizarlos,
   subir su versión y recalcular su estado.

### REQ-07 — Documentación de uso (README)

**Historia de usuario:** Como nuevo integrante, quiero saber cómo invocar la Fase 02 y qué
produce, para usarla sin leer todo el código de la fábrica.

#### Criterios de aceptación

1. CUANDO se complete la fábrica, el sistema DEBERÁ documentar en el README cómo invocar
   el subagente de la Fase 02, sus tres modos y la precondición de Fase 01 aprobada.
2. El README DEBERÁ incluir un prompt de ejemplo para la Fase 02, análogo al de la Fase 01.
3. El README DEBERÁ reflejar la estructura de archivos resultante de la Fase 02.

### REQ-08 — Modelo de decisión y reunión de diseño

**Historia de usuario:** Como arquitecto, quiero que la fábrica distinga con claridad qué
genera el agente, qué decido yo en la reunión de diseño y qué se deriva automáticamente,
para que el agente nunca invente tecnología ni ambiente y las decisiones queden
justificadas y trazables.

#### Criterios de aceptación

1. CUANDO se construya la fábrica, el sistema DEBERÁ clasificar cada artefacto de la Fase
   02 como 🟢 auto-generable, 🔵 decisión del arquitecto o 🟣 auto-derivado, y documentar esa
   clasificación en el documento marco PL-00.
2. El sistema NO DEBERÁ inferir ni inventar el stack ni el ambiente: esas decisiones 🔵 se
   toman en la reunión de diseño y el agente las DEBERÁ registrar como `DEC-D` (Contexto ·
   Decisión · Alternativas · Consecuencias) en los selectores PL-01 y PL-02.
3. CUANDO el agente registre la decisión de backend y ambiente, el sistema DEBERÁ validar
   las reglas duras de compatibilidad backend↔ambiente y marcar como inconsistencia toda
   combinación prohibida.
4. CUANDO se haya decidido el backend en PL-02, el sistema DEBERÁ auto-derivar la
   arquitectura back (PL-08), el ambiente permitido y el mecanismo de configuración
   aplicando las reglas duras de derivación.
5. El sistema DEBERÁ generar el borrador de PL-05 (modelo de datos) y PL-06 (contrato de
   endpoints) **antes** de la reunión de diseño, por ser 🟢 y no depender del stack, para
   llevarlos a la reunión como insumo.
6. El sistema DEBERÁ incluir el documento marco PL-00 (clasificación 🟢/🔵/🟣 y reglas duras)
   y la guía de la reunión de diseño PL-G (orden del día técnico con el menú de decisiones
   🔵 y las reglas de compatibilidad) con su propósito definido.
7. DADO que el número `PL-NN` indica el orden de catálogo, CUANDO se ejecute el Modo A
   pre-reunión, el orden de **elaboración** DEBERÁ adelantar PL-05 y PL-06 antes de PL-G
   y la reunión, sin que ello cambie la numeración del catálogo.
8. CUANDO se ejecute el Modo A pre-reunión, el sistema DEBERÁ generar el prompt de
   diseño visual (PL-M) para Claude **antes** de la reunión de diseño, listando las pantallas
   derivadas de RQ-05/RQ-07 y usando la paleta de Grupo Salinas por defecto salvo que el
   proyecto indique otra identidad, como apoyo **no bloqueante** (si el mockup no está listo,
   la reunión igual procede).
9. CUANDO se ejecute el Modo B post-reunión, el sistema DEBERÁ tomar las decisiones técnicas
   (stack, ambiente) de la transcripción de la reunión de diseño ubicada en
   `transcripciones diseno/txt/`, y SI no existe la transcripción, ENTONCES el sistema DEBERÁ
   pedirla y detenerse sin crear ni completar los documentos del Modo B.
