# Diseño — Fábrica de la Fase 02 (Plan / Diseño) de SDD

## Objetivo

Construir la "fábrica" de la **Fase 02 · Plan/Diseño** (código `PL`, responsable
Arquitecto) replicando el patrón que ya funciona en la Fase 01: una fuente única de
convenciones (steering), plantillas limpias, una skill por documento, un subagente de
fase e instructivos para personas.

La Fase 02 **transforma los requisitos aprobados de la Fase 01 en un diseño técnico
completo**. Si la Fase 01 describe el **QUÉ**, la Fase 02 describe el **CÓMO**: ambientes,
stack, arquitectura, modelo de datos, contratos, manejo de errores, vistas y estrategia
de pruebas.

### Principios heredados de la Fase 01 (no se renegocian)

1. **Fuente única de reglas:** las convenciones viven en `sdd-convenciones.md`. Las
   skills, plantillas e instructivos las *aplican*, no las repiten.
2. **El número del documento es su orden de elaboración.**
3. **Un documento solo cita IDs de documentos anteriores** (de Fase 01 o de documentos
   PL previos). Citar = poner el ID, nunca copiar contenido.
4. **Marcadores únicos:** `[Inferido]`, `[Propuesto]`, `⚠️ POR CONFIRMAR (PEN-###)`,
   `N/A`. Todo `⚠️` tiene su `PEN` en una minuta RQ-03.
5. **Encabezado e historial obligatorios** en todo documento (misma tabla que Fase 01,
   con `Documento | PL-NN · <Nombre>` y `Elaboró | sdd-02-plan-diseno`).
6. **Estados:** Draft → Pending Validation → Validated → Approved. El agente nunca
   asigna Validated ni Approved.
7. **El agente no inventa datos.** Si un requisito no existe o es ambiguo, levanta un
   `⚠️ POR CONFIRMAR` ligado a un `PEN` nuevo en la minuta RQ-03 de la sesión más
   reciente (los pendientes siguen siendo propiedad de la minuta de Discovery).
8. **Idioma español.**

### El cambio de naturaleza respecto a la Fase 01

| Fase 01 (Requerimientos) | Fase 02 (Plan/Diseño) |
|--------------------------|------------------------|
| Insumo: transcripciones de Discovery | Insumo: documentos **aprobados** de Fase 01 (RQ-04…RQ-08) |
| Describe el QUÉ | Describe el CÓMO |
| Prohíbe tecnología, endpoints, tablas, UI | Es exactamente donde viven esos artefactos |
| Pendientes técnicos: N/A | Aparecen **decisiones de diseño** (`DEC-D`) tomadas por el Arquitecto |
| Solo texto | Dos entregables son **diagramas** (draw.io) que dibuja una persona; el agente solo especifica qué dibujar |

## 1. Catálogo de documentos de la Fase 02

Los 11 entregables de la fase de Plan/Diseño, numerados con prefijo `PL`. **El número es
el orden de elaboración** y cada documento solo cita a los anteriores (PL previos o
documentos de Fase 01). El orden va de lo más estratégico (dónde y con qué construimos) a
lo más detallado (cómo se ve y cómo se prueba).

| Código | Documento | Formato | Responsable | Insumo principal |
|--------|-----------|---------|-------------|------------------|
| PL-01 | Selección de ambientes | `.md` | Luis | RQ-04 (NF), RQ-08 |
| PL-02 | Selección de stack | `.md` | Luis | PL-01, RQ-04 (NF) |
| PL-03 | Guía de diagrama de arquitectura | `.md` (+ `.drawio` adjunto del arquitecto) | Luis | PL-01, PL-02 |
| PL-04 | Guía de diagrama de flujos | `.md` (+ `.drawio` adjunto del arquitecto) | Luis | RQ-07 |
| PL-05 | Diccionario de datos, modelo de datos e interfaces | `.md` | Luis | RQ-04 (glosario), RQ-06, RQ-07 |
| PL-06 | Contrato de endpoints | `.md` | Andrés | PL-05, RQ-07 |
| PL-07 | Enfoque de manejo de errores | `.md` | Jack | RQ-08, PL-06 |
| PL-08 | Diseño de arquitectura back | `.md` | Andrés | PL-02, PL-03, PL-06 |
| PL-09 | Diseño de arquitectura front | `.md` | Ana | PL-02, PL-03 |
| PL-10 | Especificación de vistas y rutas (front) | `.md` | Ana | PL-09, RQ-05, RQ-07 |
| PL-11 | Estrategia de pruebas | `.md` | Arquitecto | RQ-08, PL-05, PL-06 |

Notas de orden y alcance acordadas:

- **Ambientes (PL-01) antes que stack (PL-02):** la selección de ambientes (servidores,
  repos, dependencias con otras áreas) condiciona el stack (en este contexto .NET Core 8
  y .NET Framework 4.8 conviven según el ambiente).
- **Manejo de errores es documento propio (PL-07):** cruza back, front y contratos, así
  que se centraliza (catálogo de errores, códigos, formato de respuesta de error,
  logging) en lugar de diluirse en el diseño back.
- **Back (PL-08) y front (PL-09) siempre van separados**, con responsables distintos
  (Andrés / Ana). No se unifican aunque el proyecto sea pequeño.

Además del catálogo PL-01…PL-11, la fase incorpora dos artefactos nuevos descritos en la
sección 1.bis: el **documento marco PL-00** (clasificación auto/manual/auto-derivado) y la
**guía de la reunión de diseño** (orden del día técnico). Ver 1.bis.

## 1.bis Modelo de decisión: auto-generable / decisión del arquitecto / auto-derivado

La fase 02 distingue, por cada artefacto, **quién lo decide y de dónde sale**. Esto evita
que el agente "invente" tecnología y deja claro qué es una decisión humana justificada.

| Tipo | Qué significa | Quién lo produce |
|------|---------------|------------------|
| 🟢 **Auto-generable** | Se **deriva de los requerimientos** (qué hace el sistema y con qué datos); no depende de la tecnología | El agente genera el borrador; el responsable valida |
| 🔵 **Decisión del arquitecto** | Decisión técnica que **no** se infiere de requerimientos (tecnología, ambiente, despliegue); se toma y **se justifica** en la reunión de diseño | El arquitecto decide en reunión; el agente **captura la decisión y su porqué** como `DEC-D` en el selector |
| 🟣 **Auto-derivado** | No viene de requerimientos ni es libre: queda **determinado por una decisión 🔵 previa** (regla dura) | El agente lo fija aplicando la regla de derivación |

Clasificación de los artefactos de la fase:

| Artefacto | Tipo | Observación |
|-----------|------|-------------|
| PL-05 Modelo de datos | 🟢 | Deriva del diccionario/glosario y reglas de Fase 01 |
| PL-06 Contrato de endpoints | 🟢 | Deriva de las acciones de los `CU` + datos de PL-05 |
| PL-10 Vistas y rutas front | 🟢 | Deriva de las `HU` y `CU` |
| PL-M Prompt de diseño visual (para Claude) | 🟢 | Lista las pantallas (de `HU`/`CU`) y arma el prompt para Claude; paleta Grupo Salinas por defecto; apoyo no bloqueante antes de la reunión |
| PL-01 Selección de ambientes | 🔵 | Selector con la infraestructura real; decisión del arquitecto |
| PL-02 Selección de stack | 🔵 | Selector (backend, acceso a datos, motor BD, auth, esquema, despliegue, ambiente) |
| PL-08 Arquitectura back | 🟣 | **Se deriva del backend** elegido en PL-02 (regla dura) |
| Ambiente permitido · mecanismo de config | 🟣 | Se derivan del backend (reglas de compatibilidad) |

### Cómo se toman las decisiones 🔵: la reunión de diseño

Las decisiones técnicas **no** las adivina el agente ni se marcan en frío: se toman en una
**reunión de diseño** donde el arquitecto, con los artefactos aprobados de la Fase 01 a la
vista, explica ante el equipo la arquitectura y tecnología que se usarán y **por qué**.

Un matiz importante de secuencia: los artefactos 🟢 que **no dependen de la tecnología**
(modelo de datos y endpoints) se generan **antes** de la reunión, en borrador, para que la
reunión decida el stack **viendo ya qué datos y operaciones** tiene el sistema. El flujo es:

```
Fase 01 aprobada
  → PL-00 (clasificación: fija qué es 🟢/🔵/🟣 en este proyecto)
  → 🟢 BORRADOR: PL-05 modelo de datos + PL-06 contrato de endpoints + PL-M prompt de diseño
     visual para Claude (el agente los infiere de los requerimientos; NO dependen del stack;
     PL-M es apoyo no bloqueante)
  → PL-G GUÍA DE LA REUNIÓN (orden del día técnico + modelo de datos y endpoints como material)
  ── [fin del Modo A: material listo para la reunión] ──
  → REUNIÓN: el arquitecto decide y justifica stack/ambiente viendo datos y operaciones;
     la reunión se transcribe a transcripciones diseno/txt/<COD>_reunion-diseno.txt
  ── [inicio del Modo B: con la transcripción de la reunión] ──
  → 🔵 el agente rellena PL-01 (ambientes) y PL-02 (stack) y captura el porqué como DEC-D
  → 🟣 el agente aplica las reglas de derivación: PL-08 arquitectura back (y PL-09 front),
     ambiente permitido y mecanismo de configuración, según el backend
  → PL-03 / PL-04: el arquitecto dibuja los diagramas aparte (el agente solo da la guía)
  → 🟢 el agente completa el resto desde los requerimientos: PL-07 errores,
     PL-10 vistas/rutas, PL-11 estrategia de pruebas
  → revisión de consistencia
```

**Por qué el modelo de datos y los endpoints van antes de la reunión:** son 🟢 (se derivan
del glosario/reglas/casos de uso de Fase 01) y **no dependen del stack elegido**. El modelo
de datos no cambia porque el backend sea .NET Core o Framework. Tenerlos listos hace que la
reunión decida la tecnología con una visión concreta de las entidades y operaciones. El
diseño **visual** de pantallas es independiente y no bloquea estos artefactos: PL-10 solo
necesita saber qué vistas existen y qué rol accede, no cómo se ven. Ese diseño visual se arma
con el prompt **PL-M** para Claude (🟢, lista las pantallas de RQ-05/RQ-07 y arma el prompt con
la paleta de Grupo Salinas por defecto), que se genera antes de la reunión como apoyo **no
bloqueante**.

### Artefactos nuevos que incorpora el modelo

1. **PL-00 — Clasificación auto/manual/auto-derivado** (documento marco, el primero de la
   fase). Contiene la tabla 🟢/🔵/🟣 y las reglas de derivación duras (backend → arquitectura,
   backend → ambiente permitido, backend → mecanismo de config). El agente lo lee para saber
   qué generar, qué dejar como decisión y qué derivar. Se numera PL-00 por ser previo a todo.

2. **PL-G — Guía de la reunión de diseño** (checklist/orden del día). Lista las decisiones
   🔵 a tomar en la reunión, con el menú de opciones reales y las reglas de compatibilidad
   como apoyo, y espacio para registrar lo acordado. Es el puente entre la Fase 01 aprobada
   y el llenado de los selectores. (Nombre de archivo: `PL-G_guia-reunion-diseno`; al ser
   transversal no lleva número de orden en la secuencia PL-01…PL-11.)

### Selectores con infraestructura real

PL-01 (ambientes) y PL-02 (stack) dejan de ser documentos "en blanco" y pasan a ser
**selectores** con las opciones reales de la organización (servidores SCI/BIENESTAR, VIPs,
motores de BD, reglas de compatibilidad backend↔ambiente), tomadas del material del equipo.
El arquitecto marca lo elegido y el agente registra el `DEC-D` con la justificación dada en
la reunión. Las **reglas duras** (p. ej. .NET Core → solo W2022 / Aplicaciones; .NET
Framework → W2022 o W2016 / Aplicaciones o Portales) se validan: el agente no permite una
combinación prohibida y lo marca como inconsistencia.

### PL-08 auto-derivada del backend

La arquitectura back ya no se "elige" aparte: **la fija el backend** de PL-02 (regla dura).
.NET Core (.NET 8) → arquitectura orientada a servicios (Controladores → Interfaces →
Servicios, proyecto único). .NET Framework → 3 capas (DAL/DLL → BLL → Microservicio), con
la variante legacy GS cuando se extiende un servicio existente. PL-08 también incorpora el
requisito transversal de **monitoreo/health** (endpoint de salud, diagnóstico de BD y de
dependencias) que nace en Requerimientos.

### Diagramas (PL-03 y PL-04): el agente especifica, la persona dibuja

El arquitecto mantiene un **diagrama maestro** en draw.io con todos los elementos posibles
(servidores, BD, balanceadores, etc.). En cada proyecto crea un `.drawio` nuevo
**copiando/pegando** solo los elementos que aplican. El diagrama lo arma una persona.

El agente **no dibuja**. Genera un `.md` que es una **guía + checklist de qué elementos
del diagrama maestro debe copiar el arquitecto** para este proyecto y cómo se conectan,
derivada del stack (PL-02) y los ambientes (PL-01). El arquitecto hace el copy/paste en
draw.io y referencia el `.drawio` resultante como adjunto en el `.md`.

- **PL-03** contiene: lista de elementos a incluir (con justificación: "porque el stack es
  X / porque hay ambiente Y"), relaciones entre ellos, y un campo para la ruta/nombre del
  `.drawio` adjunto.
- **PL-04** contiene: lista de flujos a dibujar (derivados de los `CU` de RQ-07), con los
  pasos y decisiones que debe tener cada uno, y el campo para el `.drawio` adjunto.
- No se genera Mermaid ni XML de draw.io: el entregable visual es responsabilidad humana;
  el agente entrega la **especificación de qué dibujar**.

## 2. Nuevos identificadores (prefijos)

La Fase 02 agrega esta familia de prefijos, siguiendo el formato `PREFIJO-NNN` del
steering §3:

| Prefijo | Qué identifica | Dueño | Ejemplo |
|---------|----------------|-------|---------|
| `AMB` | Ambiente (dev, prod, QA…) | PL-01 | AMB-002 |
| `DEC-D` | Decisión de diseño (técnica, del Arquitecto) | el documento donde se toma | DEC-D-003 |
| `ENT` | Entidad del modelo de datos | PL-05 | ENT-004 |
| `CAM` | Campo / dato del diccionario | PL-05 | ENT-004.CAM-02 |
| `EP` | Endpoint | PL-06 | EP-007 |
| `ERR` | Error del catálogo | PL-07 | ERR-005 |
| `VIS` | Vista / pantalla | PL-10 | VIS-003 |
| `RUT` | Ruta (front) | PL-10 | RUT-003 |
| `TPR` | Tipo / estrategia de prueba | PL-11 | TPR-002 |

**Decisiones de diseño (`DEC-D`):** registran una decisión técnica con el formato
Contexto · Decisión · Alternativas · Consecuencias (equivalente a un ADR, pero con
prefijo propio para no confundirse con las `DEC` de negocio de la minuta RQ-03).

### Trazabilidad hacia atrás (obligatoria)

Cada elemento de un documento PL **debe citar los IDs de Fase 01 (o de PL previos) que lo
originan**. Ejemplos: un endpoint `EP-007` cita el `CU-003` y la `RN-012` que satisface;
una entidad `ENT-004` cita el término del glosario de RQ-04; una prueba `TPR-002` cita el
`REQ-005` que valida. Esto permite que la revisión de consistencia verifique que **todo
requisito aprobado quedó cubierto por el diseño** y que **nada del diseño sale de la
nada**.

## 3. El subagente `sdd-02-plan-diseno`

Un **único subagente** orquesta todas las skills de la fase (igual que en Fase 01). Los
"responsables" (Luis, Andrés, Ana, Arquitecto) son quienes **validan** cada documento, no
agentes separados; el valor está en la trazabilidad y consistencia entre documentos.

Replica el formato del subagente de Fase 01 (frontmatter `name`/`description`/`tools`/
`resources`, cuerpo con rol + modos + entregables):

```yaml
name: sdd-02-plan-diseno
tools: ["read", "write"]
resources:
  - file://.kiro/steering/sdd-convenciones.md
  - skill://pl-01-seleccion-ambientes
  - ... (una por documento)
  - skill://pl-revision-consistencia
```

### Antes de empezar (precondiciones)

1. **La Fase 01 debe estar aprobada (precondición estricta).** El subagente exige que
   RQ-04…RQ-08 del proyecto existan en `documentacion/`, estén en estado `Approved` y sin
   `PEN` críticos abiertos. Si no se cumple, se detiene, explica qué documento falta o en
   qué estado está, y **no crea archivos**.
2. Si no conoce el **código de proyecto**, lo pregunta (reusa el mismo `<COD>` de Fase 01).
3. Revisa qué documentos PL ya existen para saber en qué punto va.

### Modos del subagente

El diseño se elabora en **dos tiempos** alrededor de la reunión de diseño (ver §1.bis): lo
que se prepara antes (Modo A) y lo que se genera después con lo decidido (Modo B).

- **Modo A — Pre-reunión:** genera lo que **no depende del stack** y sirve de insumo para la
  reunión: PL-00 → PL-05 · PL-06 · PL-M (borradores 🟢) → PL-G. Es el material que se lleva a
  la reunión de diseño. Se usa cuando la Fase 01 está aprobada.
- **Modo B — Post-reunión:** su insumo es la **transcripción de la reunión de diseño** en
  `transcripciones diseno/txt/` (un `.txt`; si viene en `.docx`, se convierte antes). Con lo
  decidido genera PL-01 · PL-02 (🔵, con `DEC-D`) → PL-08 · PL-09 (🟣 derivadas) → PL-03 ·
  PL-04 → PL-07 · PL-10 · PL-11 (🟢) y cierra con la revisión de consistencia. El agente no
  inventa las decisiones: las toma de la transcripción; si falta, la pide y se detiene.
- **Modo — Documento específico:** genera o actualiza un PL concreto, verificando que
  existan sus insumos (PL previos, documentos RQ o la transcripción de la reunión). Se usa
  para avanzar por partes o rehacer uno.
- **Modo — Propagación de cambios:** cuando cambia un requisito de Fase 01 (se cierra un
  `PEN`, cambia una `RN`), identifica qué documentos PL se ven afectados, los actualiza,
  sube versión y recalcula estado.

## 4. Las skills (una por documento)

Mismo patrón que Fase 01: `.kiro/skills/pl-NN-<nombre>/SKILL.md`, con frontmatter
`name` + `description`, y cuerpo con: Insumos · Procedimiento · Lo que NO va aquí ·
Checklist final. Cada skill aplica el steering, no lo repite.

| Skill | Genera | Esencia del contenido |
|-------|--------|------------------------|
| `pl-01-seleccion-ambientes` | PL-01 | Servidores front/back, BD, dev, prod, multimedia, repos, dependencias con otras áreas (`AMB`) |
| `pl-02-seleccion-stack` | PL-02 | Stack front/back y versiones, justificado contra los `NF` de RQ-04; decisiones `DEC-D` |
| `pl-03-diagrama-arquitectura` | PL-03 | Checklist de elementos del diagrama maestro a copiar (según PL-01/PL-02) y relaciones; campo para el `.drawio` adjunto |
| `pl-04-diagrama-flujos` | PL-04 | Lista de flujos a dibujar (derivados de los `CU`), con pasos y decisiones; campo para el `.drawio` adjunto |
| `pl-05-diccionario-modelo-datos` | PL-05 | Entidades `ENT`, campos `CAM` (tipo, obligatorio, sensible); cita glosario/reglas de Fase 01 |
| `pl-06-contrato-endpoints` | PL-06 | Endpoints `EP`: nombre, consumo, método, parámetros, respuesta JSON, códigos, propósito; cita `CU`/`RN` |
| `pl-07-manejo-errores` | PL-07 | Catálogo de errores `ERR`, códigos, formato de respuesta de error, logging |
| `pl-08-arquitectura-back` | PL-08 | Tecnología, arquitectura 3 capas, distribución del código a nivel de módulos y responsabilidades (sin firmas de métodos) |
| `pl-09-arquitectura-front` | PL-09 | Arquitectura front: organización de componentes, estado y servicios (nivel alto) |
| `pl-10-vistas-rutas-front` | PL-10 | Vistas `VIS` y rutas `RUT`; supuestos (diseño propio o provisto); cita `HU`/`CU` |
| `pl-11-estrategia-pruebas` | PL-11 | Tipos de prueba `TPR` (unit/integ/E2E), qué no entra, criterios globales, pirámide |
| `pl-revision-consistencia` | reporte en chat | Verifica IDs, cobertura RQ→PL, referencias, estados y nombres de archivo |

**Nivel de detalle del diseño back/front (PL-08 / PL-09):** se queda a **nivel alto**
(capas, módulos, responsabilidades y distribución del código). Las **firmas exactas de
métodos** (nombre + parámetros + retorno) NO van aquí: se definen en la fase de
Tareas/Desarrollo. Esto mantiene la skill manejable y evita escribir el esqueleto del
código en la fase de diseño.

## 5. Plantillas

Mismo criterio que Fase 01: **plantillas limpias, solo estructura, sin instrucciones de
IA**. Las instrucciones viven en la skill; la guía para personas, en el instructivo.

- Ubicación: `templates/PL-NN_<nombre>.md`
- Cada una abre con la tabla de encabezado (steering §6) y cierra con `## Historial de
  cambios`.
- Nombres oficiales (`<nombre>`): `seleccion-ambientes`, `seleccion-stack`,
  `diagrama-arquitectura`, `diagrama-flujos`, `diccionario-modelo-datos`,
  `contrato-endpoints`, `manejo-errores`, `arquitectura-back`, `arquitectura-front`,
  `vistas-rutas-front`, `estrategia-pruebas`. (Minúsculas, sin acentos, con guion.)

## 6. Instructivos (para personas)

Mismo estilo que `RQ-06_reglas-negocio_instructivo.md`: qué es, insumos, columna por
columna, ejemplos bien llenados, errores comunes, checklist.

Al igual que en Fase 01 (solo RQ-06 y RQ-08 tienen instructivo), se priorizan los tres
documentos más propensos a inconsistencia: **PL-05 (modelo de datos), PL-06 (contrato de
endpoints) y PL-11 (estrategia de pruebas)**. El resto queda sin instructivo por ahora.

## 7. Cambios al steering `sdd-convenciones.md`

El steering ya contempla la Fase 02 en la tabla de las 7 fases (§1), pero su detalle
(§2, §3, §4) solo cubre la Fase 01. Se **amplía** (no se reescribe) con:

- Una tabla equivalente a §2 pero para los documentos PL-01…PL-11 (qué contiene cada uno y
  qué NO contiene, y dónde va lo que no le corresponde).
- Los nuevos prefijos de ID de la sección 2 de este diseño, en §3.
- Los patrones de nombre de archivo PL en §4 (se generaliza el patrón `RQ-NN` a `<FASE>-NN`
  o se agrega la variante `PL-NN`).
- La ubicación de salida: `documentacion/02-plan-diseno/`.

Lo demás del steering (marcadores §5, encabezado §6, estados §7, idioma §8) **se reusa tal
cual**; no se duplica nada.

### Ubicación de salida con subcarpeta por fase

Los documentos PL se guardan en `documentacion/02-plan-diseno/`, en paralelo a
`documentacion/01-requerimientos/`. Se estandariza la subcarpeta por fase (y de paso se
alinea que la Fase 01 use `documentacion/01-requerimientos/`, corrigiendo la mención a
`docs/01-requerimientos/` del README actual).

Nombre de archivo de proyecto: `<COD>_PL-NN_<nombre>.md`
(ejemplo: `MJG_PL-06_contrato-endpoints.md`).

## 8. Estructura de archivos resultante

```text
.kiro/
  steering/sdd-convenciones.md            ← AMPLIADO con sección Fase 02 y modelo 🟢/🔵/🟣
  agents/sdd-02-plan-diseno.md            ← NUEVO
  skills/pl-00, pl-g, pl-m, pl-01 … pl-11, pl-revision-consistencia   ← NUEVOS (15 skills, planas)
templates/02-plan-diseno/PL-00, PL-G, PL-M, PL-01 … PL-11   ← NUEVOS (14 plantillas)
instructivos/02-plan-diseno/PL-05, PL-06, PL-11       ← NUEVOS (3 instructivos)
documentacion/02-plan-diseno/             ← salida de los documentos de proyecto
```

> Nota de evolución: el diseño original contemplaba 12 skills y 11 plantillas. Tras integrar
> el modelo 🟢/🔵/🟣 (ver §1.bis) se añadieron **PL-00** (clasificación) y **PL-G** (guía de
> la reunión de diseño); más tarde se sumó **PL-M** (prompt de diseño visual para Claude),
> quedando **15 skills y 14 plantillas**. Las skills se mantienen
> planas en `.kiro/skills/` (Kiro no las descubre en subcarpetas); plantillas e instructivos
> se organizan en subcarpetas por fase.

## 9. Resumen de decisiones (todas cerradas)

| # | Decisión | Acuerdo |
|---|----------|---------|
| 1 | Orden PL-01 ambientes vs PL-02 stack | Ambientes primero |
| 2 | Cómo se producen los diagramas draw.io | El agente genera guía/checklist; el arquitecto dibuja y adjunta el `.drawio` |
| 3 | Manejo de errores | Documento propio PL-07 |
| 4 | Back y front | Siempre separados (PL-08 / PL-09) |
| 5 | Nombre de decisiones técnicas | `DEC-D` (formato tipo ADR) |
| 6 | Trazabilidad PL→RQ | Obligatoria en cada documento |
| 7 | Precondición de Fase 01 | Estricta: RQ-04…RQ-08 en `Approved`, sin `PEN` críticos |
| 8 | Número de subagentes | Uno solo (`sdd-02-plan-diseno`) |
| 9 | Nivel de detalle de PL-08/PL-09 | Nivel alto (capas/responsabilidades); sin firmas de métodos |
| 10 | Instructivos | Solo PL-05, PL-06 y PL-11 |
| 11 | Ubicación de salida | `documentacion/02-plan-diseno/`, subcarpeta por fase |
