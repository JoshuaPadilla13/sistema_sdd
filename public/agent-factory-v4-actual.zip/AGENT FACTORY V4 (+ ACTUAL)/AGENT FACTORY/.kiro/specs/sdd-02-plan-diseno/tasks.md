# Plan de tareas — Fábrica de la Fase 02 (Plan / Diseño) de SDD

Construcción incremental de la fábrica. El orden respeta las dependencias: primero la
fuente única de reglas (steering), luego las plantillas (estructura), después las skills
(instrucciones), el subagente que las orquesta, los instructivos y, al final, la
documentación y la revisión de consistencia.

Cada tarea cita los requisitos que satisface.

- [x] 1. Ampliar el steering `sdd-convenciones.md` con la Fase 02
  - Agregar la tabla de documentos PL-01…PL-11 (qué contiene / qué NO contiene cada uno)
  - Agregar los prefijos `AMB`, `DEC-D`, `ENT`, `CAM`, `EP`, `ERR`, `VIS`, `RUT`, `TPR`
  - Agregar el patrón de archivo `<COD>_PL-NN_<nombre>.md` y la ruta `documentacion/02-plan-diseno/`
  - Alinear la ruta de salida de la Fase 01 a `documentacion/01-requerimientos/`
  - No duplicar marcadores, encabezado, estados ni idioma
  - _Requisitos: REQ-01.1, REQ-01.2, REQ-01.3, REQ-01.4, REQ-01.6_

- [x] 2. Crear las 11 plantillas `templates/PL-NN_<nombre>.md`
  - [x] 2.1 PL-01 selección de ambientes y PL-02 selección de stack
    - Encabezado del steering §6 + `## Historial de cambios`; solo estructura
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.4_
  - [x] 2.2 PL-03 guía de diagrama de arquitectura y PL-04 guía de diagrama de flujos
    - Incluir campo para referenciar el `.drawio` adjunto
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.5_
  - [x] 2.3 PL-05 diccionario/modelo de datos y PL-06 contrato de endpoints
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.4_
  - [x] 2.4 PL-07 manejo de errores
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.4_
  - [x] 2.5 PL-08 arquitectura back y PL-09 arquitectura front
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.4_
  - [x] 2.6 PL-10 vistas y rutas front y PL-11 estrategia de pruebas
    - _Requisitos: REQ-04.1, REQ-04.2, REQ-04.3, REQ-04.4_

- [x] 3. Crear las skills de documento `pl-01`…`pl-11`
  - [x] 3.1 `pl-01-seleccion-ambientes` y `pl-02-seleccion-stack`
    - Frontmatter + Insumos / Procedimiento / Lo que NO va aquí / Checklist
    - Indicar qué IDs de Fase 01 citar (trazabilidad obligada); `pl-02` introduce `DEC-D`
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4_
  - [x] 3.2 `pl-03-diagrama-arquitectura` y `pl-04-diagrama-flujos`
    - Producen guía/checklist de qué dibujar + campo `.drawio`; NO generan el diagrama
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4, REQ-03.5_
  - [x] 3.3 `pl-05-diccionario-modelo-datos` y `pl-06-contrato-endpoints`
    - Trazabilidad a glosario/RN/CU; `EP` cita `CU`/`RN`
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4_
  - [x] 3.4 `pl-07-manejo-errores`
    - Catálogo `ERR`, códigos, formato de respuesta de error, logging
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4_
  - [x] 3.5 `pl-08-arquitectura-back` y `pl-09-arquitectura-front`
    - Nivel alto (capas, módulos, responsabilidades); sin firmas de métodos
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4, REQ-03.6_
  - [x] 3.6 `pl-10-vistas-rutas-front` y `pl-11-estrategia-pruebas`
    - `VIS`/`RUT` citan `HU`/`CU`; `TPR` cita `REQ` de RQ-08
    - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.3, REQ-03.4_

- [x] 4. Crear la skill `pl-revision-consistencia`
  - Verifica IDs, cobertura RQ→PL, referencias, estados y nombres de archivo
  - Señala requisitos de Fase 01 no cubiertos y elementos de diseño sin origen
  - Reporta en el chat; no genera documento de proyecto
  - _Requisitos: REQ-03.1, REQ-03.2, REQ-03.7, REQ-06.2, REQ-06.3_

- [x] 5. Crear el subagente `.kiro/agents/sdd-02-plan-diseno.md`
  - Frontmatter `name`/`description`/`tools: ["read","write"]`/`resources` (steering + 12 skills)
  - Precondición estricta: RQ-04…RQ-08 en `Approved` y sin `PEN` críticos; si no, se detiene
  - Pedir código de proyecto si falta; revisar qué PL existen
  - Tres modos (completo / documento específico / propagación); manejo de insumos faltantes
  - Cierre de entrega: archivos con versión y estado + siguiente paso
  - _Requisitos: REQ-02.1, REQ-02.2, REQ-02.3, REQ-02.4, REQ-02.5, REQ-02.6, REQ-02.7, REQ-02.8, REQ-02.9, REQ-06.1, REQ-06.4_

- [x] 6. Crear los 3 instructivos (PL-05, PL-06, PL-11)
  - [x] 6.1 `instructivos/PL-05_diccionario-modelo-datos_instructivo.md`
    - _Requisitos: REQ-05.1, REQ-05.2, REQ-05.3_
  - [x] 6.2 `instructivos/PL-06_contrato-endpoints_instructivo.md`
    - _Requisitos: REQ-05.1, REQ-05.2, REQ-05.3_
  - [x] 6.3 `instructivos/PL-11_estrategia-pruebas_instructivo.md`
    - _Requisitos: REQ-05.1, REQ-05.2, REQ-05.3_

- [x] 7. Actualizar el README con la Fase 02
  - Cómo invocar el subagente, sus tres modos y la precondición de Fase 01 aprobada
  - Prompt de ejemplo de la Fase 02 (análogo al de Fase 01)
  - Reflejar la estructura de archivos resultante
  - _Requisitos: REQ-07.1, REQ-07.2, REQ-07.3_

- [x] 8. Verificación integral de consistencia de la fábrica
  - Revisar que todos los nombres de archivo, prefijos y rutas coincidan entre steering,
    skills, plantillas, instructivos, subagente y README
  - Confirmar que ninguna skill/plantilla duplica reglas del steering
  - Confirmar que el subagente referencia exactamente las skills existentes
  - _Requisitos: REQ-01.5, REQ-03.3, REQ-06.2, REQ-06.3_

- [x] 9. Integrar modelo 🟢/🔵/🟣 y documentos PL-00 y PL-G
  - Integración posterior: el modelo de decisión fusionado (auto-generable / decisión del
    arquitecto / auto-derivado) y los documentos marco PL-00 y PL-G se incorporaron después
    de las tareas 1-8, alineando steering, subagente, README y spec.
  - [x] 9.1 Crear plantilla y skill PL-00 (clasificación auto/manual/auto-derivado)
    - _Requisitos: REQ-04.1, REQ-08.1, REQ-08.6_
  - [x] 9.2 Crear plantilla y skill PL-G (guía de reunión de diseño)
    - _Requisitos: REQ-04.1, REQ-08.2, REQ-08.6_
  - [x] 9.3 Reescribir PL-01, PL-02 como selectores con infraestructura real
    - _Requisitos: REQ-03.1, REQ-08.2, REQ-08.3_
  - [x] 9.4 Reescribir PL-08 como auto-derivada del backend + monitoreo/health
    - _Requisitos: REQ-03.6, REQ-08.4_
  - [x] 9.5 Ajustar secuencia: PL-05/PL-06 antes de la reunión
    - _Requisitos: REQ-08.5, REQ-08.7_
  - [x] 9.6 Actualizar subagente, steering y README con el modelo y el flujo
    - _Requisitos: REQ-01.1, REQ-02.2, REQ-07.1, REQ-08.1_
  - [x] 9.7 Crear artefacto PL-M (prompt de diseño visual para Claude) con paleta Grupo Salinas por defecto, generado antes de la reunión
    - _Requisitos: REQ-08_
  - [x] 9.8 Reestructurar modos del subagente (A pre-reunión / B post-reunión) y crear carpeta transcripciones diseno/txt/
    - _Requisitos: REQ-02.7, REQ-08.9_

- [x] 10. Acta de decisiones como insumo alternativo del Modo B
  - Plantilla `templates/02-plan-diseno/PL-A_acta-decisiones-diseno.md` para reuniones sin grabar
  - El subagente exige transcripción **o** acta como archivo antes de PL-01/PL-02; una tabla
    en el chat no es insumo. PL-01 toma el backend del insumo, no de PL-02 (sin cita circular)
  - Steering (§2.bis, §4 corregido y nombres oficiales), README, PL-G §5 y README de
    `transcripciones diseno/txt/` actualizados
  - _Requisitos: REQ-02.7, REQ-08.9_

- [x] 11. Hooks de calidad (`.kiro/hooks/sdd-calidad.json` + `.kiro/scripts/`)
  - `PreToolUse` (bloquea): Validated/Approved asignado por el agente, marcadores prohibidos,
    PL-01/PL-02 sin transcripción ni acta
  - `PostFileSave` (avisa): nombre §4, encabezado/historial §6, estado vs ⚠️ §7, PEN en minuta,
    Fuentes existentes
  - _Requisitos: REQ-01.5, REQ-06.2_

- [x] 12. Artefacto PL-J (customer journey) y refuerzo de PL-M
  - Plantilla `templates/02-plan-diseno/PL-J_customer-journey.md`: fases del journey de
    **nuestro cliente** (el que firma) derivadas de RQ-04/RQ-05/RQ-07 + prompt para Claude;
    acota el alcance del diseño. Skill `pl-j-customer-journey`
  - PL-J se elabora antes que PL-M (journey precede al diseño), no bloqueante; el journey es
    siempre sobre nuestro cliente, nunca por roles internos
  - Refuerzo de la plantilla PL-M: login con identidad de marca, propuesta visual no genérica,
    vistas por rol genuinamente distintas, arranque correcto por rol, selector de rol/demo
    fuera del lienzo, y recorrido que sigue el diagrama de flujo del cliente acotado al journey
  - Instructivo `instructivos/02-plan-diseno/PL-J_customer-journey_instructivo.md`
  - Steering (§2.bis PL-J, modelo de decisión, §4 nombres y patrón de archivo + regla de
    variantes de prueba `-v#-prueba`), subagente (resources, tabla, Modo A, transversales) y
    README actualizados
  - _Requisitos: REQ-08_
