---
inclusion: fileMatch
fileMatchPattern: 'documentacion/**'
---

# Convenciones SDD del equipo (fuente única)

Este archivo es la **única fuente** de las reglas comunes de la documentación SDD.
Las skills, plantillas e instructivos **no repiten** estas reglas: las aplican.
Si algún archivo dice algo distinto, **manda este**.

---

## 1. Las 7 fases y su código

| # | Fase | Código | Responsable |
|---|------|--------|-------------|
| 01 | Requerimientos | RQ | Product Manager |
| 02 | Plan / Diseño | PL | Arquitecto |
| 03 | Tareas | TA | Frontend y Backend |
| 04 | Desarrollo | DE | Frontend y Backend |
| 05 | Testing | TE | QA |
| 06 | Deploy | DP | Backend |
| 07 | Entrega | EN | Arquitecto / Product Manager |

**Requerimientos describe el QUÉ, nunca el CÓMO.** En la fase 01 no se escriben
endpoints, tablas, tipos de dato técnicos, librerías, stack, colores ni diseño de
pantallas: eso es de la fase 02.

---

## 2. Documentos de la fase 01 — orden y responsable único de cada dato

El número del documento **es** su orden de elaboración.

| Código | Documento | Contiene SOLO | NO contiene (y dónde va) |
|--------|-----------|---------------|---------------------------|
| RQ-01 | Checklist de Discovery (**único** por proyecto; se actualiza cada sesión) | Cobertura por bloques A–D, acumulada entre sesiones | Pendientes (van en RQ-03) · un segundo checklist por sesión |
| RQ-02 | Cuestionario de Discovery | Respuestas del cliente en su lenguaje | Interpretación SDD, IDs de requerimientos |
| RQ-03 | Minuta de sesión de Discovery | Datos de la sesión, participantes, temas, decisiones `DEC`, suposiciones `SUP` y **todos los pendientes `PEN` del proyecto** | Requerimientos, reglas, criterios |
| RQ-04 | Documento base del proyecto | Título, problemas `P`, objetivos `OBJ`, alcance incluido `INC` / excluido `EXC`, actores `ACT`, límites no funcionales `NF` (declarados), glosario | Criterios verificables (RQ-08), reglas (RQ-06) |
| RQ-05 | Historias de usuario | `HU`: actor, Como/Quiero/Para, prioridad, dependencias, a qué `OBJ`/`INC` contribuye | Criterios de aceptación, reglas, validaciones, textos de pantalla, estados de UI, API, datos |
| RQ-06 | Reglas de negocio | `RN`: regla del dominio, tipo, origen | Mensajes al usuario (RQ-08), UI, no funcionales (RQ-04), Service/DTO/pruebas (fases 02 y 05) |
| RQ-07 | Casos de uso | `CU`: actores, disparador, pre/postcondiciones, flujo principal, alternos `FA`, excepciones `FE`, estados y transiciones | Criterios EARS (RQ-08), textos exactos de mensajes (RQ-08) |
| RQ-08 | Criterios de aceptación EARS | `REQ` con criterios `CA` en EARS, mensajes exactos, criterios verificables de los `NF` | Gherkin (es de Testing, fase 05), implementación |

### Regla de referencias (evita contradicciones)

1. Un documento **solo cita IDs de documentos anteriores** en el orden (RQ-08 cita
   RQ-04…RQ-07; RQ-05 cita RQ-04; nadie cita hacia adelante).
2. Citar = poner el ID. **Nunca copiar ni reescribir** el contenido de otro documento.
3. La trazabilidad hacia adelante no se escribe a mano: la calcula la revisión de
   consistencia (skill `rq-revision-consistencia`).
4. Gherkin (Dado/Cuando/Entonces) **no se usa en la fase 01**.

### Responsables de conceptos que se prestan a duplicarse

| Concepto | Dueño | Los demás… |
|----------|-------|------------|
| Pendientes | RQ-03 (minuta) | ponen el marcador con su `PEN-###` |
| Requisitos no funcionales | RQ-04 los **declara** (`NF-###`) | RQ-08 los vuelve **verificables** citando el `NF` |
| Actores / roles | RQ-04 (`ACT-###`) | citan el `ACT` |
| Términos del dominio | RQ-04 (glosario) | usan el término tal cual |
| Estados de una entidad | RQ-07 (estados y transiciones) | RQ-08 los escribe en MAYÚSCULAS entre comillas |
| Mensajes exactos al usuario | RQ-08 | nadie más los redacta |

---

## 2.bis Documentos de la fase 02 — orden y responsable único de cada dato

Igual que en la fase 01, **el número del documento es su orden de elaboración**. La fase 02
describe el **CÓMO**: ambientes, stack, arquitectura, modelo de datos, contratos, errores,
vistas y estrategia de pruebas. Cada elemento **cita hacia atrás** los IDs de la fase 01 o
de documentos PL previos que lo originan (misma "Regla de referencias" de §2); nadie cita
hacia adelante y citar = poner el ID, nunca copiar contenido.

| Código | Documento | Contiene SOLO | NO contiene (y dónde va) |
|--------|-----------|---------------|---------------------------|
| PL-00 | Clasificación auto/manual/auto-derivado | Tabla 🟢/🔵/🟣 y reglas duras de derivación (backend→arquitectura/ambiente/config) | Decisiones concretas (PL-01/PL-02), diseño |
| PL-G | Guía de la reunión de diseño | Orden del día técnico: decisiones 🔵 a tomar con menú de opciones y reglas duras | Las decisiones ya tomadas (PL-01/PL-02) |
| PL-A | Acta de decisiones de la reunión de diseño (**insumo** humano, alternativa a la transcripción; vive en `transcripciones diseno/txt/`) | Fecha, participantes, quién decidió, opción marcada por decisión y su porqué | Diseño (PL-01…PL-11); el agente no lo modifica |
| PL-J | Prompt de customer journey (para Claude) | Fases del recorrido de **nuestro cliente** (el que firma) derivadas de RQ-04/RQ-05/RQ-07 + prompt para Claude; es lo que el cliente **firma** y **acota el alcance del diseño** | El diseño visual (PL-M); roles internos del sistema (el journey es solo de nuestro cliente) |
| PL-M | Prompt de diseño visual (para Claude) | Lista de pantallas (de RQ-05/RQ-07) **acotadas a las fases del journey PL-J** + prompt para Claude con el sistema de diseño y la paleta Grupo Salinas por defecto | El código final de componentes (lo genera Claude), stack ni arquitectura |
| PL-01 | Selección de ambientes (🔵 SELECTOR, decisión del arquitecto registrada) | `AMB`: servidores front/back, BD, dev, prod, multimedia, repos, dependencias con otras áreas | Stack ni versiones (van en PL-02) |
| PL-02 | Selección de stack (🔵 SELECTOR, decisión del arquitecto registrada) | `DEC-D`: stack front/back y versiones, justificado contra los `NF` de RQ-04 | Ambientes (PL-01) |
| PL-03 | Guía de diagrama de arquitectura | Checklist de qué elementos del diagrama maestro copiar + relaciones + campo con la ruta del `.drawio` adjunto | El diagrama dibujado (lo arma el arquitecto en draw.io) |
| PL-04 | Guía de diagrama de flujos | Lista de flujos a dibujar (derivados de los `CU` de RQ-07) con pasos y decisiones + campo del `.drawio` adjunto | El diagrama dibujado (lo arma el arquitecto en draw.io) |
| PL-05 | Diccionario / modelo de datos | `ENT` y campos `CAM` (tipo, obligatorio, sensible); cita glosario de RQ-04 y `RN`/`CU` | Endpoints (PL-06) |
| PL-06 | Contrato de endpoints | `EP`: nombre, consumo, método, parámetros, respuesta JSON, códigos, propósito; cita `CU`/`RN` | Manejo de errores (PL-07) |
| PL-07 | Manejo de errores | `ERR`: catálogo de errores, códigos, formato de respuesta de error, logging | Mensajes de negocio al usuario (RQ-08) |
| PL-08 | Arquitectura back (🟣 AUTO-DERIVADA del backend elegido en PL-02; no se elige aparte) | Tecnología, arquitectura 3 capas, distribución del código a nivel de módulos y responsabilidades | Firmas exactas de métodos (fase de Tareas/Desarrollo) |
| PL-09 | Arquitectura front | Organización de componentes, estado y servicios a nivel alto | Firmas de métodos ni diseño visual de pantallas |
| PL-10 | Vistas y rutas front | `VIS` y `RUT`; supuestos (diseño propio o provisto); cita `HU`/`CU` | Lógica de negocio (RQ-06) |
| PL-11 | Estrategia de pruebas | `TPR`: tipos de prueba (unit/integ/E2E), qué no entra, criterios globales, pirámide; cita `REQ` de RQ-08 | Casos de prueba detallados (fase 05 Testing) |

La trazabilidad hacia atrás es **obligatoria**: un `EP-007` cita el `CU-003` y la `RN-012`
que satisface; una `ENT-004` cita el término del glosario de RQ-04; una `TPR-002` cita el
`REQ-005` que valida. Así la revisión de consistencia puede verificar que todo requisito
aprobado quedó cubierto por el diseño y que nada del diseño sale de la nada.

**Modelo de decisión de la fase 02.** Cada artefacto es 🟢 auto-generable (el agente lo
deriva de los requerimientos: PL-05, PL-06, PL-10), 🔵 decisión del arquitecto (se toma y
justifica en la reunión de diseño y el agente la registra con `DEC-D`: PL-01 ambientes,
PL-02 stack) o 🟣 auto-derivado (lo fija una decisión 🔵 previa por regla dura: PL-08
arquitectura según el backend, el ambiente permitido y el mecanismo de configuración). El
detalle y las reglas duras viven en PL-00. El agente no inventa tecnología ni ambiente: los
decide el arquitecto en reunión. Los artefactos 🟢 que **no dependen del stack** (PL-05
modelo de datos y PL-06 endpoints) se generan en **borrador antes de la reunión**, como
insumo para decidir el stack con los datos y las operaciones a la vista; junto con ellos se
genera el prompt de customer journey **PL-J** y el prompt de diseño visual **PL-M** (ambos
🟢) como apoyo **no bloqueante** de la reunión. El resto de 🟢 (PL-07, PL-10, PL-11) se
completa después. El número `PL-NN` es el **orden de catálogo**, no necesariamente el orden
de elaboración.

**Customer journey (PL-J) y su relación con el diseño (PL-M).** El customer journey es el
recorrido de **nuestro cliente** —el que nos hace la petición y firma el proyecto—, desde su
necesidad hasta el valor que recibe, con lo que hace, su dolor actual y qué cambia con el
sistema. Es lo que el cliente **firma** y, por tanto, **acota el alcance del diseño**: PL-M
solo cubre pantallas de las fases que están en el journey (no el flujo técnico completo).
Reglas:
> - El journey es **siempre sobre nuestro cliente** (el que firma), nunca por roles internos
>   del sistema. Ojo: nuestro cliente puede a su vez tener sus propios clientes, pero el
>   journey es sobre quien nos contrata.
> - PL-J se **elabora antes** que PL-M (el journey precede al diseño), pero **no es
>   bloqueante**: pueden mostrarse juntos en la reunión.
> - Como el journey también se produce en **Claude**, PL-J contiene las **fases derivadas**
>   (de los dolores `P` y objetivos de RQ-04, las historias de RQ-05 y los casos de uso de
>   RQ-07) **más el prompt para Claude**; el resultado (el artifact) lo pega el cliente,
>   igual que en PL-M.

La fase 02 trabaja en **dos tiempos** alrededor de la reunión de diseño: el **pre-reunión**
(Modo A: PL-00, los borradores 🟢 PL-05/PL-06/PL-M y la guía PL-G) prepara el material que se
lleva a la reunión; el **post-reunión** (Modo B) toma la **transcripción de la reunión de
diseño** (en `transcripciones diseno/txt/<COD>_reunion-diseno.txt`) o, si la reunión no se
grabó, el **acta de decisiones** (`transcripciones diseno/txt/<COD>_acta-decisiones-diseno.md`,
plantilla PL-A; ver §4) y, con lo
decidido, rellena los selectores 🔵 PL-01/PL-02 (con `DEC-D`), deriva los 🟣 (PL-08, PL-09) y
completa el resto. El agente no inventa las decisiones técnicas: las toma de esa
transcripción o acta, que debe existir como **archivo** (una tabla pegada en el chat no es
evidencia). Es el equivalente, para la fase 02, de las transcripciones de Discovery de la
fase 01.

Los marcadores (§5), el encabezado e historial (§6), los estados (§7) y el idioma (§8)
**aplican igual a la fase 02**; no se redefinen aquí. En el encabezado §6, los documentos
PL usan `Documento | PL-NN · <Nombre>` y `Elaboró | sdd-02-plan-diseno`.

---

## 3. Identificadores

- Formato: `PREFIJO-NNN` (3 dígitos). Subelementos: `PADRE.PREFIJO-NN` (2 dígitos).
- Únicos por proyecto. **Nunca se reutilizan**: si algo se elimina, su ID queda retirado.

| Prefijo | Qué identifica | Dueño | Ejemplo |
|---------|----------------|-------|---------|
| `S#` | Sesión de Discovery | RQ-03 | S1, S2 |
| `PEN` | Pendiente | RQ-03 | PEN-004 |
| `DEC` | Decisión | RQ-03 | DEC-002 |
| `SUP` | Suposición inferida en sesión | RQ-03 | SUP-001 |
| `P` | Problema | RQ-04 | P-001 |
| `OBJ` | Objetivo específico | RQ-04 | OBJ-002 |
| `INC` | Alcance incluido | RQ-04 | INC-003 |
| `EXC` | Alcance excluido | RQ-04 | EXC-001 |
| `ACT` | Actor / rol | RQ-04 | ACT-002 |
| `NF` | Límite no funcional declarado | RQ-04 | NF-001 |
| `HU` | Historia de usuario | RQ-05 | HU-007 |
| `RN` | Regla de negocio | RQ-06 | RN-012 |
| `CU` | Caso de uso | RQ-07 | CU-003 |
| `FA` / `FE` | Flujo alterno / de excepción | RQ-07 | CU-003.FE-02 |
| `REQ` | Requerimiento EARS | RQ-08 | REQ-005 |
| `CA` | Criterio de aceptación | RQ-08 | REQ-005.CA-03 |
| `AMB` | Ambiente (dev, prod, QA…) | PL-01 | AMB-002 |
| `DEC-D` | Decisión de diseño (técnica, tipo ADR) | el documento PL donde se toma | DEC-D-003 |
| `ENT` | Entidad del modelo de datos | PL-05 | ENT-004 |
| `CAM` | Campo / dato del diccionario | PL-05 | ENT-004.CAM-02 |
| `EP` | Endpoint | PL-06 | EP-007 |
| `ERR` | Error del catálogo | PL-07 | ERR-005 |
| `VIS` | Vista / pantalla | PL-10 | VIS-003 |
| `RUT` | Ruta (front) | PL-10 | RUT-003 |
| `TPR` | Tipo / estrategia de prueba | PL-11 | TPR-002 |

`DEC-D` lleva prefijo propio (distinto de las `DEC` de negocio de la minuta RQ-03) y
registra la decisión con el formato Contexto · Decisión · Alternativas · Consecuencias
(equivalente a un ADR).

**Cita de fuentes:** `RQ-02 P22` (pregunta 22 del cuestionario) · `RQ-03 S1 12:40`
(sesión 1, minuto 12:40).

---

## 4. Nombres de archivos

| Qué | Patrón | Ejemplo |
|-----|--------|---------|
| Código de proyecto | 3–5 letras mayúsculas, acordado al inicio | `MJG` |
| Documento de proyecto (fase 01) | `<COD>_RQ-NN_<nombre>.md` | `MJG_RQ-05_historias-usuario.md` |
| Documento de proyecto (fase 02) | `<COD>_PL-NN_<nombre>.md` | `MJG_PL-06_contrato-endpoints.md` |
| Documento transversal (fase 02, con letra en vez de número) | `<COD>_PL-G_guia-reunion-diseno.md` | `MJG_PL-G_guia-reunion-diseno.md` |
| Documento transversal (fase 02, con letra en vez de número) | `<COD>_PL-J_customer-journey.md` | `MJG_PL-J_customer-journey.md` |
| Documento transversal (fase 02, con letra en vez de número) | `<COD>_PL-M_prompt-diseno-visual.md` | `MJG_PL-M_prompt-diseno-visual.md` |
| Documento único de Discovery (RQ-01) | `<COD>_RQ-01_checklist-discovery.md` (sin `-S#`) | `MJG_RQ-01_checklist-discovery.md` |
| Documento por sesión (RQ-03) | `<COD>_RQ-NN_<nombre>-S#.md` | `MJG_RQ-03_minuta-discovery-S1.md` |
| Variante de prueba de un documento (experimental, no reemplaza al oficial) | `<COD>_<FASE>-NN_<nombre>-v#-prueba.md` | `MJG_PL-M_prompt-diseno-visual-v2-prueba.md` |
| Transcripción de reunión (fase 02) | `transcripciones diseno/txt/<COD>_reunion-diseno.txt` | `MJG_reunion-diseno.txt` |
| Acta de decisiones (fase 02, si no hay transcripción) | `transcripciones diseno/txt/<COD>_acta-decisiones-diseno.md` | `MJG_acta-decisiones-diseno.md` |
| Plantilla | `templates/<FASE-carpeta>/<FASE>-NN_<nombre>.md` | `templates/02-plan-diseno/PL-06_contrato-endpoints.md` |
| Skill | `.kiro/skills/<fase>-NN-<nombre>/SKILL.md` | `pl-06-contrato-endpoints` |
| Instructivo | `instructivos/<FASE-carpeta>/<FASE>-NN_<nombre>_instructivo.md` | `instructivos/02-plan-diseno/PL-06_contrato-endpoints_instructivo.md` |
| Agente de fase | `.kiro/agents/sdd-NN-<fase>.md` | `sdd-02-plan-diseno.md` |
| Ubicación de salida (fase 01) | `documentacion/01-requerimientos/` | |
| Ubicación de salida (fase 02) | `documentacion/02-plan-diseno/` | |

> Las skills se mantienen planas en `.kiro/skills/` (Kiro no las descubre en subcarpetas);
> el prefijo de fase las agrupa.

> **Variantes de prueba.** Cuando un documento ya se mostró al cliente y se quiere
> experimentar con una versión distinta **sin perder la oficial**, la variante se nombra con
> el sufijo `-v#-prueba` (p. ej. `MJG_PL-M_prompt-diseno-visual-v2-prueba.md`). La variante
> lleva en su encabezado la marca de que es experimental y **no** reemplaza al documento
> oficial hasta que el equipo lo decida; mientras tanto, el oficial conserva su nombre sin
> sufijo. Es un nombre de conveniencia para iterar; no crea un `PL-NN` nuevo en el catálogo.

Cada fase guarda sus documentos de proyecto en **su propia subcarpeta** bajo
`documentacion/` (`01-requerimientos/`, `02-plan-diseno/`, …). El `fileMatchPattern`
`documentacion/**` del frontmatter cubre todas las subcarpetas. Las plantillas y los
instructivos también se organizan en subcarpetas por fase: `templates/01-requerimientos/`
e `instructivos/01-requerimientos/` para la fase 01, y `templates/02-plan-diseno/` e
`instructivos/02-plan-diseno/` para la fase 02.

Nombres oficiales de la **fase 01** (`<nombre>`): `checklist-discovery`,
`cuestionario-discovery`, `minuta-discovery`, `documento-base`, `historias-usuario`,
`reglas-negocio`, `casos-uso`, `criterios-aceptacion-ears`.

Nombres oficiales de la **fase 02** (`<nombre>`): `clasificacion-auto-manual` (PL-00),
`guia-reunion-diseno` (PL-G), `customer-journey` (PL-J), `prompt-diseno-visual` (PL-M),
`acta-decisiones-diseno` (PL-A, insumo), `seleccion-ambientes`,
`seleccion-stack`, `diagrama-arquitectura`, `diagrama-flujos`,
`diccionario-modelo-datos`, `contrato-endpoints`, `manejo-errores`, `arquitectura-back`,
`arquitectura-front`, `vistas-rutas-front`, `estrategia-pruebas`.

Todos en minúsculas, sin acentos, palabras con guion. La skill, el instructivo y el agente
de la fase 02 siguen el mismo patrón (`pl-NN-<nombre>`, `PL-NN_<nombre>_instructivo.md`,
`sdd-02-plan-diseno.md`).

Si el usuario no ha dado el código de proyecto, **pregúntalo antes de crear archivos**.

---

## 5. Evidencia y marcadores (los únicos permitidos)

| Marcador | Cuándo |
|----------|--------|
| *(sin marca)* | Dato **confirmado**: dicho en la transcripción, el cuestionario o por el usuario en el chat |
| `[Inferido]` | Deducido del contexto; nadie lo dijo explícitamente |
| `[Propuesto]` | Sugerencia del agente para completar; requiere aceptación |
| `⚠️ POR CONFIRMAR (PEN-###): <qué falta>` | Falta información o hay contradicción entre fuentes |
| `N/A` | La sección o el campo no aplica a este proyecto |

- Todo `⚠️ POR CONFIRMAR` **debe** tener su `PEN-###` registrado en una minuta RQ-03.
- Prohibidos como marcador: `[DUDA]`, `[Por definir]`, `POR DEFINIR`, `Pendiente`,
  `Supuesto`, `No disponible`, `[Métrica por definir]` o cualquier otra variante.
  ("Supuesto" sí es válido como **categoría** de un `NF` en RQ-04.)
- Nunca inventes un dato ni conviertas un `[Inferido]` o `[Propuesto]` en decisión.
- En el checklist (RQ-01) la cobertura se marca con: ✅ Cubierto · 🟡 Parcial · ❌ Falta · N/A.
  ✅ significa que **ya se sabe la respuesta**, aunque sea negativa ("no hay fecha límite" es
  ✅); ❌ es solo cuando no se preguntó o no hubo respuesta.

---

## 6. Encabezado e historial (obligatorios en todo documento)

Al inicio:

```markdown
| Campo | Valor |
|-------|-------|
| Documento | RQ-NN · <Nombre oficial> |
| Proyecto | <Nombre del proyecto> · <COD> |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | <archivos usados, con su versión> |
```

Al final, sección `## Historial de cambios` con la tabla
`| Versión | Fecha | Cambio | Autor |`.

---

## 7. Estados del documento y cierre de pendientes

| Estado | Condición | Quién lo asigna |
|--------|-----------|-----------------|
| Draft | Tiene al menos un `⚠️ POR CONFIRMAR` | Agente |
| Pending Validation | Cero marcadores `⚠️`; listo para revisión humana | Agente |
| Validated | Revisado por PM / Analista | Persona |
| Approved | Aprobado por el responsable de la fase | Persona |

El agente **nunca** asigna `Validated` ni `Approved`.

**Cuando el usuario resuelve un pendiente con el agente:**
1. El agente reemplaza el marcador por el dato en **todos** los documentos donde aparece
   ese `PEN-###`.
2. Elimina la fila del `PEN-###` de la tabla de pendientes de la minuta.
3. Registra en el historial de cada documento tocado: `Se cierra PEN-### — <resumen>`.
4. Sube la versión (0.1 → 0.2) y recalcula el estado según la tabla de arriba.

Si un documento cambia después de `Validated` o `Approved`, regresa a `Pending Validation`.

---

## 8. Idioma

Todo en español. Palabras clave EARS en español: CUANDO, MIENTRAS, SI…ENTONCES,
DONDE, DEBERÁ.
