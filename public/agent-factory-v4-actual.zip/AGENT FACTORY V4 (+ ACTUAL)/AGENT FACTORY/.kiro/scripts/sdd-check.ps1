﻿# Revision SDD (hook PostFileSave sobre documentacion/**/*.md).
# Solo avisa: reporta lo que no cumple sdd-convenciones en el documento recien guardado.
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$raw = [Console]::In.ReadToEnd()
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')

# La ruta del archivo guardado viene en el JSON de STDIN; tambien se acepta como argumento.
$path = $args | Select-Object -First 1
if (-not $path) {
    $m = [regex]::Match($raw, '"([^"]*documentacion[\\/]+[^"]+?\.md)"')
    if ($m.Success) { $path = $m.Groups[1].Value -replace '\\\\', '\' }
}
if (-not $path) { exit 0 }
if (-not [IO.Path]::IsPathRooted($path)) { $path = Join-Path $root $path }
if (-not (Test-Path $path)) { exit 0 }

$nombre = Split-Path $path -Leaf
$doc = Get-Content $path -Raw -Encoding UTF8
$hallazgos = @()

# §4 nombre de archivo
if ($nombre -notmatch '^([A-Z]{3,5})_(RQ|PL)-(\d{2}|[A-Z])_[a-z0-9-]+?(-S\d+)?\.md$') {
    $hallazgos += "§4 nombre de archivo fuera del patron <COD>_RQ-NN_<nombre>.md / <COD>_PL-NN_<nombre>.md."
    $cod = $null
} else { $cod = $Matches[1] }

# §6 encabezado e historial
foreach ($campo in 'Documento', 'Proyecto', 'Versión', 'Estado', 'Fecha', 'Elaboró', 'Validó', 'Fuentes') {
    if ($doc -notmatch "(?m)^\|\s*$campo\s*\|") { $hallazgos += "§6 falta el campo '$campo' en el encabezado." }
}
if ($doc -notmatch '(?m)^## Historial de cambios') { $hallazgos += "§6 falta la seccion '## Historial de cambios'." }

# §7 estado vs marcadores
$estado = if ($doc -match '(?m)^\|\s*Estado\s*\|\s*\**([A-Za-z ]+?)\**\s*\|') { $Matches[1].Trim() } else { '' }
# Solo cuentan los marcadores con PEN real; las menciones del marcador en prosa no.
$marcas = ([regex]::Matches($doc, '⚠️ POR CONFIRMAR \(PEN-\d{3}\)')).Count
if ($marcas -gt 0 -and $estado -ne 'Draft') { $hallazgos += "§7 tiene $marcas marcador(es) ⚠️ pero el estado es '$estado' (debe ser Draft)." }
# Las minutas RQ-03 llevan los PEN como filas de tabla, no como marcadores.
if ($marcas -eq 0 -and $estado -eq 'Draft' -and $nombre -notmatch '_RQ-03_') { $hallazgos += "§7 no tiene marcadores ⚠️ y sigue en Draft (deberia pasar a Pending Validation)." }

# §5 cada PEN citado existe en alguna minuta RQ-03 del proyecto
if ($cod -and $nombre -notmatch '_RQ-03_') {
    $minutas = Get-ChildItem (Join-Path $root 'documentacion') -Recurse -Filter "${cod}_RQ-03_*.md" -ErrorAction SilentlyContinue
    $registrados = @{}
    foreach ($f in $minutas) {
        foreach ($m in [regex]::Matches((Get-Content $f.FullName -Raw -Encoding UTF8), 'PEN-\d{3}')) { $registrados[$m.Value] = $true }
    }
    $citados = [regex]::Matches($doc, 'PEN-\d{3}') | ForEach-Object Value | Sort-Object -Unique
    foreach ($p in $citados) { if (-not $registrados[$p]) { $hallazgos += "§5 $p no esta registrado en ninguna minuta ${cod}_RQ-03." } }
}

# Fuentes: los documentos y archivos citados existen
if ($doc -match '(?m)^\|\s*Fuentes\s*\|(.+)\|\s*$') {
    $fuentes = $Matches[1]
    foreach ($m in [regex]::Matches($fuentes, '\b([A-Z]{3,5}_(?:RQ|PL)-(?:\d{2}|[A-Z]))\b')) {
        $existe = Get-ChildItem (Join-Path $root 'documentacion') -Recurse -Filter "$($m.Value)_*.md" -ErrorAction SilentlyContinue
        if (-not $existe) { $hallazgos += "Fuentes cita $($m.Value), pero no existe el documento." }
    }
    foreach ($m in [regex]::Matches($fuentes, '`([^`]+\.(?:md|txt))`')) {
        if (-not (Test-Path (Join-Path $root $m.Groups[1].Value))) { $hallazgos += "Fuentes cita '$($m.Groups[1].Value)', pero el archivo no existe." }
    }
}

if ($hallazgos) {
    $salida = @("Revision SDD de ${nombre}: $($hallazgos.Count) hallazgo(s)") + ($hallazgos | ForEach-Object { " - $_" })
    $salida | ForEach-Object { [Console]::Out.WriteLine($_); [Console]::Error.WriteLine($_) }
    exit 1
}
exit 0
