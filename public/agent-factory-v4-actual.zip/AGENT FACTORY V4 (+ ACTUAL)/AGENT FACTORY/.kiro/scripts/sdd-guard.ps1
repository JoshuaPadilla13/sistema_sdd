﻿# Guardia SDD (hook PreToolUse sobre escrituras del agente).
# Bloquea (exit 2) las escrituras en documentacion/ que rompen sdd-convenciones:
#   §7 el agente nunca asigna Validated/Approved
#   §5 marcadores prohibidos
#   Modo B: PL-01/PL-02 sin transcripcion ni acta de la reunion de diseno
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$raw = [Console]::In.ReadToEnd()
try { $evt = $raw | ConvertFrom-Json } catch { exit 0 }

function Get-Strings($o) {
    if ($null -eq $o) { return }
    if ($o -is [string]) { $o; return }
    if ($o -is [System.Collections.IEnumerable]) { foreach ($i in $o) { Get-Strings $i }; return }
    foreach ($p in $o.PSObject.Properties) { Get-Strings $p.Value }
}

# El nombre de los campos de tool_input varia por herramienta: se buscan en todos los valores.
$vals = @(Get-Strings $evt.tool_input)
$path = $vals | Where-Object { $_ -notmatch "`n" -and $_ -match 'documentacion[\\/].+\.md$' } | Select-Object -First 1
if (-not $path) { exit 0 }
$text = ($vals | Where-Object { $_ -ne $path }) -join "`n"

$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$errores = @()

if ($text -match '\|\s*Estado\s*\|\s*\**(Validated|Approved)\**\s*\|') {
    $errores += "sdd-convenciones §7: el agente nunca asigna '$($Matches[1])'. Usa Draft o Pending Validation; Validated/Approved los pone una persona."
}

if ($text -match '\[DUDA\]|\[Por definir\]|POR DEFINIR|\[Métrica por definir\]') {
    $errores += "sdd-convenciones §5: marcador prohibido '$($Matches[0])'. Usa ⚠️ POR CONFIRMAR (PEN-###), [Inferido], [Propuesto] o N/A."
}

$nombre = Split-Path $path -Leaf
if ($nombre -match '^([A-Z]{3,5})_PL-0[12]_') {
    $cod = $Matches[1]
    $dir = Join-Path $root 'transcripciones diseno\txt'
    $insumos = @("${cod}_reunion-diseno.txt", "${cod}_acta-decisiones-diseno.md") |
        Where-Object { Test-Path (Join-Path $dir $_) }
    if (-not $insumos) {
        $errores += "Modo B: no existe 'transcripciones diseno/txt/${cod}_reunion-diseno.txt' ni '${cod}_acta-decisiones-diseno.md'. Las decisiones de PL-01/PL-02 deben venir de un archivo (plantilla templates/02-plan-diseno/PL-A_acta-decisiones-diseno.md). Pide el insumo y detente."
    }
}

if ($errores) {
    [Console]::Error.WriteLine("Guardia SDD bloqueo la escritura en ${nombre}:")
    $errores | ForEach-Object { [Console]::Error.WriteLine(" - $_") }
    exit 2
}
exit 0
