---
name: pl-01-seleccion-ambientes
description: Genera el documento PL-01 Selección de ambientes como SELECTOR de la infraestructura real (servidores front/back, BD, dev/QA/prod, recursos compartidos); la decisión se toma en la reunión de diseño y el agente la registra y valida las reglas duras de compatibilidad backend↔ambiente, asignando IDs AMB. Apunta a templates/02-plan-diseno/PL-01_seleccion-ambientes.md. Úsalo para registrar dónde se construye y despliega el proyecto.
---

# Skill — PL-01 Selección de ambientes

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
Decisiones de la reunión de diseño (PL-G), PL-00 (reglas duras), RQ-04 (`NF`), RQ-08
(`REQ` no funcionales); y el **backend decidido en PL-02**.
Plantilla `templates/02-plan-diseno/PL-01_seleccion-ambientes.md`.

## Procedimiento
1. **El agente NO infiere el ambiente.** Marca en el selector lo que el arquitecto decidió
   en la reunión (frontend, backend dev/QA, backend prod, motor BD, recursos compartidos).
   No inventa servidores fuera del catálogo real de la plantilla.
2. **VALIDA la regla dura backend ↔ ambiente** (PL-00 §3.2): p. ej. .NET Core → solo W2022
   en Dev y solo Aplicaciones en Prod; .NET Framework → W2022 o W2016 / Aplicaciones o
   Portales; Portales solo aloja .NET Framework.
3. **Si hay una combinación prohibida**, la marca como inconsistencia con
   `⚠️ POR CONFIRMAR (PEN-###)` y no la da por válida.
4. **Asigna IDs `AMB-###`** en la tabla de ambientes definidos y completa el resumen de
   selección (Dev / Prod por dimensión).

## Trazabilidad (obligatoria)
Cita el **backend de PL-02** que restringe el ambiente y los `NF` de RQ-04 (y `REQ` de
RQ-08 si aplica) que condicionan la decisión (disponibilidad, seguridad, red, infra).

## Lo que NO va aquí
Stack y versiones (PL-02, solo se referencia el backend) · arquitectura por capas
(PL-08/PL-09) · invención de servidores fuera del catálogo real.

## Checklist final
Selección marcada según la reunión · **regla de compatibilidad backend↔ambiente respetada**
(combinación prohibida marcada como inconsistencia) · IDs `AMB` asignados · resumen de
selección completo · cita el backend de PL-02 y los `NF`/`REQ` que aplican · sin datos
inventados · encabezado e historial completos.
