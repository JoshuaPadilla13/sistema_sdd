---
name: pl-09-arquitectura-front
description: Genera el documento PL-09 Arquitectura front (tecnología, organización de carpetas, componentes/módulos y responsabilidades, manejo de estado y servicios a nivel alto, sin firmas de métodos) usando templates/02-plan-diseno/PL-09_arquitectura-front.md, a partir del stack de PL-02 y la guía de arquitectura PL-03. Úsalo cuando se pida el diseño de la arquitectura del frontend.
---

# Skill — PL-09 Arquitectura front

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
PL-02 (stack front, `DEC-D`), PL-03 (elementos de arquitectura).
Plantilla `templates/02-plan-diseno/PL-09_arquitectura-front.md`.

## Procedimiento
1. **Tecnología:** resume el stack front aplicable (citando PL-02), sin repetir versiones.
2. **Organización de carpetas:** estructura del proyecto front y qué contiene cada
   carpeta.
3. **Componentes/módulos y responsabilidades:** qué hace cada componente o módulo a nivel
   de responsabilidad.
4. **Manejo de estado y servicios:** cómo se gestiona el estado y cómo se consumen los
   servicios/API, a nivel alto.
5. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Regla clave: nivel alto, SIN firmas de métodos
Se queda en organización, componentes, estado y servicios. **No** escribas firmas de
métodos ni el diseño visual de pantallas: las vistas y rutas son de PL-10.

## Trazabilidad (obligatoria)
Cita el stack/`DEC-D` de PL-02 que fundamenta la arquitectura front.

## Lo que NO va aquí
Firmas de métodos ni código · diseño visual de pantallas y rutas (PL-10) · arquitectura
back (PL-08) · lógica de negocio (RQ-06).

## Checklist final
Tecnología citada de PL-02 · organización de carpetas · componentes/módulos con
responsabilidades · manejo de estado y servicios a nivel alto · SIN firmas de métodos ni
diseño de pantallas · encabezado e historial completos.
