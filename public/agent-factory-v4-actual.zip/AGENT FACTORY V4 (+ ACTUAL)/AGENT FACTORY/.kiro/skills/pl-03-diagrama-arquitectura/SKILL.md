---
name: pl-03-diagrama-arquitectura
description: Genera el documento PL-03 Guía de diagrama de arquitectura (checklist de qué elementos del diagrama maestro copiar y cómo se conectan, más el campo del .drawio adjunto) usando templates/02-plan-diseno/PL-03_diagrama-arquitectura.md, a partir de los ambientes de PL-01 y el stack de PL-02. Úsalo cuando se necesite especificar qué debe dibujar el arquitecto en el diagrama de arquitectura.
---

# Skill — PL-03 Guía de diagrama de arquitectura

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
PL-01 (`AMB`), PL-02 (stack y `DEC-D`).
Plantilla `templates/02-plan-diseno/PL-03_diagrama-arquitectura.md`.

## Regla clave: el agente NO dibuja
Este documento **no** genera el diagrama (ni Mermaid ni XML de draw.io). El arquitecto lo
arma copiando del diagrama maestro los elementos que apliquen. La skill produce una
**guía/checklist** de qué copiar y cómo se conecta, y deja el campo para referenciar el
`.drawio` que el arquitecto adjunta.

## Procedimiento
1. **Elementos a incluir:** lista cada elemento del diagrama maestro que aplica
   (servidores front/back, BD, balanceador, almacenamiento, servicios externos) según el
   stack de PL-02 y los ambientes de PL-01. Para cada uno, marca "incluir" y justifica
   ("porque el stack es X" / "porque hay ambiente Y").
2. **Relaciones:** especifica cómo se conectan los elementos (origen, destino, tipo de
   conexión).
3. **Diagrama adjunto:** deja el campo con la ruta/nombre del `.drawio` que dibujará el
   arquitecto. Si aún no existe: `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada elemento justifica su inclusión citando el `AMB` de PL-01 o la tecnología/`DEC-D` de
PL-02 que lo motiva.

## Lo que NO va aquí
El diagrama dibujado (lo hace el arquitecto en draw.io) · Mermaid ni XML autogenerado ·
flujos de proceso (PL-04) · diseño de capas del código (PL-08/PL-09).

## Checklist final
NO dibuja: solo especifica qué copiar · elementos justificados contra PL-01/PL-02 ·
relaciones definidas · campo del `.drawio` adjunto presente · sin Mermaid ni XML ·
encabezado e historial completos.
