---
name: pl-m-prompt-diseno-visual
description: Genera el documento PL-M Prompt de diseño visual (para Claude), que lista las pantallas del proyecto (derivadas de las historias RQ-05 y los casos de uso RQ-07) y arma el prompt para que Claude genere el sistema de diseño y los mockups, con la paleta de Grupo Salinas por defecto. Usa templates/02-plan-diseno/PL-M_prompt-diseno-visual.md. Úsalo para preparar el diseño visual antes de la reunión de diseño, como material de apoyo.
---

# Skill — PL-M Prompt de diseño visual (para Claude)

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

> Documento **🟢 auto-generable**. Se produce en BORRADOR **antes de la reunión de diseño**,
> como apoyo (pantallas concretas a la vista), pero **no la bloquea**: el diseño visual no
> depende del stack. El diseño "bonito" lo genera Claude con este prompt; aquí solo se
> arma el prompt y se listan las pantallas.

## Insumos
RQ-05 (`HU`), RQ-07 (`CU`), y PL-10 (`VIS`) si ya existe.
Plantilla `templates/02-plan-diseno/PL-M_prompt-diseno-visual.md`.

## Procedimiento
1. **Lista las pantallas** del proyecto a partir de las historias (RQ-05) y los casos de uso
   (RQ-07): nombre, propósito y origen (`HU`/`CU`/`VIS`). Una pantalla por fila.
2. **Arma el prompt para Claude** usando la plantilla: incluye el sistema de diseño completo
   (principios, tokens, componentes, layout, convenciones) y la **lista de pantallas** de la
   sección 1.
3. **Paleta por defecto Grupo Salinas:** deja la paleta GS tal cual (amarillo `#FFCD00`,
   gris `#5E5E61` y los neutros) salvo que el proyecto/cliente indique otra identidad. Si el
   cliente trae su paleta, sustitúyela manteniendo la estructura de tokens y márcala
   `[Propuesto]` hasta validar.
4. **No inventes contenido de negocio** en el prompt: mantenlo en el sistema de diseño y las
   pantallas reales del proyecto. Lo no confirmado usa `[Propuesto]` o
   `⚠️ POR CONFIRMAR (PEN-###)`.
5. Deja la sección de ajustes para registrar lo que surja en validación/reunión (deben ser
   ajustes, no rediseño).

## Trazabilidad (obligatoria)
Cada pantalla listada cita la `HU` (RQ-05), el `CU` (RQ-07) o la `VIS` (PL-10) que la origina.

## Lo que NO va aquí
Stack ni arquitectura (PL-02 / PL-08 / PL-09) · lógica de negocio (RQ-06) · el código final
de los componentes (lo genera Claude a partir del prompt) · endpoints (PL-06).

## Checklist final
Pantallas listadas con su origen `HU`/`CU`/`VIS` · prompt completo (principios, tokens,
componentes, layout, convenciones) · paleta Grupo Salinas por defecto (o la del cliente,
marcada) · es apoyo no bloqueante de la reunión · lo no confirmado marcado · encabezado e
historial completos.
