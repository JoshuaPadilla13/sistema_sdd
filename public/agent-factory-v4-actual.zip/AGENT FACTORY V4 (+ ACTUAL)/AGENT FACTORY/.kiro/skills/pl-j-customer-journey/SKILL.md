---
name: pl-j-customer-journey
description: Genera el documento PL-J Prompt de customer journey (para Claude), que deriva las fases del recorrido de NUESTRO CLIENTE (el que firma el proyecto) a partir de los problemas y objetivos de RQ-04, las historias RQ-05 y los casos de uso RQ-07, y arma el prompt para que Claude genere el customer journey map que el cliente firma. Es lo que acota el alcance del diseño PL-M. Usa templates/02-plan-diseno/PL-J_customer-journey.md. Úsalo antes del diseño visual, como material para cerrar acuerdos con el cliente.
---

# Skill — PL-J Prompt de customer journey (para Claude)

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

> Documento **🟢 auto-generable**. El customer journey es el recorrido de **NUESTRO CLIENTE**
> —el que nos hace la petición y firma el proyecto—, de su necesidad al valor que recibe. Es
> lo que el cliente **firma** y, por eso, **acota el alcance del diseño** (PL-M solo cubre
> pantallas de las fases de este journey). Se elabora **antes** que PL-M, como apoyo **no
> bloqueante**. El journey "bonito" lo genera Claude con este prompt; aquí solo se derivan las
> fases y se arma el prompt.

## Regla clave: de quién es el journey
El journey es **siempre sobre nuestro cliente** (el que firma), **nunca por roles internos**
del sistema. Ojo: nuestro cliente puede a su vez tener sus propios clientes/audiencia, pero
el mapa es sobre quien nos contrata. No confundas "el cliente del sistema" (un rol interno)
con "nuestro cliente" (quien firma el proyecto).

## Insumos
RQ-04 (problemas `P`, objetivos), RQ-05 (`HU`), RQ-07 (`CU`).
Plantilla `templates/02-plan-diseno/PL-J_customer-journey.md`.

## Procedimiento
1. **Deriva las fases** del recorrido de nuestro cliente, en orden, de la necesidad al valor.
   Por fase registra: qué hace el cliente, su **dolor de hoy** (de los `P` de RQ-04), **qué
   cambia** con el sistema (de los objetivos/INC), el estatus relacionado (RQ-07) si aplica,
   los **momentos de la verdad** (⭐) y las **bifurcaciones** (urgencia, fuera de tiempo,
   regreso a una mesa, excepción).
2. **Arma el prompt para Claude** con la plantilla: incluye la regla de "de quién es el
   journey", qué debe mostrar el mapa, la propuesta visual (no genérica, con marca) y el
   contenido de las fases de la sección 1.
3. **Paleta por defecto Grupo Salinas** salvo que el cliente indique otra; si la trae,
   sustitúyela manteniendo la estructura y márcala `[Propuesto]`.
4. **No inventes** fases ni dolores: derívalos de RQ-04/RQ-05/RQ-07. Lo no confirmado usa
   `[Inferido]`, `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.
5. Deja la sección de ajustes para lo que surja al validar/firmar con el cliente.

## Relación con PL-M (acota el diseño)
El diseño visual (PL-M) cubre **solo** las fases de este journey donde el cliente tiene una
pantalla o acción. Al generar PL-M, se citan las fases de PL-J. Las fases previas al sistema
(p. ej. "Necesidad") no generan pantalla.

## Trazabilidad (obligatoria)
Cada fase cita el `P`/objetivo de RQ-04, la `HU` de RQ-05 o el `CU` de RQ-07 que la origina.

## Lo que NO va aquí
El diseño visual de pantallas (PL-M) · journeys por roles internos del sistema · stack ni
arquitectura · lógica de negocio (RQ-06).

## Checklist final
Journey de nuestro cliente (no por roles) · fases en orden con "lo que hace / dolor / qué
cambia" · momentos de la verdad y bifurcaciones marcados · cada fase con su origen de RQ · es
apoyo no bloqueante y precede a PL-M · prompt completo para Claude · lo no confirmado marcado ·
encabezado e historial completos.
