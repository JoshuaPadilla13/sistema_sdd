---
name: pl-07-manejo-errores
description: Genera el documento PL-07 Manejo de errores (estrategia general, catálogo de errores ERR con código HTTP/interno y mensaje de log, formato estándar de respuesta de error JSON y política de logging) usando templates/02-plan-diseno/PL-07_manejo-errores.md, a partir de RQ-08 y el contrato de endpoints PL-06. Úsalo cuando se pida el enfoque técnico de manejo de errores del proyecto.
---

# Skill — PL-07 Manejo de errores

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-08 (`REQ`, criterios de validación), PL-06 (`EP`, códigos).
Plantilla `templates/02-plan-diseno/PL-07_manejo-errores.md`.

## Procedimiento
1. **Estrategia general:** cómo se capturan, clasifican y propagan los errores (por capa /
   middleware), a nivel técnico.
2. **Catálogo de errores (`ERR`):** por cada error define código HTTP, código interno y
   mensaje técnico para el log. Agrupa validación, autenticación/autorización, negocio e
   infraestructura.
3. **Formato estándar de respuesta de error (JSON):** estructura única que devuelven todos
   los `EP` ante un error (p. ej. `codigo`, `mensaje`, `detalle`, `traceId`).
4. **Política de logging:** qué se registra por nivel (ERROR, WARN, INFO) y qué datos
   **nunca** se loguean (datos sensibles marcados en PL-05).
5. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Los errores de validación citan el `REQ`/`NF` de RQ-08 que les da origen; los `ERR`
asociados a un endpoint citan el `EP` de PL-06 donde aplican.

## Lo que NO va aquí
Mensajes de negocio que ve el usuario final (esos son de RQ-08; aquí es el manejo técnico y
el mensaje de log) · definición de endpoints (PL-06) · código de los handlers (fase de
Tareas/Desarrollo).

## Checklist final
Estrategia general definida · catálogo `ERR` con código HTTP, código interno y mensaje de
log · formato JSON de error único · política de logging por nivel sin datos sensibles ·
errores de validación citan `REQ`/`NF` · encabezado e historial completos.
