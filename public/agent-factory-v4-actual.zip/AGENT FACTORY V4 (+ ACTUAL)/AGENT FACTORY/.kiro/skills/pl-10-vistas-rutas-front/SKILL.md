---
name: pl-10-vistas-rutas-front
description: Genera el documento PL-10 Especificación de vistas y rutas (front) (VIS y RUT con acceso por rol, declarando si el diseño es propio o provisto por el cliente) usando templates/02-plan-diseno/PL-10_vistas-rutas-front.md, a partir de la arquitectura front PL-09, las historias RQ-05 y los casos de uso RQ-07. Úsalo cuando se pida el listado de pantallas y rutas del frontend.
---

# Skill — PL-10 Especificación de vistas y rutas (front)

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
PL-09 (arquitectura front), RQ-05 (`HU`), RQ-07 (`CU`), RQ-04 (`ACT`).
Plantilla `templates/02-plan-diseno/PL-10_vistas-rutas-front.md`.

## Procedimiento
1. **Declara el supuesto de diseño:** si el diseño visual es propio del equipo o provisto
   por el cliente. Si no está confirmado: `⚠️ POR CONFIRMAR (PEN-###)`.
2. **Vistas (`VIS`):** una por pantalla del sistema; descríbela a nivel de propósito, no de
   diseño visual detallado.
3. **Rutas (`RUT`):** la ruta que lleva a cada vista.
4. **Acceso por rol:** indica qué `ACT` de RQ-04 puede entrar a cada vista/ruta.
5. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada `VIS` cita la `HU` de RQ-05 y/o el `CU` de RQ-07 que atiende; cada `RUT` cita su
`VIS`; el acceso por rol cita el `ACT` de RQ-04.

## Lo que NO va aquí
Lógica de negocio (RQ-06) · diseño visual detallado (maquetas, colores, tipografías) ·
componentes y manejo de estado (PL-09) · endpoints (PL-06).

## Checklist final
Supuesto de diseño declarado · cada `VIS` cita `HU`/`CU` · cada `RUT` cita su `VIS` ·
acceso por rol con `ACT` · sin lógica de negocio ni diseño visual detallado · encabezado e
historial completos.
