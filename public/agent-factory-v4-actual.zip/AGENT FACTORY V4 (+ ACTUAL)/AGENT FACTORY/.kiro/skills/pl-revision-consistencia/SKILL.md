---
name: pl-revision-consistencia
description: Revisa que los documentos PL-01 a PL-11 de un proyecto sean consistentes entre sí y con la fase 01 (IDs, referencias, cobertura RQ→PL, información fuera de lugar, marcadores, estados y nombres de archivo) y reporta hallazgos en el chat. Úsalo al terminar PL-11, después de propagar cambios de la fase 01, o cuando se pida validar la fase de Plan/Diseño.
---

# Skill — Revisión de consistencia de la fase 02

Aplica las convenciones de `sdd-convenciones`. Esta skill **no crea documentos** ni
corrige nada por su cuenta: reporta en el chat y propone correcciones. Solo las aplica
si el usuario lo pide.

## Verificaciones

**1. Cobertura RQ→PL (clave)**
Todo requisito aprobado de Fase 01 debe estar cubierto por el diseño. En concreto:
- Todo `CU` de RQ-07 con operaciones de sistema tiene al menos un `EP` en PL-06.
- Todo `REQ` de RQ-08 tiene al menos un `TPR` en PL-11.
- Los términos del glosario / entidades relevantes tienen su `ENT` en PL-05.
- Cada `NF` de RQ-04 que condiciona tecnología o ambiente está reflejado en PL-01/PL-02.

Señala lo no cubierto.

**2. Diseño sin origen**
Todo elemento PL (`EP`, `ENT`, `VIS`, `RUT`, `TPR`, etc.) debe citar un origen válido de
Fase 01 o de un PL previo. Señala los elementos sin origen o con origen inexistente.

**3. Referencias**
- Todo ID citado existe en su documento dueño.
- Nadie cita hacia adelante (un PL no cita un PL de número mayor ni la Fase 01 cita PL).
- Sin IDs duplicados, reutilizados ni con formato distinto a `PREFIJO-NNN` (o
  `PADRE.PREFIJO-NN`).

**4. Información fuera de lugar**
Aplica la matriz de `sdd-convenciones` §2.bis. Señala, por ejemplo: firmas de métodos o
código en PL-08/PL-09 · el diagrama dibujado/Mermaid/XML dentro de PL-03/PL-04 (deben ser
guía + `.drawio` adjunto) · mensajes de negocio al usuario en PL-07 (son de RQ-08) · stack
dentro de PL-01 o ambientes dentro de PL-02 · catálogo de errores dentro de PL-06 (es de
PL-07).

**5. Marcadores y pendientes**
- Solo los marcadores permitidos.
- Cada `⚠️ POR CONFIRMAR (PEN-###)` tiene su fila en una minuta RQ-03.

**6. Contradicciones**
El mismo dato con valores distintos entre documentos PL o entre PL y RQ (versiones de
stack, tipos de un campo, códigos de un endpoint, roles de una ruta).

**7. Estados, versiones y nombres**
El estado corresponde a §7 · el historial refleja los cambios · los nombres de archivo
siguen §4 (`<COD>_PL-NN_<nombre>.md`).

## Formato del reporte

| # | Severidad | Documento | Hallazgo | Corrección propuesta |
|---|-----------|-----------|----------|----------------------|

Severidad: **Bloqueante** (rompe trazabilidad o contradice) · **Mayor** (información fuera
de lugar, cobertura incompleta, diseño sin origen) · **Menor** (formato).

Cierra con un veredicto: **Lista para validación** (sin bloqueantes) o **No lista**.
