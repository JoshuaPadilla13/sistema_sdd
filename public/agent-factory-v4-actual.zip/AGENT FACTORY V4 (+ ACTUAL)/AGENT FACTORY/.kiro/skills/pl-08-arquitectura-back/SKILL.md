---
name: pl-08-arquitectura-back
description: Genera el documento PL-08 Arquitectura back, que es AUTO-DERIVADA del backend elegido en PL-02 (regla dura de PL-00); el agente aplica la derivación y documenta la arquitectura resultante (capas, estructura de carpetas y responsabilidades) a nivel alto, sin firmas de métodos, e incluye siempre la sección de Monitoreo/Health Check. Apunta a templates/02-plan-diseno/PL-08_arquitectura-back.md. Úsalo para el diseño de la arquitectura del backend.
---

# Skill — PL-08 Arquitectura back

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
PL-02 (backend decidido, `DEC-D`), PL-00 (regla dura de derivación), PL-03 (elementos de
arquitectura), PL-06 (`EP`).
Plantilla `templates/02-plan-diseno/PL-08_arquitectura-back.md`.

## Procedimiento
1. **Lee el backend de PL-02.** La arquitectura no se elige aquí: la determina ese backend.
2. **Aplica la regla de derivación** (PL-00 §3.1):
   - .NET Core (.NET 8) → **Opción A**: orientada a servicios, proyecto único
     (Controladores → Interfaces de Servicios → Servicios).
   - .NET Framework 4.8 → **Opción B**: 3 capas multi-proyecto (DAL/DLL → BLL →
     Microservicio).
   - .NET Framework legacy GS → **Opción C**: 3 capas variante legacy (al extender un
     servicio existente de GS).
3. **Documenta la arquitectura resultante a nivel alto:** capas, estructura de
   carpetas/módulos y responsabilidades por módulo. Describe el flujo de una petición.
4. **Incluye SIEMPRE la sección de Monitoreo/Health Check** (requisito transversal): endpoint
   de salud, diagnóstico de conexión a BD y de dependencias externas, sin exponer datos
   sensibles.
5. **Registra `DEC-D` breves** para las decisiones de arquitectura que lo ameriten.

## Regla clave: nivel alto, SIN firmas de métodos
Se queda en capas, módulos y responsabilidades. **No** escribas firmas de métodos
(nombre + parámetros + retorno) ni código: eso es de la fase de Tareas/Desarrollo.

## Trazabilidad (obligatoria)
Cita el **backend / `DEC-D` de PL-02** que fundamenta la arquitectura derivada y los `EP`
de PL-06 que la capa de API expone.

## Lo que NO va aquí
Firmas de métodos ni código · la elección de backend (ya está en PL-02) · arquitectura
front (PL-09) · modelo de datos (PL-05) · catálogo de errores (PL-07).

## Checklist final
Backend leído de PL-02 · **arquitectura coherente con el backend** (Opción A/B/C aplicada) ·
capas, carpetas y responsabilidades a nivel alto · **sección de Monitoreo/Health Check
presente** · `DEC-D` breves · **SIN firmas de métodos** ni código · cita backend/`DEC-D` de
PL-02 y `EP` de PL-06 · encabezado e historial completos.
