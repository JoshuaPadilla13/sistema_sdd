---
name: pl-g-guia-reunion-diseno
description: Genera el documento PL-G Guía de la reunión de diseño (orden del día técnico con el menú de decisiones del arquitecto y las reglas duras de compatibilidad) usando templates/02-plan-diseno/PL-G_guia-reunion-diseno.md, a partir de los documentos aprobados de la Fase 01. Úsalo para preparar la reunión donde el arquitecto decide y justifica la arquitectura.
---

# Skill — PL-G Guía de la reunión de diseño

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-04…RQ-08 **aprobados** (estado `Approved`), PL-00 (clasificación y reglas duras) y el
**borrador de PL-05** (modelo de datos) y **PL-06** (contrato de endpoints), ya generados,
que se incluyen como material de la reunión para que el stack se decida con los datos y las
operaciones a la vista.
Plantilla `templates/02-plan-diseno/PL-G_guia-reunion-diseno.md`.

## Procedimiento
1. **Llena el checklist "antes de la reunión"** verificando que RQ-04…RQ-08 estén en estado
   `Approved` y sin `PEN` críticos abiertos. Si alguno no cumple, lo marca y no da la
   reunión por lista.
2. **Lista las decisiones 🔵 a tomar** con el menú de opciones reales (backend, acceso a
   datos, motor BD, auth, esquema, despliegue, ambientes) y las reglas duras de
   compatibilidad como apoyo.
3. **Deja el espacio para registrar, por decisión, qué se eligió y por qué** (Contexto ·
   Alternativas · Consecuencias). No marca opciones: eso lo hace el arquitecto en la reunión.
4. Es el **puente** entre la Fase 01 aprobada y los selectores (PL-01, PL-02) y sus
   derivaciones 🟣.

## Trazabilidad (obligatoria)
Las Fuentes citan los documentos aprobados de la Fase 01 (RQ-04…RQ-08) con su versión;
el menú de decisiones referencia las reglas duras de PL-00.

## Lo que NO va aquí
Las decisiones ya tomadas (eso se registra en PL-01/PL-02 tras la reunión) · stack con
versiones · arquitectura derivada (PL-08).

## Checklist final
Checklist "antes de la reunión" con estados `Approved` verificados · menú de decisiones 🔵
con opciones reales · reglas duras de compatibilidad presentes · espacio para qué+porqué de
cada decisión · sin decisiones ya marcadas · encabezado e historial completos.
