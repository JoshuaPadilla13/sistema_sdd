---
name: pl-11-estrategia-pruebas
description: Genera el documento PL-11 Estrategia de pruebas (tipos de prueba TPR unitaria/integración/E2E con alcance y herramienta, qué no entra, criterios de aceptación globales y pirámide de pruebas) usando templates/02-plan-diseno/PL-11_estrategia-pruebas.md, a partir de los requerimientos de RQ-08, el modelo de datos PL-05 y el contrato de endpoints PL-06. Úsalo cuando se pida la estrategia o el enfoque de pruebas del proyecto.
---

# Skill — PL-11 Estrategia de pruebas

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).
Guía extendida para personas: `instructivos/02-plan-diseno/PL-11_estrategia-pruebas_instructivo.md`.

## Insumos
RQ-08 (`REQ`), PL-05 (`ENT`), PL-06 (`EP`).
Plantilla `templates/02-plan-diseno/PL-11_estrategia-pruebas.md`.

## Procedimiento
1. **Tipos de prueba (`TPR`):** unitaria, integración y E2E. Por cada tipo define su
   alcance (qué cubre) y la herramienta/framework.
2. **Qué NO entra en pruebas:** acota explícitamente lo que queda fuera de esta estrategia.
3. **Criterios de aceptación globales:** umbrales que debe cumplir el proyecto para darse
   por probado (cobertura mínima, pruebas verdes, etc.).
4. **Pirámide de pruebas:** proporción esperada entre unitarias, integración y E2E.
5. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada `TPR` cita los `REQ` de RQ-08 que cubre (y puede referenciar las `ENT` de PL-05 o los
`EP` de PL-06 sobre los que se ejecuta). La revisión de consistencia usa esto para
verificar que todo `REQ` quede cubierto por algún `TPR`.

## Lo que NO va aquí
Casos de prueba detallados y scripts (fase 05 Testing) · criterios EARS reescritos (viven
en RQ-08) · configuración de CI/CD (fase de Deploy).

## Checklist final
`TPR` unitaria/integración/E2E con alcance y herramienta · qué NO entra definido ·
criterios globales · pirámide · cada `TPR` cita sus `REQ` de RQ-08 · sin casos de prueba
detallados · encabezado e historial completos.
