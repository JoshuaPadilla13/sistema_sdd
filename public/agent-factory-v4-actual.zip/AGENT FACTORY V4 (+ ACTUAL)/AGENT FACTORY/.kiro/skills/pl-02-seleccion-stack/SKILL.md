---
name: pl-02-seleccion-stack
description: Genera el documento PL-02 Selección de stack como SELECTOR de 8 pasos (frontend fijo React, backend, acceso a datos, motor BD, auth, esquema, despliegue, ambiente) decidido en la reunión de diseño; el agente registra cada decisión como DEC-D tipo ADR y recuerda que el backend determina PL-08, el ambiente permitido y el mecanismo de config. Apunta a templates/02-plan-diseno/PL-02_seleccion-stack.md. Úsalo para registrar con qué tecnologías se construye el proyecto.
---

# Skill — PL-02 Selección de stack

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
Decisiones de la reunión de diseño (PL-G), PL-00 (clasificación y reglas duras), PL-01
(ambientes), RQ-04 (`NF` declarados).
Plantilla `templates/02-plan-diseno/PL-02_seleccion-stack.md`.

## Procedimiento
1. **Marca lo decidido en cada uno de los 8 pasos** (Paso 1 frontend React es fijo; Paso 2
   backend; 3 acceso a datos; 4 motor BD; 5 autenticación; 6 esquema; 7 despliegue; 8
   ambiente destino). El agente no re-decide: registra lo acordado en la reunión.
2. **Por cada decisión relevante escribe un `DEC-D`** con el formato tipo ADR:
   Contexto · Decisión · Alternativas · Consecuencias. El porqué lo aporta el arquitecto en
   la reunión; el agente lo captura, no lo inventa.
3. **Recuerda que el backend elegido DETERMINA** la arquitectura (PL-08, auto-derivada), el
   ambiente permitido (PL-01) y el mecanismo de configuración. El agente no re-decide esas
   derivaciones aquí: solo deja claro que quedan fijadas por el backend (regla dura PL-00).
4. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada elección se justifica contra un `NF` de RQ-04 cuando aplique; cada `DEC-D` referencia
el `NF`, el `AMB` de PL-01 o el contexto de la reunión que la motiva.

## Lo que NO va aquí
Ambientes (PL-01, solo se resumen en el Paso 8) · arquitectura back (PL-08, auto-derivada
del backend) · diseño de capas y módulos.

## Checklist final
Los 8 pasos marcados según la reunión · un `DEC-D` por decisión relevante con
Contexto/Decisión/Alternativas/Consecuencias · se indica que el backend determina PL-08,
ambiente y config · cada elección cita su `NF`/`AMB` cuando aplica · lo no confirmado
marcado · encabezado e historial completos.
