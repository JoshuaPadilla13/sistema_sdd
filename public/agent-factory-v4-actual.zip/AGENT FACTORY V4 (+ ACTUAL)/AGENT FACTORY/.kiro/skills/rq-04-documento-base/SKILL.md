---
name: rq-04-documento-base
description: Genera el documento RQ-04 Documento base del proyecto (título, problemas, objetivos, alcance incluido y excluido, actores, límites no funcionales y glosario) usando templates/01-requerimientos/RQ-04_documento-base.md. Úsalo como primer documento de la etapa de documentación, cuando ya no hay pendientes críticos de Discovery.
---

# Skill — RQ-04 Documento base del proyecto

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-02 (Partes 1–4 y 9) y las minutas RQ-03. Plantilla `templates/01-requerimientos/RQ-04_documento-base.md`.

## Procedimiento
1. **Título:** máximo 10 palabras; que se entienda qué es sin leer el resto. Sin siglas
   sin explicar.
2. **Problemas (`P-###`):** de 2 a 5, ordenados por importancia. Describen la situación
   (qué pasa, a quién afecta, consecuencia, evidencia), **no la solución**. Si empieza
   con "Falta un sistema para…", reescríbelo.
3. **Objetivos:** 1 general y de 2 a 5 específicos (`OBJ-###`), en infinitivo, cada uno
   ligado a al menos un `P`. Son resultados, no actividades ("crear un dashboard" es
   actividad; "reducir a minutos la consulta" es objetivo). Sin métrica:
   `⚠️ POR CONFIRMAR (PEN-###): indicador`.
4. **Incluido (`INC-###`):** cada capacidad ligada a un `OBJ`. Lo dudoso no va aquí:
   genera un `PEN`.
5. **Excluido (`EXC-###`):** lo que el cliente dejó fuera explícitamente. Si no dijo nada:
   `⚠️ POR CONFIRMAR`.
6. **Actores (`ACT-###`):** cada rol que usa el sistema (RQ-02 Parte 4). Los permisos
   detallados son reglas de autorización de RQ-06, no van aquí.
7. **Límites no funcionales (`NF-###`):** solo **declara** la restricción o condición
   (rendimiento, seguridad, usabilidad, disponibilidad, mantenibilidad, restricciones,
   supuestos). Usa el valor si el cliente lo dio; no redactes criterios EARS (eso es
   RQ-08). Omite las categorías que no apliquen.
8. **Glosario:** términos del dominio que se usarán en los demás documentos, con
   definición de una oración. Los estados de las entidades no van aquí, van en RQ-07.

## Lo que NO va aquí
Criterios verificables, reglas de negocio, flujos, historias, diseño o tecnología
(salvo como restricción declarada del cliente, en `NF`).

## Checklist final
Problemas sin solución · cada `OBJ` cita un `P` · cada `INC` cita un `OBJ` · Excluido no
vacío · `NF` declarados sin EARS · glosario presente · sin datos inventados · encabezado e
historial completos.
