---
name: pl-05-diccionario-modelo-datos
description: Genera el documento PL-05 Diccionario de datos, modelo de datos e interfaces (entidades ENT y campos CAM con tipo, obligatorio y sensible, y relaciones) usando templates/02-plan-diseno/PL-05_diccionario-modelo-datos.md, a partir del glosario de RQ-04, las reglas de RQ-06 y los casos de uso de RQ-07. Úsalo cuando se pida el modelo de datos o el diccionario de datos del proyecto.
---

# Skill — PL-05 Diccionario de datos, modelo de datos e interfaces

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).
Guía extendida para personas: `instructivos/02-plan-diseno/PL-05_diccionario-modelo-datos_instructivo.md`.

> **Secuencia:** este documento es 🟢 auto-generable (se deriva de los requerimientos y no
> depende del stack) y se produce en **BORRADOR antes de la reunión de diseño**, como
> insumo para ella (la reunión decide el stack viendo ya los datos). Se ajusta después si
> una decisión de la reunión lo amerita.

## Insumos
RQ-04 (glosario), RQ-06 (`RN`), RQ-07 (`CU`).
Plantilla `templates/02-plan-diseno/PL-05_diccionario-modelo-datos.md`.

## Procedimiento
1. **Entidades (`ENT`):** una por concepto del dominio que persiste el sistema. Deriva del
   glosario de RQ-04 y de los `CU` de RQ-07.
2. **Campos (`CAM`) por entidad:** `ENT-###.CAM-##`, con tipo de dato, obligatorio
   (sí/no), **sensible** (sí/no, para datos personales o protegidos) y descripción.
3. **Marca los datos sensibles** explícitamente (afectan a PL-07 y a la estrategia de
   seguridad).
4. **Relaciones entre entidades:** entidad origen, tipo de relación, entidad destino.
5. Lo no confirmado usa `[Inferido]`, `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada `ENT` cita el término del glosario de RQ-04 o el `CU` de RQ-07 que la origina. Cada
campo que esté sujeto a una regla cita la `RN` de RQ-06 que aplica (p. ej. validación de
formato o unicidad).

## Lo que NO va aquí
Endpoints (PL-06) · manejo de errores (PL-07) · firmas de métodos o DTOs de código (fase
de Tareas/Desarrollo) · mensajes al usuario (RQ-08).

## Checklist final
Cada `ENT` cita glosario/`CU` · campos con tipo, obligatorio y sensible · datos sensibles
marcados · reglas citadas con `RN` · relaciones definidas · sin endpoints · encabezado e
historial completos.
