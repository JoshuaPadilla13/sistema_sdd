---
name: rq-08-criterios-aceptacion-ears
description: Genera el documento RQ-08 Criterios de aceptación EARS (REQ-### con criterios REQ-###.CA-##) en español, usando templates/01-requerimientos/RQ-08_criterios-aceptacion-ears.md, a partir de historias, reglas, casos de uso y límites no funcionales. Úsalo cuando se pidan criterios de aceptación o requerimientos EARS. Es el último documento de la fase 01.
---

# Skill — RQ-08 Criterios de aceptación EARS

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).
Guía extendida para personas: `instructivos/01-requerimientos/RQ-08_criterios-aceptacion-ears_instructivo.md`.

## Insumos
RQ-04 (`NF`, glosario), RQ-05 (`HU`), RQ-06 (`RN`), RQ-07 (`CU`, `FA`, `FE`, estados).
Plantilla `templates/01-requerimientos/RQ-08_criterios-aceptacion-ears.md`.

## Reglas que nunca se rompen
1. Todo criterio termina en **"el sistema DEBERÁ [acción observable]"**.
2. Un criterio = una sola respuesta verificable ("guardar y notificar" son dos criterios).
3. Sin palabras vagas ("debería", "podría", "rápido", "fácil", "correctamente"). Valores
   exactos.
4. Comportamiento, no implementación (sin endpoints, tablas, librerías, cron).
5. Mensajes al usuario entre comillas y con el texto exacto. Este documento es el **único**
   dueño de los mensajes. Si el cliente no los dio: `[Propuesto]` o
   `⚠️ POR CONFIRMAR (PEN-###)`.
6. El sujeto siempre es "el sistema"; el actor va dentro de la condición.
7. Nunca Gherkin (Dado/Cuando/Entonces) ni palabras clave en inglés.

## Patrones EARS

| Situación | Patrón | Forma |
|-----------|--------|-------|
| Siempre, sin condición | Ubicuo | El sistema DEBERÁ [respuesta]. |
| La dispara un evento | Evento | CUANDO [evento], el sistema DEBERÁ [respuesta]. |
| Depende de un estado | Estado | MIENTRAS [estado], el sistema DEBERÁ [respuesta]. |
| Validación, error o caso límite | No deseado | SI [condición], ENTONCES el sistema DEBERÁ [respuesta]. |
| Solo con una opción activa | Opcional | DONDE [opción habilitada], el sistema DEBERÁ [respuesta]. |

## Procedimiento
1. **Requerimientos funcionales:** un `REQ` por `HU` (o por grupo de `HU` de un mismo
   `CU`). En "Origen" cita `HU`, `CU` y `RN`. **No reescribas** la historia.
2. Deriva los criterios:
   - flujo principal del `CU` → criterios CUANDO (al menos 1 camino feliz);
   - cada `FE` y cada `RN` de tipo Validación o Restricción → un criterio SI…ENTONCES;
   - cada `RN` de Autorización → un criterio de permisos;
   - estados del `CU` → criterios MIENTRAS, con el estado en MAYÚSCULAS entre comillas.
3. Validaciones de cada campo que captura el usuario: vacío/obligatorio, formato,
   longitud/rango y duplicado, cada uno con su mensaje exacto.
4. **Requerimientos no funcionales:** un `REQ` por cada `NF` verificable de RQ-04, con
   "Origen: NF-###" y un valor medible. Un `NF` de tipo Supuesto no genera `REQ`.
5. Numera `REQ-###.CA-##` y llena el catálogo.

## Anti-patrones (corrige antes de entregar)

| Si detectas… | Corrige a… |
|--------------|-----------|
| "…DEBERÁ guardar y notificar" | Dos criterios |
| "El colaborador DEBERÁ…" | "CUANDO el colaborador…, el sistema DEBERÁ…" |
| "SI el juego está cerrado…" sin respuesta | Agregar "ENTONCES el sistema DEBERÁ…" |
| "…mostrar un error" | Mensaje exacto entre comillas |
| "…usando un trigger de BD" | Comportamiento observable |
| "el sistema debería…" | "el sistema DEBERÁ…" |

## Checklist final
Cada criterio en patrón EARS correcto · termina en "el sistema DEBERÁ…" · una respuesta
verificable · sin vaguedades ni implementación · cada `FE` y `RN` de validación tiene
criterio · cada `NF` verificable tiene `REQ` · no contradice RQ-04 a RQ-07 · sin Gherkin ·
encabezado e historial completos.
