---
name: pl-06-contrato-endpoints
description: Genera el documento PL-06 Contrato de endpoints (EP con ruta, método, parámetros, cuerpo/respuesta JSON, códigos y propósito) usando templates/02-plan-diseno/PL-06_contrato-endpoints.md, a partir del modelo de datos de PL-05 y los casos de uso de RQ-07. Úsalo cuando se pida el contrato de API o la especificación de endpoints del proyecto.
---

# Skill — PL-06 Contrato de endpoints

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).
Guía extendida para personas: `instructivos/02-plan-diseno/PL-06_contrato-endpoints_instructivo.md`.

> **Secuencia:** este documento es 🟢 auto-generable (se deriva de los requerimientos y no
> depende del stack) y se produce en **BORRADOR antes de la reunión de diseño**, como
> insumo para ella (la reunión decide el stack viendo ya las operaciones). Se ajusta
> después si una decisión de la reunión lo amerita.

## Insumos
PL-05 (`ENT`, `CAM`), RQ-07 (`CU`), RQ-06 (`RN`).
Plantilla `templates/02-plan-diseno/PL-06_contrato-endpoints.md`.

## Procedimiento
1. **Un endpoint (`EP`) por operación** que expone el sistema. Deriva de los pasos de los
   `CU` de RQ-07.
2. **Por cada `EP`** define: ruta, método (GET/POST/PUT/DELETE…), parámetros (ruta/query),
   cuerpo de petición JSON, cuerpo de respuesta JSON, códigos de estado
   (200/400/401/404/500…) y propósito.
3. **Usa las entidades `ENT` y campos `CAM` de PL-05** para los cuerpos JSON; no redefinas
   tipos de dato aquí.
4. Aquí solo se **listan** los códigos de estado; el catálogo y la estrategia de errores
   son de PL-07.
5. Lo no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada `EP` cita el `CU` de RQ-07 y/o la `RN` de RQ-06 que satisface, y referencia las
entidades `ENT` de PL-05 que usa en su cuerpo/respuesta.

## Lo que NO va aquí
Catálogo y estrategia de errores (PL-07; aquí solo se listan los códigos) · firmas de
métodos o controladores de código (fase de Tareas/Desarrollo) · mensajes al usuario
(RQ-08) · lógica de capas back (PL-08).

## Checklist final
Cada `EP` con ruta, método, parámetros, JSON de petición/respuesta, códigos y propósito ·
cuerpos usan `ENT`/`CAM` de PL-05 · cada `EP` cita `CU`/`RN` · solo lista códigos (sin
catálogo de errores) · encabezado e historial completos.
