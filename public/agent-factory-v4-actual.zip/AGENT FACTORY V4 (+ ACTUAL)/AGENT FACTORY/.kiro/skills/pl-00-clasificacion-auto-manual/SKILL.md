---
name: pl-00-clasificacion-auto-manual
description: Genera el documento PL-00 Clasificación auto/manual/auto-derivado (tabla 🟢/🔵/🟣 de qué genera el agente, qué decide el arquitecto y qué se auto-deriva, con las reglas duras backend→arquitectura/ambiente/config) usando templates/02-plan-diseno/PL-00_clasificacion-auto-manual.md. Úsalo como primer documento de la Fase 02, antes de generar cualquier otro PL.
---

# Skill — PL-00 Clasificación auto/manual/auto-derivado

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
Documentos **aprobados** de la Fase 01 (RQ-04…RQ-08) para el encabezado y las Fuentes.
Plantilla `templates/02-plan-diseno/PL-00_clasificacion-auto-manual.md`.

## Procedimiento
1. **El contenido es ESTÁNDAR.** La clasificación 🟢/🔵/🟣 y las reglas duras de derivación
   (backend → arquitectura, backend → ambiente permitido, backend → mecanismo de config)
   son fijas de la organización. Copia la plantilla tal cual.
2. **Solo ajusta si el proyecto tiene una excepción** explícita y confirmada. Cualquier
   ajuste no confirmado usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.
3. Este documento **fija qué será 🟢, 🔵 y 🟣 en este proyecto**: qué genera el agente desde
   los requerimientos, qué decide el arquitecto en la reunión y qué queda determinado por
   una decisión previa (regla dura).
4. Completa el encabezado con el `<COD>` y las versiones de las Fuentes de Fase 01.

## Trazabilidad (obligatoria)
Las Fuentes citan los documentos aprobados de la Fase 01 (RQ-04…RQ-08) con su versión.

## Lo que NO va aquí
Decisiones concretas (el backend, el ambiente y el stack van en PL-01/PL-02) · diseño de
arquitectura (PL-08) · cualquier artefacto de diseño.

## Checklist final
Tabla 🟢/🔵/🟣 presente · reglas duras backend→arquitectura/ambiente/config presentes ·
contenido estándar salvo excepción confirmada · sin decisiones concretas ni diseño ·
encabezado e historial completos.
