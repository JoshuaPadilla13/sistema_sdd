---
name: rq-05-historias-usuario
description: Genera el documento RQ-05 Historias de usuario (HU-###) a partir del documento base RQ-04, usando templates/01-requerimientos/RQ-05_historias-usuario.md. Úsalo cuando se pidan historias de usuario. Solo contiene la declaración Como/Quiero/Para, actor, prioridad y dependencias; sin criterios de aceptación, reglas, UI ni detalles técnicos.
---

# Skill — RQ-05 Historias de usuario

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-04 (alcance `INC`, objetivos `OBJ`, actores `ACT`) y RQ-02 Parte 5 (tareas A y G).
Plantilla `templates/01-requerimientos/RQ-05_historias-usuario.md`.

## Procedimiento
1. Cada `INC` produce una o más historias. **Nada fuera de `INC`** se convierte en historia.
2. Redacta "Como [rol], quiero [acción], para [beneficio]". El rol es un `ACT` de RQ-04 y
   el beneficio se liga a un `OBJ`.
3. Una historia = un objetivo coherente de un solo actor. Si mezcla dos actores u
   objetivos, divídela.
4. Prioridad desde RQ-02 Parte 5 G: "Sin esto no podemos arrancar" = Alta; "Es
   importante" = Media; "Puede esperar" = Baja. Si no se dijo: `⚠️ POR CONFIRMAR`.
5. Dependencias solo hacia otras `HU`.
6. Llena el catálogo y después el detalle de cada historia.

## Lo que NO va aquí (y a dónde va)

| No escribir | Va en |
|-------------|-------|
| Criterios de aceptación (ni Gherkin, ni EARS) | RQ-08 |
| Reglas, validaciones de campos, permisos | RQ-06 |
| Flujos paso a paso, excepciones | RQ-07 |
| Textos exactos, mensajes | RQ-08 |
| Estados de pantalla, colores, layout | Fase 02: Especificación de vistas y rutas |
| Endpoints, payloads, modelos de datos, stack | Fase 02: Contrato de endpoints, Diccionario de datos, Selección de stack |

## Checklist final
Cada `HU` cita un `ACT`, un `OBJ` y un `INC` · cada `INC` tiene al menos una `HU` · un actor
y un objetivo por historia · prioridad asignada o con `PEN` · ninguna sección prohibida ·
encabezado e historial completos.
