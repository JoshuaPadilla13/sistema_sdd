---
name: rq-01-checklist-discovery
description: Mantiene el documento ÚNICO RQ-01 Checklist de Discovery del proyecto usando templates/01-requerimientos/RQ-01_checklist-discovery.md. En la primera sesión lo crea; en las siguientes NO crea otro, sino que actualiza el mismo marcando los ítems cubiertos. Úsalo cuando haya una transcripción de una sesión de Discovery y se necesite verificar qué información ya cubrió el cliente y qué sigue como hueco.
---

# Skill — RQ-01 Checklist de Discovery

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

> **Hay UN SOLO checklist por proyecto**, no uno por sesión. En la primera sesión se crea;
> en cada sesión posterior se **actualiza el mismo archivo** marcando los ítems que ya se
> cubrieron. **Nunca** generes un segundo checklist ni le pongas sufijo `-S#`.

## Insumos
- Transcripción de la sesión S#.
- El checklist **existente** del proyecto (si ya se creó en una sesión anterior) o el que
  el facilitador llenó en tiempo real.
- Plantilla `templates/01-requerimientos/RQ-01_checklist-discovery.md`.

## Procedimiento
1. **Busca primero el checklist del proyecto** `<COD>_RQ-01_checklist-discovery.md` en
   `documentacion/01-requerimientos/`.
   - **Si ya existe:** ábrelo y **complétalo** con lo cubierto en esta sesión. No lo
     recrees ni dupliques. Conserva los ítems ya marcados (no los cambies sin evidencia) y
     solo avanza los que esta sesión resolvió o mejoró (p. ej. de ❌ a 🟡, o de 🟡 a ✅).
   - **Si no existe:** créalo desde la plantilla (primera sesión).
2. Marca cada ítem con ✅ / 🟡 / ❌ / N/A y anota el **minuto** de la transcripción donde
   salió (para ✅ y 🟡). Indica entre paréntesis la sesión del dato cuando ayude a la
   trazabilidad (p. ej. `✅ S2 14:20`).
3. **Una respuesta negativa confirmada es ✅, no ❌.** El checklist mide si ya se sabe la
   respuesta, no si la respuesta es "sí". Si el cliente confirma que algo no existe (p. ej.
   "no hay fecha límite", "no hay presupuesto definido", "no hay integraciones"), el ítem es
   ✅ y en Referencia se anota la respuesta y su minuto (p. ej. `Sin fecha fija · S1 12:40`).
   ❌ solo cuando no se preguntó o no hubo respuesta; 🟡 cuando la respuesta es incompleta
   (p. ej. "hay fecha, pero no la sabemos").
4. La pregunta de rescate solo aplica a 🟡 y ❌; no la reescribas.
5. Actualiza el resumen de cobertura al estado acumulado tras esta sesión.
6. Registra el avance en el **historial de cambios** del documento (una fila por sesión:
   "Actualización S2 — …"), y sube la versión.
7. Lista para la minuta RQ-03 los ítems que siguen 🟡 y ❌: la skill
   `rq-03-minuta-discovery` los registra como `PEN-###`. **No** crees tabla de pendientes
   en este documento.

## Lo que NO va aquí
Un segundo checklist o versiones por sesión · pendientes, decisiones, respuestas del
cliente a detalle (van en RQ-02) · análisis de requerimientos.

## Checklist final
Un único archivo `<COD>_RQ-01_checklist-discovery.md` (sin `-S#`) · ítems marcados y
acumulados entre sesiones · ✅ y 🟡 con minuto · respuestas negativas confirmadas en ✅ (no
❌) · resumen al día · historial con una fila por
sesión · sin tabla de pendientes · encabezado e historial completos.
