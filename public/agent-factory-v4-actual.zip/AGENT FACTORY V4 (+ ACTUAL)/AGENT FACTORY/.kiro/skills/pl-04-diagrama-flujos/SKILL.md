---
name: pl-04-diagrama-flujos
description: Genera el documento PL-04 Guía de diagrama de flujos (lista de flujos a dibujar derivados de los CU de RQ-07, con sus pasos y decisiones, más el campo del .drawio adjunto) usando templates/02-plan-diseno/PL-04_diagrama-flujos.md. Úsalo cuando se necesite especificar qué flujos debe dibujar el arquitecto, sin generar el diagrama.
---

# Skill — PL-04 Guía de diagrama de flujos

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-07 (`CU`, flujo principal, `FA`, `FE`).
Plantilla `templates/02-plan-diseno/PL-04_diagrama-flujos.md`.

## Regla clave: el agente NO dibuja
Este documento **no** genera el diagrama (ni Mermaid ni XML de draw.io). La skill produce
la **lista de flujos a dibujar** derivados de los `CU`, con sus pasos y decisiones, y deja
el campo para referenciar el `.drawio` que el arquitecto adjunta.

## Procedimiento
1. **Lista los flujos a diagramar:** uno por cada `CU` de RQ-07 que amerite diagrama de
   flujo (o por flujo alterno/excepción relevante).
2. **Por cada flujo** describe los pasos en orden y los puntos de decisión (condiciones,
   bifurcaciones), sin reescribir el `CU`: basta el resumen de pasos para dibujarlo.
3. **Diagrama adjunto:** deja el campo con la ruta/nombre del `.drawio` que dibujará el
   arquitecto. Si aún no existe: `⚠️ POR CONFIRMAR (PEN-###)`.

## Trazabilidad (obligatoria)
Cada flujo cita el `CU` (y `FA`/`FE` si aplica) de RQ-07 del que se deriva.

## Lo que NO va aquí
El diagrama dibujado (lo hace el arquitecto en draw.io) · Mermaid ni XML autogenerado ·
elementos de infraestructura (PL-03) · reglas de negocio reescritas (viven en RQ-06).

## Checklist final
NO dibuja: solo lista los flujos · cada flujo cita su `CU` · pasos y decisiones por flujo ·
campo del `.drawio` adjunto presente · sin Mermaid ni XML · encabezado e historial
completos.
