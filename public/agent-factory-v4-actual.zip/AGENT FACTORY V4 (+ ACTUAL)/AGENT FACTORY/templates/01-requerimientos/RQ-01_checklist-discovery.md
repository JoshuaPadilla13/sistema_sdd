# Checklist de Discovery

| Campo | Valor |
|-------|-------|
| Documento | RQ-01 · Checklist de Discovery |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | [Facilitador] / sdd-01-requerimientos |
| Validó | — |
| Fuentes | [Transcripciones de las sesiones S1, S2, …] |

> **Documento único por proyecto.** No se crea uno por sesión: se usa el mismo y se va
> completando en cada sesión, marcando los ítems conforme el cliente los cubre. Se usa
> **en tiempo real** durante la sesión para verificar qué ya dijo el cliente y qué falta.
> No es un cuestionario. Solo se hace la *pregunta de rescate* cuando el ítem está 🟡 o ❌.
>
> Cobertura: ✅ Cubierto · 🟡 Parcial · ❌ Falta · N/A
> (✅ = ya se sabe la respuesta, aunque sea "no hay": p. ej. "sin fecha fija" es ✅)
> Para ✅ y 🟡 anota el minuto (y la sesión, p. ej. `✅ S2 14:20`). Los ítems 🟡 y ❌ que no
> se cierren se registran como `PEN-###` en la minuta RQ-03 de la sesión correspondiente.

---

## Bloque A — Suele cubrirlo el cliente solo (solo verificar)

| Cobertura | Ítem | Referencia (minuto) | Pregunta de rescate |
|-----------|------|---------------------|---------------------|
| | **Problema / dolor** que motiva el proyecto | | "¿Cuál es el dolor principal que buscan resolver?" |
| | **Objetivo** de la solución | | "Si esto sale bien, ¿cómo se ve el resultado?" |
| | **Contexto de uso** (dónde / cuándo) | | "¿En qué momento y situación se usaría?" |
| | **Usuarios** principales | | "¿Quién va a usar esto en el día a día?" |

## Bloque B — Suele quedar incompleto

| Cobertura | Ítem | Referencia (minuto) | Pregunta de rescate |
|-----------|------|---------------------|---------------------|
| | **Sponsor / quién aprueba** | | "¿Quién toma la decisión final y aprueba?" |
| | **Indicador de éxito** | | "¿Cómo van a medir que funcionó?" |
| | **Fecha límite** (fija o deseable) | | "¿Hay una fecha límite? ¿Es fija o flexible?" |
| | **Proceso actual (AS-IS)** paso a paso | | "¿Cómo lo hacen hoy, paso a paso?" |

## Bloque C — Casi siempre falta (foco principal)

| Cobertura | Ítem | Referencia (minuto) | Pregunta de rescate |
|-----------|------|---------------------|---------------------|
| | **Qué ENTRA** en la primera versión | | "¿Qué debe incluir sí o sí la primera entrega?" |
| | **Qué NO ENTRA** | | "¿Qué dejamos explícitamente fuera por ahora?" |
| | **Dudosos**, funcionalidad por funcionalidad | | "Esta funcionalidad X, ¿entra o no entra?" |
| | **Excepciones y casos especiales** | | "¿Qué casos raros o excepciones hay que contemplar?" |
| | **Reglas de negocio / normativa** | | "¿Hay reglas, políticas o normativa que respetar?" |
| | **Datos obligatorios vs. opcionales** | | "¿Qué datos son obligatorios y cuáles opcionales?" |
| | **Límites concretos** (montos, plazos, cantidades) | | "¿Hay límites, montos o cantidades que importen?" |
| | **Integraciones / otros sistemas** | | "¿Con qué otros sistemas tiene que conectarse?" |
| | **Documentación de apoyo** | | "¿Existe documentación? ¿Quién la entrega y cuándo?" |
| | **Restricciones técnicas / infraestructura / seguridad** | | "¿Hay tecnología o restricciones de seguridad obligatorias?" |

## Bloque D — Anti-alucinación (confirmado vs. idea)

| Cobertura | Ítem | Referencia (minuto) | Pregunta de rescate |
|-----------|------|---------------------|---------------------|
| | **Qué está confirmado** vs. qué es idea | | "De lo que vimos, ¿qué es un hecho y qué todavía es idea?" |
| | **Supuestos** que se están asumiendo | | "¿Qué estamos asumiendo que aún no está confirmado?" |
| | **Dependencias externas** | | "¿De qué o de quién dependemos que no controlamos?" |
| | **Riesgos** que anticipa el cliente | | "¿Qué podría salir mal o retrasar esto?" |

## Cierre de la sesión (últimos minutos)

| Hecho | Acción |
|-------|--------|
| ☐ | Resumir acuerdos en voz alta y confirmarlos con el cliente |
| ☐ | Confirmar la prioridad principal |
| ☐ | Preguntar: "¿algo importante que no hayamos tocado?" |
| ☐ | Acordar responsable y fecha para lo que quedó abierto |
| ☐ | Decidir si se requiere otra sesión |

## Resumen de cobertura

| Bloque | ✅ | 🟡 | ❌ | N/A |
|--------|----|----|----|-----|
| A. Básicos | | | | |
| B. Suele quedar incompleto | | | | |
| C. Casi siempre falta | | | | |
| D. Anti-alucinación | | | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
