# Guía de diagrama de arquitectura

| Campo | Valor |
|-------|-------|
| Documento | PL-03 · Guía de diagrama de arquitectura |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-01 vX; [COD]_PL-02 vX |

> El diagrama lo dibuja el arquitecto copiando los elementos que apliquen del diagrama
> maestro de draw.io. Este documento solo especifica qué copiar y cómo se conecta.

## 1. Diagrama adjunto

| Campo | Valor |
|-------|-------|
| Diagrama .drawio adjunto | [ruta/nombre del archivo] |

## 2. Elementos a incluir

| Elemento del diagrama maestro | ¿Incluir? | Justificación (PL-01/PL-02) |
|-------------------------------|-----------|-----------------------------|
| | | |

## 3. Relaciones / conexiones entre elementos

| Origen | Destino | Tipo de conexión |
|--------|---------|------------------|
| | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
