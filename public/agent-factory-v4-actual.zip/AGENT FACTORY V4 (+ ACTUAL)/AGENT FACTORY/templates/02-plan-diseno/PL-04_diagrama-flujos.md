# Guía de diagrama de flujos

| Campo | Valor |
|-------|-------|
| Documento | PL-04 · Guía de diagrama de flujos |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-07 vX |

> El diagrama lo dibuja el arquitecto en draw.io. Este documento solo especifica qué
> flujos dibujar y con qué pasos y decisiones.

## 1. Diagrama adjunto

| Campo | Valor |
|-------|-------|
| Diagrama .drawio adjunto | [ruta/nombre del archivo] |

## 2. Flujos a dibujar

| ID flujo | Caso de uso (CU-###) | Descripción | Pasos/decisiones clave |
|----------|----------------------|-------------|------------------------|
| | CU-### | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
