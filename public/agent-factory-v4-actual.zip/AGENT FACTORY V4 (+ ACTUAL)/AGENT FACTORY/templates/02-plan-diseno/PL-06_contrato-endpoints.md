# Contrato de endpoints

| Campo | Valor |
|-------|-------|
| Documento | PL-06 · Contrato de endpoints |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-05 vX; [COD]_RQ-07 vX |

## 1. Catálogo

| ID | Endpoint | Método | Propósito | Origen (CU-###/RN-###) |
|----|----------|--------|-----------|------------------------|
| EP-001 | | | | CU-### · RN-### |

---

## EP-001 — [Nombre]

### Cómo se consume

**Ruta:** `[/ruta/del/endpoint]`
**Método:** GET / POST / PUT / DELETE

### Parámetros

| Parámetro | Tipo | Obligatorio | Descripción |
|-----------|------|-------------|-------------|
| | | | |

### Cuerpo de petición

```json
{
  "campo": "valor"
}
```

### Respuesta

```json
{
  "campo": "valor"
}
```

### Códigos de respuesta

| Código | Significado |
|--------|-------------|
| 200 | |
| 400 | |
| 401 | |
| 500 | |

### Para qué sirve

[Descripción breve del propósito del endpoint.]

<!-- Repetir bloque por endpoint. -->

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
