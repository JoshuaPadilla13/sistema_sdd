# Diccionario de datos, modelo de datos e interfaces

| Campo | Valor |
|-------|-------|
| Documento | PL-05 · Diccionario de datos, modelo de datos e interfaces |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX; [COD]_RQ-06 vX; [COD]_RQ-07 vX |

## 1. Entidades

| ID | Entidad | Descripción | Origen (glosario RQ-04 / CU-###) |
|----|---------|-------------|----------------------------------|
| ENT-001 | | | |

## 2. Diccionario de campos por entidad

### ENT-001 — [Entidad]

| ID | Campo | Tipo | Obligatorio | Sensible | Descripción | Regla (RN-###) |
|----|-------|------|-------------|----------|-------------|----------------|
| ENT-001.CAM-01 | | | | | | RN-### |

<!-- Repetir bloque por entidad. -->

## 3. Relaciones entre entidades

| Entidad origen | Relación | Entidad destino |
|----------------|----------|-----------------|
| | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
