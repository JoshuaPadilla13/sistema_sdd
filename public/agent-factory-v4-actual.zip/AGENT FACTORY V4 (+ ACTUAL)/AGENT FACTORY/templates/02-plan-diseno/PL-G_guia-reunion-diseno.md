# Guía de la reunión de diseño

| Campo | Valor |
|-------|-------|
| Documento | PL-G · Guía de la reunión de diseño |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | Documentos aprobados de Fase 01 ([COD]_RQ-04 … [COD]_RQ-08) |

> Documento **transversal**. Por eso lleva la letra `G` y no un número de orden en la
> secuencia PL-01 … PL-11.

## 1. Propósito

Es el **orden del día técnico** de la reunión de diseño. El arquitecto presenta ante el
equipo los artefactos aprobados de la Fase 01 y **decide y justifica** la arquitectura y
tecnología que se usarán. Lo acordado alimenta los selectores (PL-01, PL-02) y, con ellos,
las derivaciones 🟣 (PL-08, ambiente permitido, mecanismo de configuración).

## 2. Antes de la reunión

- [ ] RQ-04 Documento base — estado `Approved`
- [ ] RQ-05 Historias de usuario — estado `Approved`
- [ ] RQ-06 Reglas de negocio — estado `Approved`
- [ ] RQ-07 Casos de uso — estado `Approved`
- [ ] RQ-08 Criterios de aceptación EARS — estado `Approved`
- [ ] Sin `PEN` críticos abiertos en las minutas RQ-03

Artefactos a proyectar en la reunión:

- [ ] RQ-04 (problemas, objetivos, alcance, actores, límites no funcionales `NF`, glosario)
- [ ] RQ-05 (historias de usuario)
- [ ] RQ-06 (reglas de negocio)
- [ ] RQ-07 (casos de uso y estados)
- [ ] RQ-08 (criterios de aceptación y requisitos no funcionales verificables)
- [ ] **PL-05 borrador** (modelo de datos: entidades y campos) — material de apoyo para decidir el stack
- [ ] **PL-06 borrador** (contrato de endpoints: operaciones del sistema) — material de apoyo para decidir el stack
- [ ] **PL-M borrador** (prompt/mockups de diseño visual para Claude) — material de apoyo **no bloqueante**

> El borrador de PL-05 y PL-06 se genera **antes** de la reunión (son 🟢, se infieren de los
> requerimientos y no dependen del stack). Tenerlos a la vista permite decidir la tecnología
> con los datos y las operaciones concretas del sistema.
>
> El borrador de **PL-M** (prompt de diseño visual para Claude) también se prepara antes de
> la reunión como apoyo, pero es **no bloqueante**: el diseño visual no depende del stack, así
> que si el mockup no está listo o aprobado, la reunión igual procede.

## 3. Decisiones a tomar (con menú de opciones reales)

> **RECORDATORIO · REGLAS DURAS de compatibilidad:**
> - .NET Core (.NET 8): Dev **solo** W2022 · Prod **solo** Aplicaciones · config `appsettings.{env}.json` · arquitectura orientada a servicios.
> - .NET Framework: Dev W2022 **o** W2016 · Prod Aplicaciones **o** Portales · config `App.config`/`Web.config` (o `Res_General.resx` en legacy GS) · arquitectura 3 capas.
> - Portales solo aloja .NET Framework.

| # | Decisión (🔵) | Opciones (marcar una) |
|---|---------------|-----------------------|
| 1 | Backend | [ ] .NET 8 (Core) · [ ] .NET Framework 4.8 · [ ] legacy GS |
| 2 | Acceso a datos | [ ] EF Core · [ ] EF6 · [ ] SP-Packages · [ ] Híbrido |
| 3 | Motor BD | [ ] Oracle · [ ] SQL Server · [ ] MySQL · [ ] SQLite |
| 4 | Autenticación | [ ] JWT · [ ] Token propio GUID · [ ] Otro |
| 5 | Estrategia de esquema | [ ] Migraciones EF · [ ] Scripts SQL |
| 6 | Despliegue | [ ] TFS · [ ] GitLab CI/CD |
| 7 | Ambiente Dev backend | [ ] W2022 · [ ] W2016 |
| 8 | Ambiente Prod backend | [ ] Aplicaciones · [ ] Portales |
| 9 | Ambiente Prod frontend | [ ] Aplicaciones intranet · [ ] Móvil Huawei (internet sin VPN) |

## 4. Para cada decisión, registrar

Lo registrado aquí alimenta los `DEC-D` de PL-02 (y las notas de PL-01). Por cada decisión:

- [ ] **Qué se eligió** (la opción marcada arriba)
- [ ] **Por qué** → Contexto (situación que obliga a decidir)
- [ ] **Por qué** → Alternativas consideradas (y por qué se descartaron)
- [ ] **Por qué** → Consecuencias (qué implica la elección para el resto del diseño)

## 5. Después de la reunión

La reunión se **transcribe** y el `.txt` resultante se guarda en
`transcripciones diseno/txt/` (nombre sugerido `<COD>_reunion-diseno.txt`; si la reunión
quedó en `.docx`, conviértela a `.txt` antes). **Si no se grabó**, se llena el acta de
decisiones (plantilla `templates/02-plan-diseno/PL-A_acta-decisiones-diseno.md`) y se guarda
como `transcripciones diseno/txt/<COD>_acta-decisiones-diseno.md`. Ese archivo es el
**insumo del Modo B (post-reunión)** del agente: de ahí toma las decisiones del arquitecto
para rellenar los selectores y derivar el resto del diseño.

Con lo acordado en la transcripción o el acta, el agente:

- [ ] Rellena **PL-01** (selección de ambientes) con lo elegido
- [ ] Rellena **PL-02** (selección de stack) y captura cada porqué como `DEC-D`
- [ ] Deriva **PL-08** (arquitectura back) aplicando la regla dura backend → arquitectura
- [ ] Valida que ambiente y mecanismo de configuración respeten las reglas duras

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
