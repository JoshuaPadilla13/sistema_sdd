# Estrategia de pruebas

| Campo | Valor |
|-------|-------|
| Documento | PL-11 · Estrategia de pruebas |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-08 vX; [COD]_PL-05 vX; [COD]_PL-06 vX |

## 1. Tipos de prueba

| ID | Tipo (Unitaria/Integración/E2E) | Alcance | Herramienta | Requisitos cubiertos (REQ-###) |
|----|---------------------------------|---------|-------------|--------------------------------|
| TPR-001 | | | | REQ-### |

## 2. Qué NO entra en las pruebas

- [Elemento fuera del alcance de pruebas]

## 3. Criterios de aceptación globales

- [Criterio que debe cumplir el conjunto de pruebas para considerarse superado]

## 4. Pirámide de pruebas

[Nota breve: muchas pruebas unitarias en la base, algunas de integración en el medio y
pocas pruebas E2E en la cima.]

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
