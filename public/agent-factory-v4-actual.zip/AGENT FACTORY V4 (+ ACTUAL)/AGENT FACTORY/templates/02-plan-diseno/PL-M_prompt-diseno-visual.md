# Prompt de diseño visual (para Claude)

| Campo | Valor |
|-------|-------|
| Documento | PL-M · Prompt de diseño visual (para Claude) |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-J vX (fases del journey, acota el alcance); [COD]_RQ-05 vX; [COD]_RQ-07 vX; [COD]_PL-10 vX (si existe); diagrama de flujo del cliente (si existe) |

> 🟢 **Auto-generable.** Se deriva de las historias (RQ-05), los casos de uso (RQ-07) y, muy
> importante, del **customer journey PL-J**: el diseño cubre **solo** las fases/pantallas del
> journey que el cliente firma, no el flujo técnico completo. Se produce **antes de la
> reunión** como apoyo **no bloqueante**; el visual no depende del stack.
>
> **El recorrido navegable debe seguir el diagrama de flujo del cliente** (si existe), no un
> orden inventado. Empieza siempre por el login y luego por la pantalla que le hace sentido a
> cada rol (el cliente arranca en su solicitud/avance, no en un tablero genérico).
>
> **Paleta por defecto: Grupo Salinas** (amarillo `#FFCD00` + gris `#5E5E61`). Si el cliente
> trae su identidad, se sustituye y se registra como `[Propuesto]` hasta validar.

## 1. Pantallas del proyecto (acotadas al journey PL-J; derivadas de RQ-05 / RQ-07 / PL-10)

| ID | Pantalla / Vista | Fase del journey (PL-J) | Rol que la usa | Propósito | Origen (HU/CU/VIS) |
|----|------------------|--------------------------|----------------|-----------|---------------------|
| | | | | | |

> Solo entran pantallas de fases presentes en el journey PL-J. Indica para cada una el rol
> que la usa, para que Claude no haga vistas idénticas entre roles.

## 2. Prompt para Claude

> Copia el siguiente bloque a Claude. El objetivo es un **artifact** interactivo y navegable.

```text
Actúa como un diseñador de producto y front-end senior con criterio de marca. Genera el
resultado como un ÚNICO ARTIFACT interactivo, autocontenido y navegable en vivo. Antes de
dibujar cualquier pantalla, define e implementa un sistema de diseño con PERSONALIDAD, no
genérico. Toda la interfaz va en español.

## 0. Reglas que NO puedes romper (lecciones de proyectos previos)
- PROPUESTA DE DISEÑO REAL: nada de "formulario plano" ni look de plantilla por defecto.
  Define una personalidad visual (voz de marca, acentos, ritmo, detalle) y aplícala a TODAS
  las pantallas, empezando por el login. Un diseño soso o genérico es un entregable fallido,
  aunque uses los colores corporativos. Busca inspiración en productos SaaS ejecutivos
  modernos, pero NO copies: propón.
- EL LOGIN ES LA PRIMERA IMPRESIÓN: debe tener identidad de marca completa (logotipo o
  monograma, nombre del producto, un lado visual con propuesta —imagen, patrón o color de
  marca—, no un recuadro blanco vacío). El recorrido SIEMPRE empieza en el login.
- VISTAS POR ROL GENUINAMENTE DISTINTAS: cada rol ve navegación, pantalla inicial y acciones
  DIFERENTES, acordes a lo que hace. Prohibido el mismo tablero con otro título. El cliente
  arranca en SU recorrido (solicitud/avance), no en un tablero operativo que no entiende.
- EL CAMBIO DE ROL/SIMULACIÓN VA FUERA DEL LIENZO: si incluyes un selector de rol para la
  demo, ponlo en una BARRA SUPERIOR DE DEMO claramente separada del producto (etiquetada
  "modo demostración"), NUNCA como un botón dentro de la vista del usuario logueado (p. ej.
  "continuar como [otra persona]" mezclado con el contenido confunde de quién es la vista).
- EL FLUJO SIGUE EL DIAGRAMA DEL CLIENTE: respeta el orden del recorrido real (sección 6);
  no inventes transiciones ni abras en una pantalla que el cliente no esperaría.

## 1. Formato del entregable (artifact)
- Entrega TODO en un solo artifact ejecutable, navegable al instante; no partas la respuesta
  en archivos ni pidas copiar fragmentos.
- Navegación interna para saltar entre pantallas sin recargar.
- Tokens de diseño como única fuente de verdad dentro del artifact; datos de ejemplo en
  español para poblar las pantallas.

## 2. Principios de diseño (obligatorios)
- Claridad ejecutiva: jerarquía visual evidente, espacios en blanco generosos, nada saturado.
- Consistencia total: todo color/tamaño/espaciado/radio viene de tokens; cero valores sueltos.
- Intuitivo: patrones predecibles, affordances claros, feedback inmediato.
- Accesible: contraste AA, foco visible, targets de 44px, textos legibles.
- Responsivo: mobile-first, breakpoints definidos, layouts que se reacomodan con elegancia.

## 3. Tokens de diseño (defínelos primero, sección central del artifact)
### Colores — Identidad Grupo Salinas (por defecto)
// Marca
$color-primary:       #FFCD00; // Amarillo GS - acento / CTAs
$color-primary-light: #FFE04D;
$color-primary-dark:  #E6B800;
$color-gris-gs:       #5E5E61; // Gris GS - textos / secundarios
// Texto
$color-text:          #2D2926;
$color-text-secondary:#686868;
$color-text-muted:    #7A7C80;
// Fondos
$color-bg:            #FFFFFF;
$color-bg-soft:       #FDFBF9;
$color-bg-subtle:     #F3F4F6;
// Bordes
$color-border:        #E5E7EB;
$color-border-input:  #9A9DA1;
// Header/footer oscuro
$color-dark:          #2C2C2C;
// Estados / semáforo
$color-success:       #16A34A;
$color-warning:       #F59E0B;
$color-error:         #DC2626;
$color-info:          #2563EB;
:root { --color-marca: #FFCD00; }

> Usa el amarillo con intención (acentos y CTAs), no como fondo masivo. El gris y los neutros
> cargan el texto y las superficies. Si el cliente trae otra paleta, reemplázala manteniendo
> la estructura de tokens.

### Tipografía
- Familia profesional y legible (ej. Inter). Escala en rem: xs(12) sm(14) base(16) lg(18)
  xl(20) 2xl(24) 3xl(30). Pesos 400/500/600/700. Interlineado 1.5 cuerpo / 1.3 títulos.

### Espaciado, radios, sombras, movimiento
- Espaciado múltiplos de 8px. Radios sm(4) md(8) lg(12) full. Sombras sutiles (3 niveles).
  Transiciones rápida(150) base(250) lenta(350). Breakpoints sm(640) md(768) lg(1024) xl(1440).

## 4. Componentes base (a partir de los tokens)
Botones (primary amarillo, secondary contorno, success, danger; estados hover/active/disabled/
focus), inputs/selects/textarea con focus de marca, cards, badges de estatus y semáforo,
navegación y tabs/pill, tabla/listado de seguimiento, stepper/línea de tiempo, estados de
carga/vacío/error/éxito.

## 5. Layout
Header y footer con fondo oscuro neutro (#2C2C2C) y acento de marca puntual; contenido
centrado (máx ~1440px); grids que colapsan a una columna bajo lg. Si usas barra de demo de
rol, va por ENCIMA del header del producto y claramente separada.

## 6. Contexto del producto y recorrido (sigue el journey y el diagrama del cliente)
[Describe aquí, a partir del journey PL-J y del diagrama de flujo del cliente: las fases que
cubre el diseño, el recorrido en orden, y para CADA rol cuál es su pantalla inicial y qué
acciones tiene. El cliente arranca en su solicitud/avance; los roles internos en su cola o
tablero correspondiente.]

### 6.1 Roles (con pantalla inicial y acciones propias de cada uno)
[Lista los roles con su pantalla de entrada y sus acciones; deben ser distintos entre sí.]

### 6.2 Pantallas a generar (de la sección 1, acotadas al journey)
[Lista de pantallas con su propósito y la acción principal que dispara la transición.]

## 7. Entregable esperado (un solo artifact)
1. Sección central de tokens documentada.
2. Estilos globales (reset, tipografía, utilidades).
3. Librería de componentes base.
4. Todas las pantallas, accesibles desde navegación interna, empezando por el login.
5. Barra de demo de rol SEPARADA (si aplica), para cambiar de rol sin confundir la vista.
6. Recorrido navegable que siga el diagrama del cliente, con los botones que disparan cada
   transición.
7. Datos de ejemplo en español.

Importante: primero, en un mensaje de texto (no en el artifact), propón la paleta, la
personalidad visual y los tokens para mi validación; solo después genera el artifact completo.
```

## 3. Ajustes tras validación / reunión

> Registra aquí los cambios pedidos por el cliente (ajustes, no rediseño). Cada ajuste no
> confirmado: `⚠️ POR CONFIRMAR (PEN-###)`. Si ya hay un artifact generado, usa un **prompt
> de ajuste incremental** que modifique el artifact existente sin rehacerlo.

| # | Ajuste | Origen | Estado |
|---|--------|--------|--------|
| | | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
