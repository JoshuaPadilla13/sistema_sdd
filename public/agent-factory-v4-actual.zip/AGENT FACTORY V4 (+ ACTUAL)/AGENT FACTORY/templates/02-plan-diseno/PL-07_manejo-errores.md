# Enfoque de manejo de errores

| Campo | Valor |
|-------|-------|
| Documento | PL-07 · Enfoque de manejo de errores |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-08 vX; [COD]_PL-06 vX |

## 1. Estrategia general

[Descripción breve de cómo se capturan, propagan y registran los errores.]

## 2. Catálogo de errores

| ID | Situación | Código HTTP | Código interno | Mensaje técnico (log) | Origen (REQ-###) |
|----|-----------|-------------|----------------|-----------------------|------------------|
| ERR-001 | | | | | REQ-### |

## 3. Formato estándar de respuesta de error

```json
{
  "codigo": "",
  "mensaje": "",
  "detalle": ""
}
```

## 4. Política de logging

| Nivel | Cuándo se usa | Qué se registra |
|-------|---------------|-----------------|
| | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
