# Selección de ambientes

| Campo | Valor |
|-------|-------|
| Documento | PL-01 · Selección de ambientes |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX; [COD]_RQ-08 vX |

> 🔵 **Decisión del arquitecto.** Este documento es un **selector**: la elección de
> ambientes se toma en la reunión de diseño (ver PL-G) y se **registra** aquí. El arquitecto
> marca lo elegido; el agente valida las reglas duras y captura el porqué.

## 1. Regla de compatibilidad Backend ↔ Ambiente

El backend (PL-02) **restringe** qué ambientes se pueden usar. El agente no permite una
combinación prohibida.

| Backend | Dev/QA permitido | Producción permitido |
|---------|------------------|----------------------|
| .NET Framework | W2022 o W2016 | Aplicaciones o Portales |
| .NET Core (.NET 8) | Solo W2022 | Solo Aplicaciones |

## 2. Frontend (React) — ambiente

### 2.1 Dev
- [ ] **W2022** — `aa22dproges02v` (10.64.28.96)

### 2.2 Producción (elegir uno)
- [ ] **Aplicaciones intranet** — granja 2 `AA22PPROGES01V` / `AA22PPROGES02V`, VIP F5 10.64.100.132, URLs `portalapps.gs` / `botonrojo.socio.gs`
- [ ] **Móvil Huawei** (web externo / DMZ) — Huawei Cloud Mexico City 2; ALB `portalsocio.gs` 10.127.4.21 puerto 443 TLS 1.2, WAF Imperva; ECS Red Hat 8.6 `HCW19PWebExt9` 10.127.4.142 / `HCW19PWebExt10` 10.127.6.102; compartido `\\10.127.4.248\scimovil$` (50GB)

> **Regla:** internet sin VPN → Huawei. Solo intranet → Aplicaciones.

## 3. Backend Dev/QA (elegir permitido)

- [ ] **W2022** — `aa22dproges02v` (10.64.28.96); .NET Core / .NET Framework / React; TFS + GitLab; IEECO SCI INCIDENTES C4 QA 8394
- [ ] **W2016 legacy** — `AA16DContent01v` (10.64.29.22); solo .NET Framework 4.5/4.8 y React; TFS; IEECO SCI DESARROLLO W16 8303

## 4. Base de datos Dev (elegir)

- [ ] **Oracle** `DESA02_TVADESA` — ORD1Oracle (10.64.27.157), Oracle 19C
- [ ] **CA SQL** `CA_SQL` (10.122.26.41) — SQL Server, puertos 1433/1533
- [ ] **Otro:** _______________

Compartido QA: `\\tvaapps01\SisBienestarQA$` (1GB).

## 5. Backend Producción (elegir)

- [ ] **Aplicaciones intranet** — granja 2 `AA22PPROGES01V` 10.64.92.132 / `AA22PPROGES02V` 10.64.93.132, VIP F5 10.64.100.132; React + .NET Core y .NET Framework 4.8 legacy; TFS + GitLab; IEECO SCI INCIDENTES C4 PROD 6306
- [ ] **Portales intranet** — granja 3 `AA16PPORTAL01V` / `02V` / `03V` (10.64.92.130 / 10.64.93.130 / 10.64.94.130), VIP F5 10.64.100.130, URL `portal.socio.gs`; solo .NET Framework; TFS; IEECO SCI Portales 6305

## 6. Base de datos Producción (elegir)

- [ ] **Oracle** `SIGS_TVAPROD` — ORP2 (10.64.27.150), Oracle 19C, puertos 1591/1596
- [ ] **CA SQL** `CA_SQL` (10.122.23.70–73) — puertos 1533/1433
- [ ] **Otro:** _______________

Compartido Prod:
- [ ] `\\10.64.12.61\SisBienestar$` (2GB, Aplicaciones)
- [ ] `\\10.127.4.248\scimovil$` (50GB, Huawei)

## 7. Ambientes definidos

| ID | Ambiente | Propósito | Servidor(es) / IP | Motor BD | Compartido | Despliegue | IEECO |
|----|----------|-----------|-------------------|----------|------------|------------|-------|
| AMB-001 | | | | | | | |

## 8. Resumen de selección

| Dimensión | Dev | Prod |
|-----------|-----|------|
| Frontend | | |
| Backend | | |
| Base de datos | | |
| Despliegue | | |
| Recurso compartido | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
