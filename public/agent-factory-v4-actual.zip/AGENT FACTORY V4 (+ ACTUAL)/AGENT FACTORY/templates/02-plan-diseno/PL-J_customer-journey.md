# Prompt de customer journey (para Claude)

| Campo | Valor |
|-------|-------|
| Documento | PL-J · Prompt de customer journey (para Claude) |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX (problemas P, objetivos); [COD]_RQ-05 vX (historias); [COD]_RQ-07 vX (casos de uso) |

> 🟢 **Auto-generable.** El customer journey es el recorrido de **NUESTRO CLIENTE** —el que
> nos hace la petición y firma el proyecto—, de su necesidad al valor que recibe. Es lo que
> el cliente **firma** y, por eso, **acota el alcance del diseño** (PL-M solo cubre pantallas
> de las fases de este journey). Se elabora **antes** que PL-M, como apoyo **no bloqueante**.
>
> **El journey es siempre sobre nuestro cliente, nunca por roles internos del sistema.** Ojo:
> nuestro cliente puede a su vez tener sus propios clientes, pero el journey es sobre quien
> nos contrata y firma.
>
> Igual que PL-M, este documento tiene las **fases derivadas** (sección 1) **más el prompt
> para Claude** (sección 2); el resultado (el artifact del journey) lo pega el cliente.

## 1. Fases del journey (derivadas de RQ-04 / RQ-05 / RQ-07)

> Cada fase es un paso del recorrido de nuestro cliente. "Lo que hace", "dolor de hoy" y "qué
> cambia" se derivan de los problemas `P` y objetivos de RQ-04, las historias de RQ-05 y los
> casos de uso de RQ-07. Marca los **momentos de la verdad** (⭐) y las **bifurcaciones**
> (urgencia, excepción, regreso a una mesa). Lo que no esté confirmado va como `[Inferido]`,
> `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

| # | Fase | Estatus relacionado (RQ-07) | Lo que hace el cliente | Dolor de hoy | Qué cambia con el sistema | ⭐ / bifurcación | Origen |
|---|------|------------------------------|------------------------|--------------|----------------------------|------------------|--------|
| | | | | | | | |

> El diseño (PL-M) cubre **solo** las fases de esta tabla donde el cliente tiene una pantalla
> o acción. Las fases previas al sistema (p. ej. "Necesidad") no generan pantalla.

## 2. Prompt para Claude

> Copia el siguiente bloque a Claude. El objetivo es un **artifact** de customer journey
> presentable al cliente para que lo firme.

```text
Actúa como un diseñador de servicios (service designer) senior. Genera un CUSTOMER JOURNEY
MAP de una sola persona —NUESTRO CLIENTE, el que nos hace la petición y firma el proyecto—
como un ÚNICO ARTIFACT visual, presentable y navegable, que esa persona pueda leer y
aprobar/firmar en una reunión. Todo en español.

## 0. Sobre quién es el journey (no lo confundas)
- El journey es SIEMPRE sobre nuestro cliente: la persona/área que nos contrató y recibirá
  el producto. NO es un journey por roles internos del sistema.
- Nuestro cliente puede tener a su vez sus propios clientes/audiencia; aun así, el mapa es
  sobre quien firma con nosotros, de su necesidad al valor que obtiene.

## 1. Qué debe mostrar el mapa
- Una fila de FASES en orden, de la necesidad inicial hasta el valor final.
- Por cada fase: (a) qué hace el cliente, (b) su DOLOR de hoy (cómo sufre sin el sistema),
  (c) QUÉ CAMBIA con el sistema (el valor), y (d) marca de MOMENTO DE LA VERDAD cuando la
  fase es decisiva para la relación.
- BIFURCACIONES claras donde el recorrido se ramifica (urgencia, fuera de tiempo, regreso a
  una mesa, excepción), diferenciadas visualmente de la ruta principal.
- Una sección final de PREGUNTAS PARA VALIDAR con el cliente (lo que aún no está confirmado).

## 2. Propuesta visual (no genérica)
- Trátalo como una pieza ejecutiva de consultoría: jerarquía clara, tono profesional,
  identidad de marca. NO entregues un diagrama plano ni una tabla sosa.
- Usa la identidad de marca (por defecto Grupo Salinas: amarillo #FFCD00 + gris #5E5E61 sobre
  blanco; úsalo con intención, no como fondo masivo). Si el cliente trae otra paleta,
  reemplázala manteniendo la estructura.
- Codifica con color/ícono las tres capas (lo que hace / dolor / qué cambia) para que se lean
  de un vistazo. El dolor en tono de alerta, el valor en tono positivo.
- Encabezado con el nombre del proyecto, de quién es el journey, versión y alcance.

## 3. Contenido del journey
[Pega aquí las fases de la sección 1 de este documento, con su "lo que hace / dolor / qué
cambia", momentos de la verdad y bifurcaciones.]

## 4. Entregable
Un solo artifact visual, navegable en horizontal si hace falta, con todas las fases, sus tres
capas, los momentos de la verdad, las bifurcaciones y la sección de preguntas por validar.
Debe verse listo para proyectarse en una reunión y que el cliente lo firme.
```

## 3. Ajustes tras validación / reunión

> Registra aquí los cambios pedidos por el cliente (deben ser ajustes, no rehacer el journey).
> Cada ajuste no confirmado: `⚠️ POR CONFIRMAR (PEN-###)`.

| # | Ajuste | Origen | Estado |
|---|--------|--------|--------|
| | | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
