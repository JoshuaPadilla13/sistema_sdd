# Selección de stack

| Campo | Valor |
|-------|-------|
| Documento | PL-02 · Selección de stack |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-01 vX; [COD]_RQ-04 vX |

> 🔵 **Decisión del arquitecto.** Selector de 8 pasos. Se decide y justifica en la reunión
> de diseño (ver PL-G); el arquitecto marca cada paso y el agente registra el porqué como
> `DEC-D`. El backend (Paso 2) **determina** la arquitectura (PL-08), el ambiente permitido
> y el mecanismo de configuración (reglas duras de PL-00).

## Paso 1 · Frontend (fijo)

- [x] **React + Vite** (JavaScript, SASS, Context API, React Router)
  - Breakpoints: 1440 / 768 / 425
  - Espaciado base: 8px
  - Estados obligatorios por vista: carga / vacío / error / éxito

## Paso 2 · Backend (elegir uno)

- [ ] **.NET 8 (Core)** — proyecto nuevo (preferido)
- [ ] **.NET Framework 4.8** — legacy

### Consecuencias de la elección

| Aspecto | .NET 8 (Core) | .NET Framework 4.8 |
|---------|---------------|--------------------|
| Estructura | Proyecto único, orientado a servicios | Multi-proyecto, 3 capas (DAL/BLL/Microservicio) |
| Hosting | Kestrel / IIS | IIS / OWIN Self-Host |
| IoC | Integrado (built-in DI) | Unity |
| Config | `appsettings.{env}.json` | `App.config` / `Web.config` |
| Errores | Middleware | `FiltroGlobalExcepciones` |
| Controllers | `ControllerBase` | `ApiController` |
| Respuestas | `IActionResult` | `IHttpActionResult` |
| Rutas | Atributos / convención | Atributos |
| Async | `async`/`await` nativo | `async`/`await` (soportado) |

> **Nota legacy GS:** .NET Framework 4.6.1, 3 capas, IIS + `Global.asax`, sin IoC, SP Oracle
> vía `DatosGS.dll`. Se usa cuando se extiende un servicio existente de GS.

## Paso 3 · Acceso a datos (elegir)

- [ ] EF Core + LINQ
- [ ] EF6
- [ ] Stored Procedures / Packages
- [ ] Híbrido

## Paso 4 · Motor de base de datos (elegir)

- [ ] Oracle (`Oracle.EntityFrameworkCore` / ODP.NET)
- [ ] SQL Server
- [ ] MySQL (Pomelo)
- [ ] SQLite

## Paso 5 · Autenticación (elegir)

- [ ] JWT Bearer
- [ ] Token propio GUID (persistido en BD, validado por SP, vigencia definida)
- [ ] Otro: _______________

## Paso 6 · Estrategia de esquema de BD (elegir)

- [ ] Migraciones EF Core
- [ ] Scripts SQL manuales (carpeta `BaseDeDatos/` o `scripts/`)

## Paso 7 · Despliegue (elegir)

- [ ] TFS (tiende a Framework legacy / IIS)
- [ ] GitLab CI/CD (tiende a moderno / .NET 8)

## Paso 8 · Ambiente destino

Referencia a **PL-01** (no se duplica). Resumen de la selección:

| Entorno | Ambiente elegido (ver PL-01) |
|---------|------------------------------|
| Dev/QA | |
| Producción | |

## Decisiones de diseño (DEC-D)

| ID | Contexto | Decisión | Alternativas | Consecuencias |
|----|----------|----------|--------------|---------------|
| DEC-D-001 | | | | |

## Resumen de selección

| Paso | Elección |
|------|----------|
| 1 · Frontend | React + Vite |
| 2 · Backend | |
| 3 · Acceso a datos | |
| 4 · Motor BD | |
| 5 · Autenticación | |
| 6 · Esquema BD | |
| 7 · Despliegue | |
| 8 · Ambiente destino | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
