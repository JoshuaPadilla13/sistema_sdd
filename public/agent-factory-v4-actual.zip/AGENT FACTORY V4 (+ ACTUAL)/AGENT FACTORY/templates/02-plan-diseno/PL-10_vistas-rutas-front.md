# Especificación de vistas y rutas (front)

| Campo | Valor |
|-------|-------|
| Documento | PL-10 · Especificación de vistas y rutas (front) |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-09 vX; [COD]_RQ-05 vX; [COD]_RQ-07 vX |

## 1. Supuesto de diseño

| Campo | Valor |
|-------|-------|
| ¿Diseño propio o provisto por el cliente? | [ ] |

## 2. Vistas

| ID | Vista/Pantalla | Propósito | Historia (HU-###/CU-###) |
|----|----------------|-----------|--------------------------|
| VIS-001 | | | HU-### · CU-### |

## 3. Rutas

| ID | Ruta | Vista (VIS-###) | Acceso (público/rol ACT-###) |
|----|------|-----------------|------------------------------|
| RUT-001 | | VIS-### | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
