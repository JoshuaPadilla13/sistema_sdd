# Clasificación auto/manual/auto-derivado

| Campo | Valor |
|-------|-------|
| Documento | PL-00 · Clasificación auto/manual/auto-derivado |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX; [COD]_RQ-05 vX; [COD]_RQ-06 vX; [COD]_RQ-07 vX; [COD]_RQ-08 vX |

> Documento marco. Es el **primero** de la fase: define, por cada artefacto, quién lo
> decide y de dónde sale, antes de generar cualquier otro PL.

## 1. Tipos de artefacto

| Tipo | Qué significa | Quién lo produce |
|------|---------------|------------------|
| 🟢 Auto-generable | Se **deriva de los requerimientos** (qué hace el sistema y con qué datos); no depende de la tecnología elegida | El agente genera el borrador; el responsable valida |
| 🔵 Decisión del arquitecto | Decisión técnica que **no** se infiere de los requerimientos (tecnología, ambiente, despliegue); se toma y **se justifica** en la reunión de diseño | El arquitecto decide en reunión; el agente captura la decisión y su porqué como `DEC-D` |
| 🟣 Auto-derivado | No viene de requerimientos ni es libre: queda **determinado por una decisión 🔵 previa** (regla dura) | El agente lo fija aplicando la regla de derivación |

## 2. Clasificación de los artefactos de la fase

| Artefacto | Tipo | Observación |
|-----------|------|-------------|
| PL-05 · Modelo de datos | 🟢 | Deriva del diccionario/glosario de RQ-04 y de las reglas de RQ-06 |
| PL-06 · Contrato de endpoints | 🟢 | Deriva de las acciones de los `CU` (RQ-07) + datos de PL-05 |
| PL-10 · Vistas y rutas front | 🟢 | Deriva de las `HU` (RQ-05) y los `CU` (RQ-07) |
| PL-M · Prompt de diseño visual (para Claude) | 🟢 | Prompt para Claude, derivado de las historias (RQ-05) y los casos de uso (RQ-07); paleta Grupo Salinas por defecto; apoyo no bloqueante antes de la reunión |
| PL-01 · Selección de ambientes | 🔵 | Selector con la infraestructura real; decisión del arquitecto |
| PL-02 · Selección de stack | 🔵 | Selector (backend, acceso a datos, motor BD, auth, esquema, despliegue, ambiente) |
| PL-08 · Arquitectura back | 🟣 | **Se deriva del backend** elegido en PL-02 (regla dura) |
| Ambiente permitido | 🟣 | Se deriva del backend (regla de compatibilidad) |
| Mecanismo de configuración | 🟣 | Se deriva del backend (regla de compatibilidad) |

## 3. Reglas de derivación duras (🟣)

Estas reglas no se eligen: una vez decidido el **backend** en PL-02, lo demás queda fijado.
El agente aplica la regla y, si detecta una combinación prohibida, la marca como
inconsistencia.

### 3.1 Backend → Arquitectura

| Backend | Arquitectura resultante | Capas / componentes |
|---------|-------------------------|---------------------|
| .NET Core (.NET 8) | Orientada a servicios, proyecto único | Controladores → Interfaces de Servicios → Servicios |
| .NET Framework 4.8 | 3 capas | DAL/DLL → BLL → Microservicio |
| .NET Framework legacy GS | 3 capas (variante legacy) | Se usa cuando se **extiende un servicio existente** de GS |

### 3.2 Backend → Ambiente permitido

| Backend | Dev/QA permitido | Producción permitido |
|---------|------------------|----------------------|
| .NET Core (.NET 8) | Solo W2022 | Solo Aplicaciones |
| .NET Framework | W2022 o W2016 | Aplicaciones o Portales |

### 3.3 Backend → Mecanismo de configuración

| Backend | Mecanismo de configuración |
|---------|----------------------------|
| .NET Core (.NET 8) | `appsettings.{env}.json` |
| .NET Framework 4.8 | `App.config` / `Web.config` |
| .NET Framework legacy GS | `Res_General.resx` (cadena encriptada + llave del Registro) |

## 4. Flujo de la fase

Los artefactos 🟢 que **no dependen del stack** (PL-05 modelo de datos y PL-06 endpoints) se
generan en **borrador antes de la reunión**, como insumo para decidir el stack; el resto de
🟢 (PL-07, PL-10, PL-11) se completa después.

```
Fase 01 APROBADA (RQ-04 … RQ-08 en estado Approved)
  → PL-00 (clasificación: fija qué es 🟢/🔵/🟣 en este proyecto)
  → 🟢 BORRADOR: PL-05 modelo de datos + PL-06 contrato de endpoints + PL-M prompt de diseño
     visual para Claude (el agente los infiere de los requerimientos; NO dependen del stack;
     PL-M es apoyo no bloqueante de la reunión)
  → PL-G GUÍA DE LA REUNIÓN (orden del día técnico + modelo de datos y endpoints como material)
  → REUNIÓN: el arquitecto decide y justifica stack/ambiente viendo ya datos y operaciones
  → 🔵 el agente rellena los SELECTORES (PL-01 ambientes, PL-02 stack) con lo decidido y
     captura el porqué como DEC-D (Contexto · Decisión · Alternativas · Consecuencias)
  → 🟣 el agente aplica las REGLAS DE DERIVACIÓN (PL-08 arquitectura, PL-09 front,
     ambiente permitido, mecanismo de configuración), según el backend
  → PL-03 · PL-04 (guías de diagrama; el arquitecto dibuja aparte)
  → 🟢 el agente completa el resto desde los requerimientos (PL-07 errores, PL-10 vistas/rutas,
     PL-11 estrategia de pruebas)
  → revisión de consistencia
```

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
