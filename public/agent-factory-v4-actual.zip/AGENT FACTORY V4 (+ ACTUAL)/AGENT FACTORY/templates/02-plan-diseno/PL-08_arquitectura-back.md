# Diseño de arquitectura back

| Campo | Valor |
|-------|-------|
| Documento | PL-08 · Diseño de arquitectura back |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-02-plan-diseno |
| Validó | — |
| Fuentes | [COD]_PL-02 vX; [COD]_PL-03 vX; [COD]_PL-06 vX |

> 🟣 **Auto-derivada.** La arquitectura back **no se elige aparte**: la determina el backend
> seleccionado en PL-02 (regla dura de PL-00). Este documento se queda a **nivel alto**
> (capas, módulos, responsabilidades y distribución del código). **No** incluye firmas de
> métodos (nombre + parámetros + retorno): eso es de la fase de Tareas/Desarrollo.

## 1. Regla de derivación Backend → Arquitectura

| Backend | Arquitectura resultante | Capas / componentes |
|---------|-------------------------|---------------------|
| .NET Core (.NET 8) | Orientada a servicios, proyecto único | Controladores → Interfaces de Servicios → Servicios |
| .NET Framework 4.8 | 3 capas | DAL/DLL → BLL → Microservicio |

## 2. Backend seleccionado

- [ ] **.NET 8 (Core)** — proyecto único → **Opción A**
- [ ] **.NET Framework 4.8** — multi-proyecto → **Opción B**
- [ ] **.NET Framework legacy GS** — 3 capas → **Opción C**

## 3. Patrón según selección

### Opción A · .NET 8 (Core)

Flujo: **Cliente → Controller** (`ControllerBase`, valida JWT) **→ IService → DbContext**
(EF Core) **/ DAL Oracle → BD**.

```text
src/
  Program.cs
  Controllers/
  Services/
    Interfaces/
  Models/
  DTOs/
  Data/
    Migrations/
  DAL/
  Security/
  Middleware/
  lib/
  BaseDeDatos/
  docs/
```

### Opción B · .NET Framework 4.8

Multi-proyecto, 4 capas (`Api` / `Negocio` / `Datos` / `Pruebas`). Hosting OWIN Self-Host
o IIS. IoC con Unity. EF6 o DAL Oracle. Manejo de errores con `FiltroGlobalExcepciones`.

Flujo: **Cliente → ApiController** (Api) **→ IServicio** (Negocio) **→ Repositorio / DAL**
(Datos) **→ BD**.

```text
Solucion/
  Api/
  Negocio/
  Datos/
  Pruebas/
```

### Opción C · legacy GS

3 capas: **Microservicios** (Web API 2) / **BLL** (`clsNegocio`) / **DAL** (`clsBase`).
Hosting IIS + `Global.asax`, sin IoC. SP / packages Oracle vía `DatosGS.dll`. Código con
regiones prefijadas; cadena de conexión encriptada en `Res_General.resx` + llave del
Registro.

Flujo: **Cliente → Microservicio (Web API 2) → BLL (`clsNegocio`) → DAL (`clsBase`) → SP/Package Oracle → BD**.

## 4. Autenticación

- [ ] JWT Bearer
- [ ] Token propio GUID (persistido en BD, validado por SP, vigencia definida)

## 5. Conexión a base de datos

- Connection string **encriptada** (desencriptado en tiempo de ejecución).
- Política de reintentos (retry policy) **si** .NET 8.
- Mecanismo de configuración según backend: `appsettings.{env}.json` (.NET 8) ·
  `App.config` / `Web.config` (.NET Framework 4.8) · `Res_General.resx` (legacy GS).

## 6. Monitoreo y Health Check

Requisito transversal obligatorio.

| Elemento | Descripción |
|----------|-------------|
| Endpoint de health | Punto de verificación de estado del servicio |
| Diagnóstico de conexión a BD | Comprueba que la BD responde |
| Diagnóstico de dependencias externas | Comprueba servicios de los que depende el back |
| Componente sugerido | `MonitoreoController` |
| Respuesta | Estado por componente, **sin exponer datos sensibles** |

## 7. Decisiones de arquitectura (DEC-D breves)

| Decisión | Alternativas | Por qué |
|----------|--------------|---------|
| | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
