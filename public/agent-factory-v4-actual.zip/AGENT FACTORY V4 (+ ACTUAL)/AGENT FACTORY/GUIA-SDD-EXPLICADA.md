# La metodología SDD explicada como una pastelería

> Guía sencilla de cómo funciona la "fábrica" SDD de este proyecto (Pautas · PCM), qué hace
> cada pieza y qué se mejoró el 27 de octubre de 2026. Para el detalle técnico ver
> [README.md](README.md) y [.kiro/steering/sdd-convenciones.md](.kiro/steering/sdd-convenciones.md).

Imagina una **pastelería**. Llega un cliente y pide un pastel para una fiesta. Antes de
prender el horno hay que entender bien qué quiere, decidir con qué ingredientes y en qué
horno se hace, y repartir el trabajo. Si alguien se equivoca en el pedido, el pastel sale
mal aunque esté muy bien horneado.

La metodología SDD es **la forma ordenada en que esta pastelería trabaja**, con ayudantes
robot que hacen el papeleo y personas que deciden y aprueban.

---

## 1. Del pedido a la entrega (las 7 fases)

| # | Fase | En la pastelería |
|---|------|------------------|
| 01 | Requerimientos (RQ) | **Tomar el pedido:** qué pastel quiere, para cuántos, de qué sabor, para cuándo. Es **el QUÉ** |
| 02 | Plan / Diseño (PL) | **Diseñar el pastel:** receta, ingredientes, horno, molde y dibujo del decorado. Es **el CÓMO** |
| 03 | Tareas | Repartir el trabajo: quién hace el bizcocho, quién el relleno, quién decora |
| 04 | Desarrollo | Hornear y decorar |
| 05 | Testing | Probar el pastel antes de entregarlo |
| 06 | Deploy | Empacarlo y llevarlo al lugar de la fiesta |
| 07 | Entrega | El cliente lo recibe y firma de recibido |

**Hoy la pastelería ya tiene funcionando las fases 01 y 02.** Las demás se construirán
después.

---

## 2. Quién es quién en la pastelería

### El manual de la casa (steering)
`.kiro/steering/sdd-convenciones.md`

Es el **manual de la pastelería**: cómo se llenan los formatos, cómo se numeran los pedidos,
qué va en cada hoja y qué no. Si un papel dice una cosa y el manual otra, **manda el
manual**.

### Los dos ayudantes robot (agentes)
`.kiro/agents/`

| Ayudante | Su puesto | Qué hace |
|----------|-----------|----------|
| `sdd-01-requerimientos` | **El que toma los pedidos** | Escucha las grabaciones de las llamadas con el cliente y escribe exactamente qué pastel quiere |
| `sdd-02-plan-diseno` | **El que arma la orden de producción** | Con el pedido ya aprobado y lo que decidió el chef, escribe la receta, los ingredientes y el plan de trabajo |

No se les habla directo: en el chat le pides al encargado (el agente principal)
"**Invoca al subagente sdd-0X-…**" y él los llama.

### El chef pastelero (el arquitecto)
Es una **persona**, no un robot. Él decide lo que el robot no puede decidir solo: qué harina
se usa, qué horno, en qué cocina se prepara y desde qué mostrador se entrega.

### Las recetas (skills)
`.kiro/skills/`

Cada hoja que hay que llenar tiene su **receta paso a paso**, para que el ayudante no se
equivoque.

- **Toma del pedido (9 recetas):** lista de preguntas, cuestionario, nota de la llamada,
  ficha del pedido, deseos del cliente, reglas de la casa, paso a paso de cada pedido,
  pruebas de calidad y revisión final.
- **Orden de producción (15 recetas):** quién decide qué, guía para la junta con el chef,
  boceto del decorado, cocinas, ingredientes y hornos, mapa de la cocina, recorrido del
  pedido, lista de ingredientes, ventanillas de pedido, qué hacer si algo sale mal, cómo
  se organiza el obrador, cómo se organiza el mostrador, vitrinas, plan de pruebas y
  revisión final.

### Los formatos en blanco (plantillas)
`templates/`

Son los **formatos de pedido con los cuadritos ya impresos**. El ayudante solo los llena.

### El manual para empleados (instructivos)
`instructivos/`

Explican **a las personas** cómo llenar los formatos más difíciles.

### Las grabaciones y la nota del chef (insumos)
- `transcripciones discovery/` → **las grabaciones de las llamadas con el cliente**.
  Con ellas se toma el pedido.
- `transcripciones diseno/` → **la junta con el chef**, donde decide ingredientes y hornos.
  Si la junta **no se grabó**, aquí va **la nota firmada del chef (acta)**.

### La carpeta del pedido (documentación)
`documentacion/01-requerimientos/` y `documentacion/02-plan-diseno/` → aquí quedan los
formatos ya llenos de este pedido.

### Los supervisores de calidad (hooks), nuevos
`.kiro/hooks/sdd-calidad.json` y `.kiro/scripts/`

Vigilan al ayudante robot mientras llena los formatos. Se explican en la sección 6.

---

## 3. Fase 01: tomar el pedido

1. **Después de cada llamada con el cliente**, el ayudante que toma pedidos:
   - marca la **lista de preguntas** (¿ya preguntamos sabor, tamaño, fecha, alergias?);
   - llena el **cuestionario** con lo que contestó el cliente, con sus propias palabras;
   - escribe la **nota de la llamada (minuta)**: lo que se decidió y lo que quedó pendiente
     de preguntar.
2. **Cuando ya no hay dudas importantes**, llena en orden:
   - la **ficha del pedido** (para qué es, quiénes lo van a comer, qué incluye y qué no);
   - los **deseos del cliente** ("como festejado quiero un pastel de chocolate…");
   - las **reglas de la casa** ("los pedidos grandes se piden con 2 semanas de anticipación");
   - el **paso a paso de cada pedido** (qué pasa si el cliente cambia el sabor, si cancela…);
   - las **pruebas de calidad** ("el pastel DEBERÁ alcanzar para 50 personas").
3. **Cuando el cliente contesta una duda**, el ayudante la corrige en **todos** los
   formatos donde aparecía.

---

## 4. Fase 02: armar la orden de producción

El ayudante sabe que **no todo lo puede decidir él**:

| Color | Quién decide | Ejemplo en la pastelería |
|-------|--------------|--------------------------|
| 🟢 | El ayudante lo saca del pedido | Cuántas capas lleva, qué texto va escrito en el pastel |
| 🔵 | **El chef decide** en la junta | Qué harina, qué horno, en qué cocina se hace |
| 🟣 | Sale solo de una decisión del chef | Si el chef eligió el horno de convección, la temperatura y el tiempo ya están dados |

Por eso trabaja en **dos tiempos**:

- **Antes de la junta con el chef (Modo A):** prepara el material:
  - la tabla de quién decide qué;
  - el borrador de la lista de ingredientes y de las ventanillas de pedido;
  - el boceto del decorado;
  - la **guía de la junta**, con las preguntas que el chef tiene que contestar.
- **Después de la junta (Modo B):** con lo que decidió el chef:
  - llena qué cocinas y qué ingredientes se usan;
  - deduce cómo se organizan el obrador y el mostrador;
  - completa el resto de la orden de producción.

---

## 5. Las reglas de oro de la pastelería

- **Nunca inventar.** Si algo no se dijo, el ayudante lo marca:
  - `[Inferido]` = "lo deduje yo";
  - `[Propuesto]` = "lo sugiero yo";
  - `⚠️ POR CONFIRMAR (PEN-###)` = "falta preguntarle al cliente".
- **Cada dato tiene un solo dueño.** Por ejemplo, el texto exacto que va escrito en el
  pastel solo se anota en las pruebas de calidad (RQ-08), y los pendientes solo en la nota
  de la llamada.
- **Solo se mira hacia atrás.** Un formato copia datos de los formatos que ya existían,
  nunca de los que todavía no se llenan.
- **El ayudante no se pone el sello de "aprobado".** Él solo puede marcar un formato como
  "borrador" o "listo para revisar". "Revisado" y "Aprobado" los pone una persona.
- **Antes de pasar a la cocina, una revisión.** Se revisa que todo cuadre: que no falte
  ningún deseo del cliente y que nada de la orden salga de la nada.

---

## 6. Lo que se mejoró (27 de octubre de 2026)

### 6.1 La nota firmada del chef (acta)

**Problema:** el ayudante escribió la orden de producción diciendo "esto lo decidió el
chef", pero **no había grabación ni nota** de esa junta. Era como cocinar con una receta que
nadie sabe quién autorizó.

**Arreglo:**
- Se creó un **formato para anotar las decisiones del chef** cuando la junta no se graba:
  `templates/02-plan-diseno/PL-A_acta-decisiones-diseno.md`.
- Se guardó la nota de Pautas en `transcripciones diseno/txt/PCM_acta-decisiones-diseno.md`:
  - **Fecha:** 26 de octubre de 2026.
  - **Quién estuvo:** Luis Angel Ramirez Sanchez (Arquitecto de Soluciones, el chef que
    decidió), Ana Patricia Vazquez Nava (Frontend) y Jose Antonio Cordero Daniel (Backend).
  - **Qué se eligió:** .NET 8, EF Core, Oracle, token GUID, migraciones EF, GitLab para el
    back, TFS para el front, W2022, Aplicaciones y Huawei.
  - **Por qué se eligieron las cocinas:**
    - en **Desarrollo** (la cocina de pruebas), el mostrador y el obrador comparten **la
      misma mesa**;
    - en **Producción** van separados: **Huawei** es el mostrador que da a la calle (con
      internet) y **Aplicaciones** es el obrador interno (solo red interna).
- El ayudante **ya no acepta decisiones dichas de palabra en el chat**: tiene que existir
  la grabación o la nota firmada.
- Si la nota no dice **por qué** se eligió un ingrediente, el ayudante marca su explicación
  como `[Inferido]`. Hoy siguen así las razones de backend, ORM, base de datos,
  autenticación y esquema.

### 6.2 "Yo te copio y tú me copias"

**Problema:** el formato de cocinas (PL-01) decía "lo saqué del formato de ingredientes" y
el de ingredientes (PL-02) decía "lo saqué del formato de cocinas". Ninguno tenía la fuente
real.

**Arreglo:** ahora los dos sacan su información de la nota firmada del chef.

### 6.3 El camino del cliente al obrador

**Problema:** la orden dibujaba al cliente entrando **directo al obrador** a pedir su
pastel. Pero el obrador (Aplicaciones) solo tiene acceso interno: desde la calle no se puede
entrar.

**Arreglo:** ya existe un permiso para que el mostrador (Huawei) se comunique con el
obrador. El camino quedó así: el **mesero del mostrador** recibe el pedido y lo pasa por la
ventanilla interna.

```text
Cliente (internet) → Mostrador Huawei (atiende y pasa el pedido) → Obrador Aplicaciones (backend) → Almacén Oracle
```

Se actualizaron PL-01, PL-03 y PL-09. Falta que el chef confirme **cómo** pasa los pedidos el
mesero; por ejemplo, con nginx o Apache como proxy inverso.

### 6.4 Los supervisores de calidad (hooks)

**Antes no había ningún supervisor.** Ahora hay dos:

| Supervisor | Cuándo actúa | Qué hace |
|------------|--------------|----------|
| 🛑 **El de la puerta de la cocina** (`PreToolUse`) | **Antes** de que el ayudante escriba | **Lo detiene** si quiere ponerse el sello de "Aprobado", si usa palabras prohibidas como `[Por definir]` o si quiere llenar cocinas e ingredientes sin la nota del chef |
| 🔍 **El inspector** (`PostFileSave`) | **Después** de que el ayudante guarda | **Avisa** si al formato le falta el encabezado o el historial, si el nombre del archivo está mal, si el estado no corresponde a los pendientes, si menciona un pendiente que no está en la nota de la llamada o si dice "lo saqué de X" y X no existe |

Son programas pequeños de PowerShell: **no gastan tokens** y no se quedan dando vueltas.
Solo vigilan lo que escribe el ayudante robot. Lo que una persona edita a mano se puede
revisar con:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .kiro/scripts/sdd-check.ps1 documentacion/02-plan-diseno/PCM_PL-01_seleccion-ambientes.md
```

### 6.5 Lo que encontró el inspector (y se corrigió)

- **El mapa de la cocina y el recorrido del pedido** (PL-03 y PL-04) pedían los dibujos
  `.drawio` como pendientes (PEN-051 y PEN-052), pero esos pendientes no estaban anotados en
  la nota de la llamada. Ya se anotaron.
- **La lista de preguntas** (checklist) estaba en borrador aunque ya no tenía pendientes. Se
  pasó a "listo para revisar".

### 6.6 Las fechas del pedido

- Se anotaron los tres hitos en la nota de la llamada como **DEC-010**, contados desde la
  primera llamada (20 de octubre):

  | Hito | En la pastelería | Cuándo |
  |------|------------------|--------|
  | Prototipo | La **prueba de sabor** que se le da al cliente | **3 de noviembre de 2026** (2 semanas) |
  | Desarrollo en QA | El pastel **terminado para degustación** | **17 de noviembre de 2026** (4 semanas) |
  | Entregable final | **Entrega del pastel** en la fiesta | **1 de diciembre de 2026** (6 semanas) |

- Se anotaron en la ficha del pedido y en la lista de preguntas.
- Se quitaron de una prueba de calidad, porque una prueba dice **cómo debe quedar el
  pastel**, no el calendario de entrega.

### 6.7 "No hay" también es una respuesta

Si el cliente dice "**no tengo** fecha para la fiesta", eso se marca ✅, porque **ya sabemos
la respuesta**. ❌ es solo cuando **no le preguntamos** o no contestó. Ahora lo dicen igual
el manual de la casa, la receta de la lista de preguntas y su formato en blanco.

### 6.8 Se ordenó el manual de la casa

- Se arregló una tabla que estaba rota.
- Se agregaron nombres de formatos que faltaban (PL-00, PL-G, PL-J, PL-M y PL-A).
- El README explica todo esto.

---

## 7. Lo que todavía falta

- [ ] Que el chef diga **por qué** eligió .NET 8, EF Core, Oracle, el token GUID y las
      migraciones EF, para quitar los `[Inferido]`.
- [ ] Que el chef confirme **cómo** el mesero del mostrador (Huawei) pasa los pedidos al
      obrador (Aplicaciones), antes de la prueba de sabor del 3 de noviembre.
- [ ] Que el chef dibuje y adjunte el mapa de la cocina y el recorrido del pedido en
      `.drawio` (PEN-051 y PEN-052).
- [ ] Que una persona revise y **apruebe** los formatos de la toma del pedido, que siguen en
      borrador.
- [ ] Probar los supervisores dentro de Kiro; hasta ahora solo se probaron con simulacros.
- [ ] Construir las fases 03 a 07: repartir tareas, hornear, probar, empacar y entregar.
