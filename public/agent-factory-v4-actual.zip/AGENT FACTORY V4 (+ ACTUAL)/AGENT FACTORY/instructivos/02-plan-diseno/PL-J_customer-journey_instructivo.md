# Instructivo — PL-J Prompt de customer journey (para Claude)

> Guía para llenar `templates/02-plan-diseno/PL-J_customer-journey.md`: qué fases derivar, de
> dónde sale la información y qué hace que un customer journey esté bien planteado.
>
> **Quién lo llena:** el agente `sdd-02-plan-diseno` genera el borrador y **el Arquitecto /
> Product Manager** lo valida antes de llevarlo al cliente a firmar.
> **Convenciones comunes** (IDs, marcadores, estados): `.kiro/steering/sdd-convenciones.md`.

---

## 1. ¿Qué es un customer journey (y qué NO lo es)?

Un **customer journey** es el recorrido de **NUESTRO CLIENTE** —la persona o área que nos
hace la petición y firma el proyecto— desde su necesidad inicial hasta el valor que recibe.
Muestra, fase por fase, **qué hace**, **cuál es su dolor hoy** (sin el sistema) y **qué
cambia** con el sistema. Es la pieza que el cliente **firma** para acordar el alcance.

- ✅ **Sí es:** "El cliente envía su brief (fase Solicitud); hoy no sabe si llegó a tiempo
  (dolor); con el sistema recibe confirmación inmediata (qué cambia)".
- ❌ **No es:** el **diagrama de flujo técnico** ni la **máquina de estados** (eso es de
  RQ-07 / PL-04) · tampoco el **diseño de pantallas** (eso es PL-M).

> Regla de oro: el journey cuenta la **experiencia y el valor** para quien firma, no la
> mecánica interna del sistema.

---

## 2. De quién es el journey (la confusión más común)

El journey es **siempre sobre nuestro cliente**: quien nos contrata y recibe el producto.
**Nunca** es un journey por roles internos del sistema (ejecutivo, diseñador, etc.).

Cuidado con un matiz: nuestro cliente puede a su vez **tener sus propios clientes** o
audiencia. Aun así, el mapa es sobre **quien firma con nosotros**, no sobre los clientes de
nuestro cliente ni sobre los roles operativos.

---

## 3. Insumos

- **RQ-04 (problemas `P` y objetivos):** los `P` son el "dolor de hoy" de cada fase; los
  objetivos/`INC` son el "qué cambia".
- **RQ-05 (historias `HU`):** lo que el cliente hace en cada fase.
- **RQ-07 (casos de uso `CU`):** el orden de las fases, las bifurcaciones (urgencia,
  excepción, regresos) y el estatus relacionado.

---

## 4. Cómo derivar las fases

1. Ordena el recorrido de **la necesidad al valor** (de antes del sistema hasta el cierre).
2. Por cada fase, llena las tres capas: **lo que hace**, **dolor de hoy**, **qué cambia**.
3. Marca los **momentos de la verdad** (⭐): las fases decisivas para la relación (p. ej.
   enviar la solicitud, aprobar, ver publicada su campaña).
4. Marca las **bifurcaciones**: dónde el recorrido se ramifica (urgente, fuera de tiempo,
   regreso a una mesa, excepción), diferenciadas de la ruta principal.
5. Indica el **estatus relacionado** de RQ-07 cuando la fase tenga uno, para que PL-M pueda
   conectar la pantalla.

> Las fases **previas al sistema** (p. ej. "Necesidad") son válidas en el journey pero **no
> generan pantalla** en el diseño.

---

## 5. Relación con el diseño (PL-M): el journey acota el alcance

El customer journey es lo que el cliente **firma**, y por eso **define qué pantallas cubre el
diseño**: PL-M solo genera pantallas de las fases del journey donde el cliente tiene una
acción. Esto evita que el diseño abra en una pantalla que el cliente no esperaba (p. ej. un
tablero operativo) y mantiene el alcance acordado.

PL-J se elabora **antes** que PL-M, pero **no es bloqueante**: pueden mostrarse juntos al
cliente en la misma reunión.

---

## 6. El prompt para Claude

Igual que PL-M, el journey "bonito" lo genera **Claude**: PL-J contiene las **fases
derivadas** (sección 1 de la plantilla) **más el prompt** (sección 2). El resultado —el
artifact del mapa— lo pega el cliente. El prompt debe:

- Dejar claro de quién es el journey (nuestro cliente, no roles internos).
- Pedir las tres capas por fase, los momentos de la verdad y las bifurcaciones.
- Exigir una **propuesta visual no genérica** con identidad de marca (Grupo Salinas por
  defecto: amarillo `#FFCD00`, gris `#5E5E61`), presentable para firmar.
- Incluir una sección de **preguntas por validar** con el cliente para lo no confirmado.

---

## 7. Trazabilidad: cada fase con su origen

Cada fase cita el `P`/objetivo de RQ-04, la `HU` de RQ-05 o el `CU` de RQ-07 que la origina.
Así la revisión de consistencia comprueba que el journey no inventa pasos y que cubre el
recorrido real del cliente.

> No reescribas el contenido del requisito: **cita el ID**.

---

## 8. Errores comunes

- ❌ Hacer el journey **por roles internos** del sistema en vez de sobre nuestro cliente.
- ❌ Confundirlo con el **flujo técnico** (los 11 estatus / la máquina de estados): esa
  mecánica es de RQ-07.
- ❌ Inventar dolores o fases que no salen de RQ-04/RQ-05/RQ-07.
- ❌ Generar pantallas en PL-M para fases que **no** están en el journey firmado.
- ❌ Dejar fases sin citar su origen (rompe la trazabilidad).
- ❌ Entregar un mapa genérico y sin identidad de marca (no sirve para firmarlo).
- ❌ Dejar lo no confirmado sin marcar (`[Inferido]`, `[Propuesto]`, `⚠️ POR CONFIRMAR`).

---

## 9. Checklist final

- [ ] El journey es sobre **nuestro cliente** (el que firma), no por roles internos.
- [ ] Las fases van en orden, de la necesidad al valor.
- [ ] Cada fase tiene "lo que hace / dolor de hoy / qué cambia".
- [ ] Están marcados los momentos de la verdad (⭐) y las bifurcaciones.
- [ ] Cada fase cita su origen (`P`/`OBJ` de RQ-04, `HU` de RQ-05 o `CU` de RQ-07).
- [ ] El prompt para Claude está completo (de quién es, qué mostrar, propuesta visual,
      preguntas por validar).
- [ ] Queda claro que PL-J acota el alcance de PL-M y se elabora antes (no bloqueante).
- [ ] Lo no confirmado está marcado con `[Inferido]` / `[Propuesto]` / `⚠️ POR CONFIRMAR`.
- [ ] El Arquitecto / PM validó el journey antes de llevarlo a firmar.
