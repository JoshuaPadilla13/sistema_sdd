# Instructivo — PL-05 Diccionario de datos, modelo de datos e interfaces

> Guía para llenar `templates/02-plan-diseno/PL-05_diccionario-modelo-datos.md`: qué va en cada columna,
> de dónde sale la información y qué hace que una entidad o un campo estén bien descritos.
>
> **Quién lo llena:** el agente `sdd-02-plan-diseno` genera el borrador y **Luis (o el
> arquitecto)** valida que el modelo refleje el dominio.
> **Convenciones comunes** (IDs, marcadores, estados): `.kiro/steering/sdd-convenciones.md`.

---

## 1. ¿Qué es un diccionario / modelo de datos (y qué NO lo es)?

Un **diccionario de datos** describe las **entidades** del dominio (los "sustantivos" que
el sistema guarda) y los **campos** de cada una, diciendo de qué tipo son, si son
obligatorios y si son sensibles. El **modelo de datos** añade cómo se relacionan esas
entidades entre sí.

- ✅ **Sí es:** "La entidad Cliente tiene los campos id, nombre, rfc y correo; el correo es
  obligatorio; el rfc es sensible", "Un Cliente tiene muchos Pedidos".
- ❌ **No es:** el DDL / script SQL final (`CREATE TABLE …`), ni los índices, ni el motor de
  base de datos (eso es implementación, fase de Desarrollo) · tampoco son endpoints
  (`POST /clientes` va en PL-06) · ni mensajes al usuario (RQ-08).

> Regla de oro: aquí describimos **qué datos existen y cómo se relacionan**, en lenguaje de
> dominio. El cómo se crean las tablas y por dónde se consultan se define más adelante.

---

## 2. Insumos

- **RQ-04 Documento base — glosario:** cada término del glosario suele ser una entidad o un
  campo candidato.
- **RQ-06 Reglas de negocio (`RN`):** las reglas de validación/restricción marcan qué campos
  son obligatorios, únicos o tienen formato, y se citan en la columna Regla.
- **RQ-07 Casos de uso (`CU`):** los datos que se capturan, consultan o modifican en los
  flujos revelan entidades y campos.

> Frases que suelen esconder una entidad o campo: **"se registra un…", "cada [cosa] tiene…",
> "el [dato] del cliente", "un pedido con varios productos"**.

---

## 3. Columna por columna de la plantilla

### 3.1 Tabla de entidades (sección 1)

| ID | Entidad | Descripción | Origen (glosario RQ-04 / CU-###) |
|----|---------|-------------|----------------------------------|

- **`ID`** → `ENT-001`, `ENT-002`… consecutivo. Si una entidad se elimina, su ID queda
  retirado y no se reasigna.
- **`Entidad`** → el nombre del concepto del dominio, en singular: Cliente, Pedido, Factura.
- **`Descripción`** → una línea que explica qué representa.
- **`Origen`** → de dónde sale: el término del glosario de RQ-04 o el `CU` que la usa. Si no
  se puede rastrear, márcala `[Inferido]` o `[Propuesto]`.

### 3.2 Diccionario de campos por entidad (sección 2)

| ID | Campo | Tipo | Obligatorio | Sensible | Descripción | Regla (RN-###) |
|----|-------|------|-------------|----------|-------------|----------------|

- **`ID`** → `ENT-001.CAM-01`, `ENT-001.CAM-02`… El campo "pertenece" a su entidad.
- **`Campo`** → el nombre del dato: id, nombre, rfc, correo, fecha_registro.
- **`Tipo`** → tipo de dato en lenguaje neutro: texto, número, decimal, fecha, booleano,
  identificador. No pongas tipos de un motor concreto (`VARCHAR(50)`, `NUMBER`): eso es
  implementación.
- **`Obligatorio`** → `Sí` / `No`. ¿El sistema puede guardar el registro sin este dato?
- **`Sensible`** → `Sí` / `No`. Ver la sección 4.
- **`Descripción`** → qué es el campo, en una línea.
- **`Regla (RN-###)`** → si una regla de negocio aplica al campo (formato, unicidad, rango),
  cita su `RN`. Si no aplica ninguna, deja `N/A`. **No reescribas la regla**, solo cita el ID.

### 3.3 Relaciones entre entidades (sección 3)

| Entidad origen | Relación | Entidad destino |
|----------------|----------|-----------------|

Ver la sección 5.

---

## 4. ¿Qué cuenta como dato **sensible**?

Un dato es **sensible** cuando, si se filtra o se usa mal, puede dañar a una persona o al
negocio. Marcarlo importa porque condiciona la seguridad y la privacidad (quién lo ve, si
se cifra, si se registra en logs). Se decide en PL-07 y en la estrategia de pruebas.

Cuentan como sensibles, entre otros:

- **Datos personales:** nombre completo, RFC/CURP, dirección, teléfono, correo, fecha de
  nacimiento, identificaciones oficiales.
- **Datos financieros:** número de tarjeta, cuenta bancaria, CLABE, saldos.
- **Credenciales y secretos:** contraseñas, tokens, respuestas de seguridad.
- **Datos de salud** o cualquier categoría protegida por ley.

No suelen ser sensibles: un identificador interno autogenerado, el nombre de un producto,
un estatus ("ACTIVO"), una fecha de creación del registro.

> Ojo: **sensible ≠ obligatorio**. Un correo puede ser obligatorio y además sensible; un
> identificador interno es obligatorio pero no sensible. Son dos columnas distintas.

---

## 5. ¿Entidad o campo? ¿Y cómo describo las relaciones?

**¿Es entidad o campo?**

- Es **entidad** si tiene vida propia y varios atributos, y de ella puede haber muchos
  registros: Cliente, Pedido, Producto.
- Es **campo** si es un dato simple que describe a una entidad: el nombre del cliente, el
  total del pedido.
- Pista: si de "algo" puede haber una lista y ese algo tiene sus propios datos, es una
  entidad (un Pedido tiene varios Productos → Producto es entidad).

**Relaciones** (en lenguaje simple):

| Tipo | Qué significa | Ejemplo |
|------|---------------|---------|
| **1:1** | Un registro de A se relaciona con **uno** de B | Un Cliente tiene un Perfil |
| **1:N** | Un registro de A se relaciona con **varios** de B | Un Cliente tiene varios Pedidos |
| **N:M** | Varios de A con varios de B | Un Pedido tiene varios Productos y un Producto está en varios Pedidos |

En la sección 3 se escribe así: `Entidad origen = Cliente · Relación = 1:N · Entidad
destino = Pedido`.

---

## 6. Ejemplo bien llenado

**Entidades**

| ID | Entidad | Descripción | Origen |
|----|---------|-------------|--------|
| ENT-001 | Cliente | Persona o empresa que compra. | RQ-04 glosario · CU-001 |
| ENT-002 | Pedido | Solicitud de compra de un cliente. | CU-002 |

**Campos de ENT-001 — Cliente**

| ID | Campo | Tipo | Obligatorio | Sensible | Descripción | Regla (RN-###) |
|----|-------|------|-------------|----------|-------------|----------------|
| ENT-001.CAM-01 | id | identificador | Sí | No | Identificador interno del cliente. | N/A |
| ENT-001.CAM-02 | rfc | texto | Sí | Sí | RFC del cliente; único. | RN-001 |
| ENT-001.CAM-03 | correo | texto | Sí | Sí | Correo de contacto; formato válido. | RN-006 |
| ENT-001.CAM-04 | tipo | texto | Sí | No | "Persona" o "Empresa". | N/A |

**Relaciones**

| Entidad origen | Relación | Entidad destino |
|----------------|----------|-----------------|
| Cliente | 1:N | Pedido |

---

## 7. Errores comunes

- ❌ Confundir **sensible** con **obligatorio**: son dos preguntas distintas (ver sección 4).
- ❌ Meter **endpoints** o rutas (`POST /clientes`): eso es PL-06.
- ❌ Escribir el **DDL / SQL** o tipos de un motor concreto (`VARCHAR(50)`): es implementación.
- ❌ **Inventar campos** sin origen en el glosario, en una `RN` o en un `CU`.
- ❌ Reescribir la regla en la columna Regla en vez de **citar el `RN-###`**.
- ❌ Dejar un valor dudoso sin marcar: usa `⚠️ POR CONFIRMAR (PEN-###)`.
- ❌ Tratar como campo algo que en realidad es una entidad con sus propios datos.

---

## 8. Checklist final

- [ ] Cada entidad tiene ID `ENT-###` y cita su origen (glosario RQ-04 o `CU`).
- [ ] Cada campo tiene ID `ENT-###.CAM-##`, tipo neutro, Obligatorio y Sensible.
- [ ] Los datos personales, financieros y credenciales están marcados como sensibles.
- [ ] Los campos con regla citan su `RN-###` (sin reescribirla); el resto dice `N/A`.
- [ ] Las relaciones entre entidades están definidas (1:1, 1:N o N:M).
- [ ] No hay endpoints, DDL/SQL ni mensajes al usuario.
- [ ] Lo no confirmado está marcado con `[Inferido]`, `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.
- [ ] Luis (o el arquitecto) validó que el modelo refleja el dominio real.
