# Instructivo — PL-06 Contrato de endpoints

> Guía para llenar `templates/02-plan-diseno/PL-06_contrato-endpoints.md`: qué va en cada parte de un
> endpoint, de dónde sale la información y qué hace que un contrato esté bien escrito.
>
> **Quién lo llena:** el agente `sdd-02-plan-diseno` genera el borrador y **Andrés (o el
> responsable de back)** valida que el contrato sea correcto.
> **Convenciones comunes** (IDs, marcadores, estados): `.kiro/steering/sdd-convenciones.md`.

---

## 1. ¿Qué es un contrato de endpoints (y qué NO lo es)?

Un **contrato de endpoints** es el acuerdo entre el front y el back: qué operaciones expone
el sistema por la API, con qué ruta y método se llaman, qué datos reciben y qué devuelven.
Es un **contrato**: el front puede programar contra él aunque el back aún no exista.

- ✅ **Sí es:** "`POST /clientes` recibe un cliente en el cuerpo, devuelve el cliente creado
  con su id y responde 201 si todo sale bien".
- ❌ **No es:** la **implementación** (el controlador, el Service, el código que guarda en la
  BD) → eso es la fase de Desarrollo · tampoco es el **catálogo y la estrategia de errores**
  (`ERR`, mensajes de log, formato de respuesta de error) → eso es PL-07; aquí solo se
  **listan** los códigos de estado.

> Regla de oro: el contrato describe **qué entra y qué sale por cada endpoint**, no cómo se
> procesa por dentro ni cómo se gestionan los errores a detalle.

---

## 2. Insumos

- **PL-05 Diccionario / modelo de datos (`ENT`, `CAM`):** los cuerpos JSON de petición y
  respuesta se arman con las entidades y campos ya definidos. No redefinas tipos aquí.
- **RQ-07 Casos de uso (`CU`):** cada operación que necesita un paso de un caso de uso suele
  volverse un endpoint.
- **RQ-06 Reglas de negocio (`RN`):** las reglas que aplica una operación se citan como
  origen (p. ej. unicidad del RFC al crear un cliente).

> Pista: por cada verbo de un caso de uso ("registrar", "consultar", "actualizar",
> "eliminar") suele haber un endpoint.

---

## 3. Parte por parte de un endpoint (`EP`)

### `ID` y nombre
`EP-001`, `EP-002`… consecutivo, con un nombre corto ("Crear cliente").

### Ruta
La dirección donde se llama: `/clientes`, `/clientes/{id}`, `/pedidos/{id}/productos`.

### Método (cuándo usar cada uno)

| Método | Para qué | Ejemplo |
|--------|----------|---------|
| **GET** | Consultar / leer (no modifica nada) | `GET /clientes`, `GET /clientes/{id}` |
| **POST** | Crear un recurso nuevo | `POST /clientes` |
| **PUT** | Reemplazar / actualizar un recurso existente | `PUT /clientes/{id}` |
| **DELETE** | Eliminar un recurso | `DELETE /clientes/{id}` |

### Parámetros (ruta vs query)

- **Parámetro de ruta:** identifica **cuál** recurso, va dentro de la ruta entre llaves:
  `/clientes/{id}` → `id` es parámetro de ruta.
- **Parámetro de query:** filtra, ordena o pagina, va después del `?`:
  `/clientes?tipo=Empresa&pagina=2` → `tipo` y `pagina` son de query.

### Cuerpo de petición (JSON)
Lo que el front **envía**. Se usa en POST/PUT. Se arma con los campos `CAM` de la entidad de
PL-05. En GET/DELETE normalmente no hay cuerpo.

### Respuesta (JSON)
Lo que el back **devuelve**. También se arma con los campos de PL-05 (p. ej. el recurso
creado, incluyendo su `id`).

### Códigos de estado (en lenguaje simple)

| Código | Qué significa |
|--------|---------------|
| **200** | OK: la operación salió bien (típico de GET/PUT). |
| **201** | Creado: se creó un recurso nuevo (típico de POST). |
| **400** | Petición mal formada: faltan datos o el formato es inválido. |
| **401** | No autenticado: no sabemos quién eres (falta o es inválido el inicio de sesión). |
| **403** | Autenticado pero sin permiso: sabemos quién eres, pero no puedes hacerlo. |
| **404** | No encontrado: el recurso pedido no existe. |
| **500** | Error del servidor: algo falló del lado del sistema. |

Aquí **solo se listan** los códigos que puede devolver el endpoint. El detalle de cada error
(mensaje, log, formato) vive en PL-07.

### Propósito
Una línea que explica para qué sirve el endpoint.

---

## 4. Buenas prácticas de nombrado de rutas

- **Sustantivos en plural, no verbos:** `/clientes`, no `/crearCliente` (el verbo ya lo da el
  método).
- **Jerarquía con sub-recursos:** `/pedidos/{id}/productos` para "los productos de un pedido".
- **Identificadores como parámetro de ruta:** `/clientes/{id}`, no `/clientes?id=5` para leer
  uno concreto.
- **Minúsculas y guiones** si hace falta separar: `/ordenes-compra`.
- **Filtros y paginación como query:** `/clientes?tipo=Empresa&pagina=2`.

---

## 5. Ejemplo bien llenado

**Catálogo**

| ID | Endpoint | Método | Propósito | Origen |
|----|----------|--------|-----------|--------|
| EP-001 | /clientes | POST | Registrar un cliente nuevo. | CU-001 · RN-001 |

**EP-001 — Crear cliente**

- **Ruta:** `/clientes`
- **Método:** POST
- **Parámetros:** ninguno (el cliente va en el cuerpo).

**Cuerpo de petición** (campos de ENT-001 de PL-05):

```json
{
  "rfc": "XAXX010101000",
  "correo": "contacto@acme.com",
  "tipo": "Empresa"
}
```

**Respuesta** (201):

```json
{
  "id": 1024,
  "rfc": "XAXX010101000",
  "correo": "contacto@acme.com",
  "tipo": "Empresa"
}
```

**Códigos de respuesta**

| Código | Significado |
|--------|-------------|
| 201 | Cliente creado. |
| 400 | Faltan datos o el RFC/correo tiene formato inválido. |
| 409 | Ya existe un cliente con ese RFC (RN-001). |

**Para qué sirve:** da de alta un cliente a partir del flujo principal de CU-001.

---

## 6. Errores comunes

- ❌ Meter **lógica de negocio** o cómo se implementa por dentro (Service, repositorio): eso
  es la fase de Desarrollo.
- ❌ Mezclar el **catálogo de errores** (mensajes, logs, formato de error): es PL-07; aquí
  solo se listan los códigos.
- ❌ **Redefinir tipos de dato** en los JSON en lugar de usar los campos `CAM` de PL-05.
- ❌ No **citar el `CU`/`RN`** de origen de cada endpoint.
- ❌ Rutas con **verbos** (`/crearCliente`) o con el id en query para leer uno concreto.
- ❌ Usar el **método equivocado** (crear con GET, consultar con POST).
- ❌ Dejar datos dudosos sin marcar: usa `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.

---

## 7. Checklist final

- [ ] Cada endpoint tiene ID `EP-###`, ruta, método, propósito y origen (`CU`/`RN`).
- [ ] Los cuerpos JSON de petición y respuesta usan las `ENT`/`CAM` de PL-05 (sin redefinir tipos).
- [ ] Los parámetros están clasificados correctamente (ruta vs query).
- [ ] El método corresponde a la operación (GET leer, POST crear, PUT actualizar, DELETE borrar).
- [ ] Se listan los códigos de estado, sin entrar al catálogo de errores (eso es PL-07).
- [ ] Las rutas siguen las buenas prácticas de nombrado (sustantivos en plural, etc.).
- [ ] Lo no confirmado está marcado con `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.
- [ ] Andrés (o el responsable de back) validó que el contrato es correcto.
