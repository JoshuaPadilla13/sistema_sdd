# Instructivo — PL-11 Estrategia de pruebas

> Guía para llenar `templates/02-plan-diseno/PL-11_estrategia-pruebas.md`: qué tipos de prueba definir, de
> dónde sale la información y qué hace que una estrategia esté bien planteada.
>
> **Quién lo llena:** el agente `sdd-02-plan-diseno` genera el borrador y **el Arquitecto**
> valida la estrategia.
> **Convenciones comunes** (IDs, marcadores, estados): `.kiro/steering/sdd-convenciones.md`.

---

## 1. ¿Qué es una estrategia de pruebas (y qué NO lo es)?

Una **estrategia de pruebas** es el plan de alto nivel de **cómo se va a probar** el
proyecto: qué tipos de prueba se harán, qué cubre cada uno, con qué herramienta, qué queda
fuera y cuándo se considera "probado". Es el mapa, no el recorrido detallado.

- ✅ **Sí es:** "Habrá pruebas unitarias del cálculo de IVA con xUnit; pruebas de integración
  de los endpoints de clientes; una prueba E2E del alta de cliente de punta a punta".
- ❌ **No es:** los **casos de prueba detallados** (paso a paso, datos de entrada esperados,
  Gherkin): eso es la **fase 05 Testing** · tampoco es la configuración de CI/CD (fase de
  Deploy).

> Regla de oro: aquí decimos **qué se probará y con qué criterio se da por bueno**, no el
> detalle de cada caso. El "qué exactamente verifico en este escenario" se escribe después.

---

## 2. Insumos

- **RQ-08 Criterios de aceptación (`REQ`):** son lo que hay que verificar. Cada tipo de
  prueba (`TPR`) existe para cubrir ciertos `REQ`.
- **PL-05 Diccionario / modelo de datos (`ENT`):** indica qué entidades y validaciones hay
  que probar (unicidad, obligatorios, datos sensibles).
- **PL-06 Contrato de endpoints (`EP`):** los endpoints son el objetivo natural de las
  pruebas de integración y E2E.

---

## 3. Los tipos de prueba (`TPR`)

| Tipo | Qué prueba | Ejemplo |
|------|-----------|---------|
| **Unitaria** | Una pieza pequeña y aislada (una función, un cálculo, una regla), sin BD ni red | Verificar que el cálculo de IVA (16 % del subtotal) da el resultado correcto |
| **Integración** | Varias piezas trabajando juntas (p. ej. un endpoint con su capa de datos) | Llamar `POST /clientes` y comprobar que el cliente queda guardado y responde 201 |
| **E2E** (de punta a punta) | Un flujo completo como lo vive el usuario, por la interfaz real | Entrar, dar de alta un cliente y verlo aparecer en la lista |

**La pirámide de pruebas** (de forma simple):

```
        /\        E2E        → pocas (lentas y frágiles, pero realistas)
       /  \
      /----\      Integración → algunas
     /      \
    /--------\    Unitarias    → muchas (rápidas y baratas: la base)
```

La idea: **muchas pruebas unitarias en la base, algunas de integración en el medio y pocas
E2E en la cima**. Las unitarias son rápidas y baratas, así que son la mayoría; las E2E son
lentas y se rompen con facilidad, así que se reservan para los flujos más importantes.

---

## 4. "Qué NO entra en las pruebas" y por qué declararlo

Siempre hay cosas que, de forma deliberada, **no se prueban** en este proyecto: módulos de
terceros ya probados, funcionalidad fuera del alcance (los `EXC` de RQ-04), o escenarios que
el equipo decide no automatizar.

Declararlo explícitamente evita dos problemas: que alguien **asuma** que algo está cubierto
cuando no lo está, y que se discuta después por qué "faltó" probar algo que nunca estuvo en
el plan. Es un acuerdo, no un olvido.

---

## 5. Criterios de aceptación globales

Son los umbrales que el **conjunto** de pruebas debe cumplir para dar el proyecto por
probado. Ejemplos:

- Cobertura mínima de código (p. ej. `[Propuesto]` 80 % en la capa de negocio).
- **Ninguna prueba en rojo**: todas las pruebas deben pasar antes de avanzar de fase.
- Todos los `REQ` de RQ-08 tienen al menos un `TPR` que los cubre.
- Las pruebas corren de forma automática y repetible (mismo resultado cada vez).

Si un umbral no está confirmado por el equipo, márcalo `[Propuesto]` o
`⚠️ POR CONFIRMAR (PEN-###)` en vez de inventarlo.

---

## 6. Trazabilidad: cada `TPR` con sus `REQ`

La columna **"Requisitos cubiertos (REQ-###)"** de la plantilla es obligatoria: cada `TPR`
cita los `REQ` de RQ-08 que verifica (y puede referenciar las `ENT` de PL-05 o los `EP` de
PL-06 sobre los que corre). Así la revisión de consistencia puede comprobar que **todo `REQ`
aprobado queda cubierto por algún tipo de prueba** y que ningún `TPR` prueba algo que no está
pedido.

> No reescribas el criterio: **cita el `REQ-###`**, no copies su texto.

---

## 7. Ejemplo bien llenado

**Tipos de prueba**

| ID | Tipo | Alcance | Herramienta | Requisitos cubiertos |
|----|------|---------|-------------|----------------------|
| TPR-001 | Unitaria | Reglas de cálculo y validación (IVA, descuento, formato de RFC). | xUnit | REQ-004, REQ-006 |
| TPR-002 | Integración | Endpoints de clientes contra base de datos de prueba. | xUnit + WebApplicationFactory | REQ-001, REQ-002 |
| TPR-003 | E2E | Flujo de alta de cliente desde la interfaz. | Playwright | REQ-001 |

**Qué NO entra:** reportes de exportación (EXC-002 de RQ-04) · librerías de terceros.

**Criterios globales:** cobertura mínima `[Propuesto]` 80 % en la capa de negocio · todas las
pruebas en verde antes de pasar a Deploy · cada `REQ` con al menos un `TPR`.

**Pirámide:** mayoría unitarias (TPR-001), algunas de integración (TPR-002), una sola E2E
(TPR-003) para el flujo crítico.

---

## 8. Errores comunes

- ❌ Confundir la **estrategia** con los **casos de prueba** detallados (paso a paso): eso es
  la fase 05 Testing.
- ❌ **Invertir la pirámide**: muchas E2E y pocas unitarias (lento, frágil y caro).
- ❌ No declarar **qué NO entra**, dejando dudas sobre qué quedó cubierto.
- ❌ Dejar un `TPR` **sin citar `REQ`**, rompiendo la trazabilidad.
- ❌ Inventar un umbral de cobertura en vez de marcarlo `[Propuesto]` / `⚠️ POR CONFIRMAR`.
- ❌ Meter **Gherkin** o scripts de prueba aquí (van en Testing).
- ❌ Incluir configuración de **CI/CD** (es de la fase de Deploy).

---

## 9. Checklist final

- [ ] Hay `TPR` de tipo unitaria, integración y E2E, cada uno con alcance y herramienta.
- [ ] La pirámide está declarada (muchas unitarias, algunas de integración, pocas E2E).
- [ ] Está definido explícitamente "qué NO entra en las pruebas".
- [ ] Hay criterios de aceptación globales (cobertura, pruebas en verde, etc.).
- [ ] Cada `TPR` cita los `REQ-###` de RQ-08 que cubre (sin reescribir el criterio).
- [ ] No hay casos de prueba detallados, Gherkin ni configuración de CI/CD.
- [ ] Lo no confirmado está marcado con `[Propuesto]` o `⚠️ POR CONFIRMAR (PEN-###)`.
- [ ] El Arquitecto validó la estrategia.
