# AGENT FACTORY — Metodología SDD

Esta es la "fábrica" de la metodología SDD: steering con las reglas comunes, un subagente
por fase, skills por documento, plantillas limpias e instructivos para personas. Cada fase
transforma los insumos de la anterior en documentos trazables y consistentes.

Por ahora están construidas dos fases, ambas con el mismo patrón:

- **Fase 01 — Requerimientos (`RQ`):** convierte las transcripciones de Discovery en los
  documentos de requisitos (el QUÉ). Subagente `sdd-01-requerimientos`.
- **Fase 02 — Plan / Diseño (`PL`):** convierte los requisitos **aprobados** de la Fase 01
  en un diseño técnico (el CÓMO). Subagente `sdd-02-plan-diseno`.

## Estructura

```text
.kiro/
  steering/sdd-convenciones.md          ← reglas comunes (fuente única, ambas fases)
  hooks/sdd-calidad.json                ← hooks: guardia antes de escribir y revisión al guardar
  scripts/sdd-guard.ps1, sdd-check.ps1  ← scripts que ejecutan los hooks
  agents/sdd-01-requerimientos.md       ← subagente de la Fase 01
  agents/sdd-02-plan-diseno.md          ← subagente de la Fase 02
  skills/rq-01 … rq-08, rq-revision-consistencia          ← skills Fase 01
  skills/pl-00, pl-g, pl-j, pl-m, pl-01 … pl-11, pl-revision-consistencia  ← skills Fase 02
templates/01-requerimientos/RQ-01 … RQ-08   ← plantillas Fase 01 (solo estructura)
templates/02-plan-diseno/PL-00, PL-G, PL-J, PL-M, PL-A, PL-01 … PL-11  ← plantillas Fase 02 (solo estructura)
instructivos/01-requerimientos/              ← guías para personas Fase 01 (RQ-06, RQ-08)
instructivos/02-plan-diseno/                 ← guías para personas Fase 02 (PL-J, PL-05, PL-06, PL-11)
documentacion/
  01-requerimientos/                    ← salida de los documentos de la Fase 01
  02-plan-diseno/                       ← salida de los documentos de la Fase 02
transcripciones discovery/              ← insumos de la Fase 01 (transcripciones de Discovery)
transcripciones diseno/                 ← insumo del Modo B de la Fase 02 (transcripción o acta de decisiones de la reunión de diseño)
```

Los documentos de cada proyecto se guardan en la subcarpeta de su fase:

- Fase 01 en `documentacion/01-requerimientos/` con el nombre `<COD>_RQ-NN_<nombre>.md`
  (por ejemplo, `MJG_RQ-05_historias-usuario.md`).
- Fase 02 en `documentacion/02-plan-diseno/` con el nombre `<COD>_PL-NN_<nombre>.md`
  (por ejemplo, `MJG_PL-06_contrato-endpoints.md`).

## Hooks de calidad

`.kiro/hooks/sdd-calidad.json` vigila automáticamente los documentos que escribe el agente
(los hooks de archivo de Kiro **solo** reaccionan a cambios del agente, no a ediciones
manuales). Usa scripts de PowerShell en `.kiro/scripts/`, sin costo de tokens.

| Hook | Cuándo | Qué hace |
|------|--------|----------|
| **Guardia de escritura** (`PreToolUse`, bloquea) | Antes de que el agente escriba en `documentacion/` | Bloquea si asigna `Validated`/`Approved` (§7), si usa un marcador prohibido (§5) o si crea PL-01/PL-02 sin `transcripciones diseno/txt/<COD>_reunion-diseno.txt` ni `<COD>_acta-decisiones-diseno.md` |
| **Revisión al guardar** (`PostFileSave`, avisa) | Después de guardar un `.md` en `documentacion/` | Revisa nombre de archivo (§4), encabezado e historial (§6), estado vs marcadores ⚠️ (§7), que cada `PEN` exista en una minuta RQ-03 y que las `Fuentes` citadas existan |

La revisión al guardar **no sustituye** a `rq-revision-consistencia` / `pl-revision-consistencia`:
revisa la forma de un documento; la trazabilidad y cobertura entre documentos siguen en esas skills.

Para probar la revisión a mano sobre un documento:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .kiro/scripts/sdd-check.ps1 documentacion/02-plan-diseno/PCM_PL-01_seleccion-ambientes.md
```

## Cambios respecto a la versión anterior

| Antes | Ahora |
|-------|-------|
| Historia de usuario con Gherkin, reglas, UI y API | Solo actor, Como/Quiero/Para, prioridad, dependencias y a qué objetivo o alcance contribuye |
| Criterios EARS reescribían la historia e incluían introducción y glosario | Solo citan `HU` / `CU` / `RN`; el glosario vive en RQ-04 y los estados en RQ-07 |
| Reglas de negocio con trazabilidad a Service/DTO y mensajes en notas | Solo la regla; Diseño y Pruebas citan el `RN` |
| Caso de uso citaba las historias 3 veces, criterios hacia adelante y pendientes propios | Cita una vez, solo hacia atrás; casos límite cubiertos por flujos; pendientes en la minuta |
| Pendientes en checklist, acta y cuestionario | Solo en la minuta RQ-03 (`PEN-###`) |
| 7 marcadores de información faltante | Uno solo: `⚠️ POR CONFIRMAR (PEN-###): …` + `[Inferido]`, `[Propuesto]`, `N/A` |
| IDs `US-`, `HU-`, `ID-US-`, `CA-`, `Req-` | Un solo esquema `PREFIJO-NNN` (ver steering §3) |
| Nombres de archivo y skills sin patrón | `RQ-NN_<nombre>` en plantillas y `rq-NN-<nombre>` en skills |
| La skill del acta prohibía indicar el estado | Todo documento lleva encabezado, estado e historial; el estado cambia al cerrar pendientes |
| Regla de evidencia copiada en el agente y en cada skill | Una sola vez, en el steering |
| El agente no declaraba `resources` | Carga el steering y las 9 skills por `resources` |
| Sin control de calidad final | Skill `rq-revision-consistencia` |
| Documento base con instrucciones de IA dentro de la plantilla | Plantilla limpia; las instrucciones viven en la skill |
| Cuestionario con tabla de uso interno | El mapa interno vive en la skill `rq-02` |

## Fase 01 — Requerimientos

### Cómo usar el agente

`sdd-01-requerimientos` está definido como **subagente** (en `.kiro/agents/`). Esto
significa que **no aparece en el selector de la barra de chat ni se activa con `@`**: lo
invoca por ti el agente principal con el que estás chateando.

Para usarlo, escríbele al chat un prompt que **le pida explícitamente invocar al
subagente** `sdd-01-requerimientos` (ver el prompt de abajo). La línea clave es
"Invoca al subagente sdd-01-requerimientos…"; con eso el agente principal delega en él
en lugar de activar solo una skill suelta.

> Si solo ves "Activated Skill rq-02…" y nunca "invocando agente", es señal de que **no**
> se delegó al subagente: faltó la instrucción de invocarlo. Agrega esa línea y reintenta.

**Sobre la transcripción:** el subagente solo lee texto (`tools: ["read", "write"]`), así
que trabaja con un archivo **`.txt`** guardado en `transcripciones discovery/txt/`. La
conversión de `.docx` a `.txt` es un **paso previo**: lo puedes hacer tú, o pedírselo al
agente principal en el mismo prompt (él sí puede convertir y guardar el `.txt` en esa
carpeta antes de invocar al subagente). El subagente nunca abre el `.docx`.
Se detiene si no hay transcripción y pregunta el código de proyecto si no lo das.

Tiene tres modos:

- **Modo 1 — Después de cada sesión (S1, S2…):** actualiza el checklist **único** RQ-01
  (lo crea en S1 y lo completa en S2+), crea/actualiza RQ-02 y genera la minuta RQ-03 de
  la sesión; reporta los pendientes críticos. Si quedan críticos, recomienda otra sesión.
- **Modo 2 — Documentación (sin pendientes críticos):** genera RQ-04 a RQ-08 y la
  revisión de consistencia.
- **Modo 3 — Resolución de pendientes:** cierra los `PEN` que respondas y propaga el
  cierre a todos los documentos, subiendo versiones y recalculando estados.

### Prompt universal

```text
Invoca al subagente sdd-01-requerimientos (fase 01 Requerimientos, metodología SDD)
para esta tarea.

Contexto del proyecto:
- Código de proyecto: <3–5 letras que YO asigno para nombrar los archivos, p.ej. ESR>
- Nombre del proyecto: <nombre legible>
- Sesión de Discovery: <S1 / S2 / ...>
- Transcripción a usar: #<archivo de la sesión>
- Salida esperada en: documentacion/01-requerimientos

Si la transcripción está en .docx, primero conviértela a .txt y guárdala en
"transcripciones discovery/txt/"; el subagente trabaja sobre ese .txt.

Lo que necesito en esta corrida:
<elige UNA>
- MODO 1 (después de una sesión): actualiza el checklist ÚNICO RQ-01 (créalo en S1,
  compléta el MISMO archivo en S2+; no crees un segundo checklist), RQ-02 Cuestionario
  (crea en S1, actualiza en S2+), RQ-03 Minuta con decisiones, suposiciones y
  pendientes PEN; cierra con el reporte de PEN críticos y el siguiente paso.
- MODO 2 (documentación, sin PEN críticos abiertos): genera en orden
  RQ-04 → RQ-05 → RQ-06 → RQ-07 → RQ-08 y termina con la revisión de consistencia.
- MODO 3 (resolver pendientes): te respondo los siguientes PEN: <lista PEN-### + respuesta>.
  Actualiza todos los documentos afectados, cierra los PEN en la minuta y recalcula
  versiones y estados.

Reglas:
- Respeta sdd-convenciones (orden de documentos, IDs, nombres de archivo, marcadores,
  encabezado/historial y estados). La fase 01 describe el QUÉ, nunca el CÓMO.
- No inventes datos: usa [Inferido], [Propuesto] o ⚠️ POR CONFIRMAR (PEN-###) según corresponda.
- Si falta la transcripción o el código de proyecto, pídemelo y detente.
- Al terminar: lista los archivos creados/actualizados con versión y estado, los PEN
  abiertos (marca los críticos) y el siguiente paso recomendado.
```

### Ejemplo de primera sesión (Modo 1)

```text
Invoca al subagente sdd-01-requerimientos.
Código de proyecto: ESR
Nombre: Programa ESR
Sesión: S1
Transcripción: #Contexto General – Programa ESR.txt   (en transcripciones discovery/txt/)
Salida en: documentacion/01-requerimientos/
MODO 1: genera RQ-01, RQ-02 y RQ-03 de S1 y dame el reporte de PEN críticos.
```

> El código de proyecto (ESR, MJG, …) lo asignas tú: es una etiqueta de 3–5 letras que
> se usa como prefijo de todos los archivos del proyecto. Si no lo das, el agente lo pide.

## Fase 02 — Plan / Diseño

La Fase 02 transforma los requisitos **aprobados** de la Fase 01 (RQ-04…RQ-08) en un
diseño técnico trazable. Si la Fase 01 describe el **QUÉ**, la Fase 02 describe el
**CÓMO**: ambientes, stack, arquitectura, modelo de datos, contratos, manejo de errores,
vistas y estrategia de pruebas. Genera los documentos PL-01…PL-11 en orden y cierra con
una revisión de consistencia que verifica que todo requisito aprobado quedó cubierto y que
nada del diseño sale de la nada.

### Cómo usar el agente

`sdd-02-plan-diseno` también está definido como **subagente** (en `.kiro/agents/`), igual
que el de la Fase 01: **no aparece en el selector de la barra de chat ni se activa con
`@`**; lo invoca por ti el agente principal. La línea clave en tu prompt es "Invoca al
subagente sdd-02-plan-diseno…".

> Si solo ves "Activated Skill pl-05…" y nunca "invocando agente", es señal de que **no**
> se delegó al subagente: faltó la instrucción de invocarlo. Agrega esa línea y reintenta.

**Precondición estricta — la Fase 01 debe estar aprobada.** El subagente exige que los
documentos RQ-04…RQ-08 del proyecto existan en `documentacion/01-requerimientos/`, estén
en estado `Approved` y sin `PEN` críticos abiertos. Si no se cumple, se detiene, explica
qué documento falta o en qué estado está, y **no crea ningún archivo**. Si no le das el
código de proyecto, lo pregunta (reusa el mismo `<COD>` de la Fase 01) y se detiene antes
de crear archivos.

El diseño se elabora en **dos tiempos** alrededor de la **reunión de diseño** (humana): lo
que se prepara antes (Modo A) y lo que se genera después con lo decidido (Modo B). Sus modos:

- **Modo A — Pre-reunión (Fase 01 aprobada):** genera PL-00 → PL-05 · PL-06 → PL-J · PL-M
  (borradores 🟢, antes de la reunión) → PL-G. Es el material que se **lleva a la reunión de
  diseño**, donde el arquitecto decide y justifica stack, ambiente y demás. PL-J (customer
  journey de nuestro cliente) se hace antes que PL-M y acota qué pantallas cubre el diseño.
- **Modo B — Post-reunión (con la transcripción o el acta de la reunión):** su insumo es la
  transcripción de la reunión de diseño (`.txt`) o, si no se grabó, el acta de decisiones
  (`<COD>_acta-decisiones-diseno.md`, plantilla PL-A), guardados en `transcripciones diseno/txt/`. Con lo decidido genera PL-01 · PL-02 (🔵 con `DEC-D`) → PL-08 · PL-09 (🟣
  derivadas) → PL-03 · PL-04 → PL-07 · PL-10 · PL-11 (🟢) y cierra con la revisión de
  consistencia. Si no hay transcripción ni acta, la pide y se detiene.
- **Modo — Documento específico:** genera o actualiza un PL concreto, verificando que
  existan sus insumos (PL previos, documentos RQ o la transcripción/acta de la reunión). Si
  falta un insumo, lo explica y ofrece generarlo primero.
- **Modo — Propagación de cambios:** cuando cambia un requisito de la Fase 01 (se cierra
  un `PEN`, cambia una `RN`/`CU`/`NF`), identifica los documentos PL afectados, los
  actualiza, sube su versión y recalcula su estado.

**Sobre la transcripción de la reunión de diseño:** el subagente solo lee texto
(`tools: ["read", "write"]`), así que el Modo B trabaja sobre un archivo **`.txt`** guardado
en `transcripciones diseno/txt/` (nombre sugerido `<COD>_reunion-diseno.txt`). Si la reunión
viene en `.docx`, conviértela a `.txt` antes y guárdala ahí (lo puedes hacer tú o pedírselo
al agente principal), igual que en la Fase 01 con las transcripciones de Discovery. Es el
equivalente, para la Fase 02, de `transcripciones discovery/txt/`.

**Si la reunión no se grabó:** llena el acta de decisiones con la plantilla
`templates/02-plan-diseno/PL-A_acta-decisiones-diseno.md` (fecha, participantes, quién decidió,
opción elegida y, de preferencia, el porqué) y guárdala como
`transcripciones diseno/txt/<COD>_acta-decisiones-diseno.md`. Una tabla pegada solo en el
chat no cuenta como insumo: el agente pide que se guarde como acta antes de registrar
PL-01/PL-02. Si el acta no trae el porqué, los `DEC-D` quedan con su contexto `[Inferido]`.

### Modelo de decisión y reunión de diseño

La Fase 02 clasifica cada artefacto como 🟢 **auto-generable** (el agente lo deriva de los
requerimientos), 🔵 **decisión del arquitecto** (tecnología, ambiente) o 🟣 **auto-derivado**
(lo fija una decisión 🔵 previa por regla dura). Las decisiones técnicas **no las inventa el
agente**: se toman y se justifican en una **reunión de diseño** donde el arquitecto presenta
los artefactos de la Fase 01 y explica la arquitectura ante el equipo; el agente registra lo
acordado como `DEC-D`. **PL-00** fija la clasificación (qué genera el agente, qué decide el
arquitecto y qué se auto-deriva, con las reglas duras) y **PL-G** es la guía/orden del día de
esa reunión. El **modelo de datos (PL-05)** y los **endpoints (PL-06)** son 🟢 y no dependen
del stack, así que se generan en borrador **antes** de la reunión y se llevan a ella como
insumo, para decidir la tecnología con los datos y las operaciones a la vista. El **prompt
de customer journey (PL-J)** —el recorrido de nuestro cliente, que él firma y que acota qué
pantallas cubre el diseño— y el **prompt de diseño visual (PL-M)** para Claude también se
generan antes de la reunión como apoyo, con
la paleta de **Grupo Salinas** por defecto (amarillo `#FFCD00`, gris `#5E5E61`) salvo que el
proyecto indique otra identidad; es **no bloqueante** (si el mockup no está listo, la reunión
igual procede).

### Los documentos de la Fase 02

| Código | Documento | De qué trata |
|--------|-----------|--------------|
| PL-00 | Clasificación auto/manual/auto-derivado | Marco: qué genera el agente, qué decide el arquitecto y qué se auto-deriva, con las reglas duras |
| PL-G | Guía de la reunión de diseño | Orden del día técnico de la reunión donde el arquitecto decide y justifica la arquitectura |
| PL-J | Prompt de customer journey (para Claude) | Deriva las fases del recorrido de **nuestro cliente** (el que firma) y arma el prompt para que Claude genere el customer journey; el cliente lo firma y acota el alcance del diseño |
| PL-M | Prompt de diseño visual (para Claude) | Lista las pantallas (acotadas al journey PL-J) y arma el prompt para que Claude genere el sistema de diseño y los mockups; paleta Grupo Salinas por defecto |
| PL-01 | Selección de ambientes (selector, decisión del arquitecto) | Servidores front/back, BD, dev, prod, multimedia, repos y dependencias con otras áreas (`AMB`) |
| PL-02 | Selección de stack (selector, decisión del arquitecto) | Stack front/back y versiones, justificados contra los `NF` de RQ-04; decisiones de diseño `DEC-D` |
| PL-03 | Guía de diagrama de arquitectura | Checklist de qué elementos del diagrama maestro copiar y cómo se conectan; campo para el `.drawio` adjunto |
| PL-04 | Guía de diagrama de flujos | Lista de flujos a dibujar (derivados de los `CU`) con pasos y decisiones; campo para el `.drawio` adjunto |
| PL-05 | Diccionario / modelo de datos | Entidades `ENT` y campos `CAM` (tipo, obligatorio, sensible); cita glosario de RQ-04 y `RN`/`CU` |
| PL-06 | Contrato de endpoints | Endpoints `EP`: ruta, método, parámetros, cuerpo/respuesta JSON, códigos y propósito; cita `CU`/`RN` |
| PL-07 | Manejo de errores | Catálogo de errores `ERR`, códigos, formato estándar de respuesta de error y logging |
| PL-08 | Arquitectura back (auto-derivada del backend) | Tecnología, arquitectura en 3 capas, distribución del código en módulos y responsabilidades (sin firmas de métodos) |
| PL-09 | Arquitectura front | Organización de componentes, manejo de estado y servicios a nivel alto |
| PL-10 | Vistas y rutas front | Vistas `VIS` y rutas `RUT` con acceso por rol; cita `HU`/`CU` |
| PL-11 | Estrategia de pruebas | Tipos de prueba `TPR` (unit/integración/E2E), qué no entra, criterios globales y pirámide; cita `REQ` de RQ-08 |

> **Sobre los diagramas (PL-03 y PL-04):** el agente **no dibuja**. Genera la guía con el
> checklist de qué elementos del diagrama maestro copiar y cómo se conectan; el arquitecto
> arma el `.drawio` y lo referencia como adjunto en el `.md`.

### Prompt universal (Fase 02)

El diseño va en dos tiempos: **Modo A** antes de la reunión y **Modo B** después, con la
transcripción. Un ejemplo por modo:

**Ejemplo Modo A — pre-reunión** (preparar el material de la reunión de diseño):

```text
Invoca al subagente sdd-02-plan-diseno. Código: <COD>. Documentos fase 01 en
documentacion/01-requerimientos/ (Approved). MODO A: genera PL-00, el borrador de PL-05,
PL-06, el customer journey PL-J, el prompt de diseño PL-M, y la guía de reunión PL-G. Esto
es lo que llevo a la reunión de diseño.
```

**Ejemplo Modo B — post-reunión** (con la transcripción o el acta ya guardada en
`transcripciones diseno/txt/`):

```text
Invoca al subagente sdd-02-plan-diseno. Código: <COD>. Transcripción de la reunión:
#<COD>_reunion-diseno.txt o #<COD>_acta-decisiones-diseno.md (en transcripciones diseno/txt/).
MODO B: con lo decidido en la
reunión, genera PL-01 y PL-02 (con DEC-D), deriva PL-08 y PL-09, y completa PL-03, PL-04,
PL-07, PL-10, PL-11, cerrando con la revisión de consistencia.
```

Prompt completo con todas las reglas y los demás modos:

```text
Invoca al subagente sdd-02-plan-diseno (fase 02 Plan/Diseño, metodología SDD).

Contexto del proyecto:
- Código de proyecto: <COD> (el mismo de la fase 01)
- Documentos de fase 01 en: documentacion/01-requerimientos/ (deben estar Approved)
- Salida esperada en: documentacion/02-plan-diseno/

Si la reunión de diseño está en .docx, primero conviértela a .txt y guárdala en
"transcripciones diseno/txt/" (nombre sugerido <COD>_reunion-diseno.txt); el subagente
trabaja sobre ese .txt en el Modo B.

Lo que necesito:
<elige UNO>
- MODO A (pre-reunión): genera PL-00 → PL-05 · PL-06 → PL-J · PL-M (borradores) → PL-G.
  Es el material para la reunión de diseño.
- MODO B (post-reunión, con la transcripción o el acta): a partir de la transcripción o el acta de la reunión
  en transcripciones diseno/txt/, genera PL-01 · PL-02 (con DEC-D) → PL-08 · PL-09
  (derivadas) → PL-03 · PL-04 → PL-07 · PL-10 · PL-11 y cierra con la revisión de consistencia.
- MODO documento específico: genera/actualiza PL-NN (verifica sus insumos primero).
- MODO propagar cambios: propaga los cambios de <IDs> a los documentos PL afectados,
  sube versiones y recalcula estados.

Reglas:
- Respeta sdd-convenciones (orden de documentos, IDs, nombres de archivo, marcadores,
  encabezado/historial y estados). La fase 02 describe el CÓMO.
- Cada documento cita hacia atrás los IDs de fase 01 (o de PL previos) que lo originan;
  citar = poner el ID, nunca copiar contenido.
- No inventes datos: usa [Inferido], [Propuesto] o ⚠️ POR CONFIRMAR (PEN-###) según corresponda.
- No inventes las decisiones técnicas: en el Modo B, tómalas de la transcripción o del acta
  de la reunión (un archivo en transcripciones diseno/txt/). Si no hay ninguno, pídelo y detente.
- Si la fase 01 no está aprobada (RQ-04…RQ-08 no están en Approved o hay PEN críticos),
  detente, dilo y no crees archivos.
- Al terminar: lista los archivos creados/actualizados con versión y estado y el siguiente
  paso recomendado.
```

> El subagente verifica primero que RQ-04…RQ-08 estén en `Approved` y sin `PEN` críticos.
> Si no es así, se detiene y te dice qué falta antes de crear nada. En el Modo B, si no
> encuentra la transcripción ni el acta en `transcripciones diseno/txt/`, los pide y se detiene.
