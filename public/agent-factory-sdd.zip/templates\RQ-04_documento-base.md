# Documento base del proyecto

| Campo | Valor |
|-------|-------|
| Documento | RQ-04 · Documento base del proyecto |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [COD]_RQ-02_cuestionario-discovery vX; [COD]_RQ-03_minuta-discovery-S# vX |

## 1. Título

**[Nombre del proyecto, máximo 10 palabras]**
_[Subtítulo opcional: área, cliente o fase]_

## 2. Problemas

| ID | Qué ocurre | A quién afecta | Consecuencia | Evidencia |
|----|------------|----------------|--------------|-----------|
| P-001 | | | | |

## 3. Objetivos

**Objetivo general:** [resultado global esperado]

| ID | Objetivo específico | Responde a | Indicador / meta | Plazo |
|----|---------------------|------------|------------------|-------|
| OBJ-001 | | P-001 | | |

## 4. Límites del alcance

### 4.1 Alcance funcional

**Incluido**

| ID | Capacidad o entregable | Contribuye a |
|----|------------------------|--------------|
| INC-001 | | OBJ-001 |

**Excluido (fuera de alcance en esta versión)**

| ID | Elemento excluido | Motivo |
|----|-------------------|--------|
| EXC-001 | | |

**Actores**

| ID | Rol | Qué hace con el sistema | Cuántos |
|----|-----|-------------------------|---------|
| ACT-001 | | | |

### 4.2 Límites no funcionales (declarados)

> Se declara la restricción o condición; RQ-08 la vuelve verificable.

| ID | Categoría | Límite declarado |
|----|-----------|------------------|
| NF-001 | [Rendimiento · Seguridad y privacidad · Usabilidad · Disponibilidad · Mantenibilidad · Restricción · Supuesto] | |

## 5. Glosario del dominio

| Término | Definición |
|---------|------------|
| | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
