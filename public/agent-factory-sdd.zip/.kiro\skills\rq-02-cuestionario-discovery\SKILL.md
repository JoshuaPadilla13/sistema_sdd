---
name: rq-02-cuestionario-discovery
description: Contesta o actualiza el documento RQ-02 Cuestionario de Discovery (11 partes, lenguaje sencillo) con la transcripción de una sesión, usando templates/RQ-02_cuestionario-discovery.md. Úsalo como primer paso después de cada sesión de Discovery para identificar qué información falta.
---

# Skill — RQ-02 Cuestionario de Discovery

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
- Transcripción de la sesión S# (y RQ-01 de esa sesión, si existe).
- Plantilla `templates/RQ-02_cuestionario-discovery.md`.
- Mapa interno `mapa-uso-interno.md` (en esta carpeta): indica qué documento alimenta
  cada parte. **Nunca** lo copies al cuestionario.

## Procedimiento
1. **Sesión S1:** crea `<COD>_RQ-02_cuestionario-discovery.md` desde la plantilla.
   **Sesión S2 o posterior:** actualiza el mismo archivo (no crees otro) y sube la versión.
2. Respeta las 11 partes y su orden. Repite la Parte 5 por cada tarea mencionada.
3. Contesta con las palabras del cliente, en lenguaje sencillo. Si lo resumes, no
   cambies el sentido. Cita el minuto cuando ayude: `(RQ-03 S1 12:40)`.
4. Lo que no se respondió, quedó ambiguo o se contradice:
   `⚠️ POR CONFIRMAR (PEN-###): <qué falta>`. Numera los `PEN` continuando la
   numeración del proyecto; la minuta RQ-03 de la sesión los registrará.
5. Marca la prioridad de cada `PEN` para la minuta:
   - **Crítico:** bloquea un problema, objetivo, alcance, actor, flujo principal o regla.
   - **Normal:** todo lo demás.
6. En S2+, cuando una respuesta cierre un `PEN`, reemplaza el marcador por el dato y
   avisa a la minuta que ese `PEN` se cierra (ver `sdd-convenciones` §7).

## Lo que NO va aquí
IDs de requerimientos (`HU`, `RN`, `REQ`…), interpretación técnica, la tabla de uso
interno ni recomendaciones de envío.

## Checklist final
11 partes en orden · lenguaje del cliente · cada hueco con su `PEN-###` y prioridad ·
sin datos inventados · un solo archivo por proyecto (actualizado por sesión) ·
encabezado e historial completos.
