# Mapa de uso interno del cuestionario RQ-02 (no enviar al cliente)

| Parte | Alimenta |
|-------|----------|
| 1 | RQ-03 Minuta (datos de la sesión y participantes) |
| 2, 3 | RQ-04 Documento base (problemas, objetivos, incluido/excluido, restricciones y supuestos `NF`) |
| 4 | RQ-04 actores `ACT`; RQ-06 reglas de autorización |
| 5 (A, G) | RQ-05 Historias de usuario y su prioridad |
| 5 (B, F) | RQ-07 Casos de uso (flujo principal, pre y postcondiciones) |
| 5 (C) | RQ-07 flujos de excepción → RQ-08 criterios SI…ENTONCES |
| 5 (D) | RQ-06 Reglas de negocio |
| 5 (E) | RQ-08 mensajes exactos |
| 6 | RQ-06 reglas de validación de datos; el diccionario de datos es de la fase 02 |
| 7 | RQ-06 Reglas de negocio |
| 8 | Fase 02 (Especificación de vistas y rutas); en fase 01 solo como contexto |
| 9 | RQ-04 límites no funcionales `NF` |
| 10 | RQ-03 Minuta (responsables y fechas) |
| 11 | Pendientes `PEN` en RQ-03 y reglas ocultas en RQ-06 |

### Recomendaciones de envío

- Como el cliente no es técnico, mándenlo **por partes**: primero las Partes 1 a 3 y la 5,
  luego la 6 con un recordatorio corto.
- La **Parte 9** conviene reenviarla directamente al área de sistemas del cliente, si existe.
- Cuando lleguen respuestas con "No sé", pásenlas a Kiro tal cual. Saldrán como
  `⚠️ POR CONFIRMAR (PEN-###)`.
