---
name: rq-revision-consistencia
description: Revisa que los documentos RQ-01 a RQ-08 de un proyecto sean consistentes entre sí (IDs, referencias, información fuera de lugar, marcadores, estados y nombres de archivo) y reporta hallazgos en el chat. Úsalo al terminar RQ-08, después de resolver pendientes, o cuando se pida validar la fase de Requerimientos.
---

# Skill — Revisión de consistencia de la fase 01

Aplica las convenciones de `sdd-convenciones`. Esta skill **no crea documentos** ni
corrige nada por su cuenta: reporta en el chat y propone correcciones. Solo las aplica
si el usuario lo pide.

## Verificaciones

**1. Cobertura (de atrás hacia adelante)**
- Todo `P` tiene al menos un `OBJ`; todo `OBJ` tiene al menos un `INC`.
- Todo `INC` tiene al menos una `HU`.
- Toda `HU` está en al menos un `CU` y en al menos un `REQ`.
- Todo `RN` es citado por algún `CU` o `REQ`.
- Todo `FE` tiene un criterio SI…ENTONCES en RQ-08.
- Todo `NF` verificable tiene un `REQ`.

**2. Referencias**
- Todo ID citado existe en su documento dueño.
- Nadie cita hacia adelante (por ejemplo, RQ-07 citando un `REQ`).
- No hay IDs duplicados, reutilizados ni con formato distinto a `PREFIJO-NNN`.

**3. Información fuera de lugar**
Aplica la matriz de `sdd-convenciones` §2. Señala, por ejemplo: Gherkin en cualquier
documento · criterios o reglas dentro de RQ-05 · mensajes fuera de RQ-08 ·
endpoints, tablas, tipos o stack en cualquier documento · pendientes fuera de RQ-03 ·
contenido copiado de otro documento en vez de citado.

**4. Marcadores y pendientes**
- Solo los marcadores permitidos.
- Cada `⚠️ POR CONFIRMAR (PEN-###)` tiene su fila en una minuta, y cada fila `PEN` abierta
  tiene al menos un marcador.

**5. Contradicciones**
El mismo dato con valores distintos entre documentos (montos, límites, roles, estados,
nombres).

**6. Estados, versiones y nombres**
El estado corresponde a la regla de §7 · el historial refleja los cambios · los nombres de
archivo siguen §4.

## Formato del reporte

| # | Severidad | Documento | Hallazgo | Corrección propuesta |
|---|-----------|-----------|----------|----------------------|

Severidad: **Bloqueante** (rompe trazabilidad o contradice) · **Mayor** (información fuera de
lugar, cobertura incompleta) · **Menor** (formato).

Cierra con un veredicto: **Lista para validación** (sin bloqueantes) o **No lista**.
