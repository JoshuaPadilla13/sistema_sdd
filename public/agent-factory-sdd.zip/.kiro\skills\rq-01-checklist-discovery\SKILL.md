---
name: rq-01-checklist-discovery
description: Llena o completa el documento RQ-01 Checklist de Discovery de una sesión (S1, S2…) usando templates/RQ-01_checklist-discovery.md. Úsalo cuando haya una transcripción de una sesión de Discovery y se necesite verificar qué información ya cubrió el cliente y qué quedó como hueco.
---

# Skill — RQ-01 Checklist de Discovery

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
- Transcripción de la sesión S#.
- El checklist que el facilitador llenó en tiempo real, si existe.
- Plantilla `templates/RQ-01_checklist-discovery.md`.

## Procedimiento
1. Si el facilitador ya llenó el checklist, **complétalo**: no cambies lo que él marcó
   sin evidencia en la transcripción. Si no existe, llénalo desde cero.
2. Marca cada ítem con ✅ / 🟡 / ❌ / N/A y anota el **minuto** de la transcripción
   donde salió (para ✅ y 🟡).
3. La pregunta de rescate solo aplica a 🟡 y ❌; no la reescribas.
4. Llena el resumen de cobertura.
5. Lista para la minuta RQ-03 los ítems 🟡 y ❌: la skill `rq-03-minuta-discovery` los
   registra como `PEN-###`. **No** crees tabla de pendientes en este documento.

## Lo que NO va aquí
Pendientes, decisiones, respuestas del cliente a detalle (van en RQ-02) ni análisis de
requerimientos.

## Checklist final
Todos los ítems marcados · ✅ y 🟡 con minuto · resumen lleno · sin tabla de pendientes ·
encabezado e historial completos · nombre `<COD>_RQ-01_checklist-discovery-S#.md`.
