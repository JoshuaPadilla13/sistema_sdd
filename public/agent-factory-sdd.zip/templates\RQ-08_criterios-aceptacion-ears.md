# Criterios de aceptación EARS

| Campo | Valor |
|-------|-------|
| Documento | RQ-08 · Criterios de aceptación EARS |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX; [COD]_RQ-05 vX; [COD]_RQ-06 vX; [COD]_RQ-07 vX |

## Catálogo

| ID | Título | Tipo | Origen |
|----|--------|------|--------|
| REQ-001 | | Funcional | HU-### · CU-### |
| REQ-0NN | | No funcional | NF-### |

---

## REQ-001 — [Título corto, 3 a 6 palabras]

**Origen:** HU-### · CU-### · RN-###, RN-###

| ID | Criterio |
|----|----------|
| REQ-001.CA-01 | CUANDO [evento], el sistema DEBERÁ [respuesta observable]. |
| REQ-001.CA-02 | SI [condición no deseada], ENTONCES el sistema DEBERÁ mostrar "[mensaje exacto]". |
| REQ-001.CA-03 | MIENTRAS [estado], el sistema DEBERÁ [respuesta]. |
| REQ-001.CA-04 | DONDE [característica habilitada], el sistema DEBERÁ [respuesta]. |
| REQ-001.CA-05 | El sistema DEBERÁ [requisito siempre aplicable]. |

<!-- Repetir el bloque "## REQ-NNN" por cada requerimiento. Los no funcionales citan su NF-### como origen. -->

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
