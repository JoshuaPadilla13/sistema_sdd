# Cuestionario de Discovery

| Campo | Valor |
|-------|-------|
| Documento | RQ-02 · Cuestionario de Discovery |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [Transcripción S1, S2…] |

> Cuestionario en lenguaje sencillo para que el cliente aporte la información de la
> fase de Requerimientos. El agente lo contesta con la transcripción de cada sesión.
> Lo que falte se marca `⚠️ POR CONFIRMAR (PEN-###): <qué falta>` y el `PEN` se
> registra en la minuta RQ-03 de esa sesión.

---

## 📩 Versión para enviar al cliente

**Asunto:** Cuéntanos cómo trabajas hoy, para construir lo que realmente necesitas (≈ 40 min)

Hola, [Nombre]:

Queremos que el sistema salga bien desde el principio y evitar reuniones largas. Para eso,
necesitamos que nos cuentes cómo trabajas, sin necesidad de saber de sistemas ni de
tecnología. Tú conoces tu trabajo mejor que nadie, y eso es justo lo que nos hace falta.

**Antes de empezar:**

- No hay respuestas correctas o incorrectas. Escribe como si le explicaras a un compañero
  nuevo cómo se hacen las cosas.
- Los ejemplos son solo ejemplos. Cámbialos por tu caso real.
- Si no sabes algo, escribe "No sé". Es mejor que adivinar. Así sabemos qué revisar contigo
  después.
- Puedes adjuntar fotos, Excel, formatos, correos o dibujos a mano.
- Puedes contestar por partes y mandarlo en varios envíos.
- No te preocupes por la redacción. Con palabras sueltas o viñetas es suficiente.

---

### PARTE 1 · Sobre ti y este proyecto

1. Nombre del proyecto: ____
2. ¿Quién está respondiendo? Nombre y puesto. Si participan varias personas, anota a cada
   una (por ejemplo, "Ana, de contabilidad"). ____
3. ¿Quién toma la decisión final si hay opiniones distintas sobre cómo debe funcionar algo? ____
4. En una frase, ¿qué esperas lograr con este sistema? ____

---

### PARTE 2 · Cómo trabajas hoy

5. Cuéntanos un día normal de trabajo en lo que este sistema va a cubrir. ¿Qué haces desde
   que empieza el proceso hasta que termina? ¿Qué usas hoy (Excel, papel, WhatsApp, correo,
   otro programa)? ____
6. ¿Qué es lo que más te estorba, te desespera o te quita tiempo? Ejemplo: "Registramos
   clientes en Excel y a veces el mismo cliente aparece dos veces". ____
7. Piensa en la última vez que algo salió mal (un error, un retraso, información perdida).
   ¿Qué pasó y qué consecuencia tuvo? ____
8. Si esto no se arregla en los próximos 6 meses, ¿qué pasa? (Pérdida de dinero, de tiempo,
   quejas de clientes, multas…) ____
9. ¿Cómo sabrás que el sistema funcionó bien? Ejemplo: "Registrar a un cliente toma 2
   minutos y nunca hay duplicados". ____

---

### PARTE 3 · Qué quieres que haga el sistema

10. Haz una lista de todo lo que quieres que el sistema haga, aunque sean palabras sueltas.
    Ejemplos: "registrar clientes", "ver cuánto vendimos al mes", "mandar recordatorios de
    pago". ____
11. De esa lista, si solo pudiéramos entregarte tres cosas primero, ¿cuáles serían y en qué
    orden? ____
12. ¿Qué NO quieres que haga, o qué dejarías para después? Ejemplo: "Por ahora no hace falta
    que facture". ____
13. ¿Hay algo que debamos respetar o tomar en cuenta?
    - ¿Fecha límite o evento importante? ____
    - ¿Programas o equipos que su empresa obliga a usar? (Si no sabes, escribe "preguntar a
      sistemas") ____
    - ¿Reglas o leyes que se deben cumplir? (Protección de datos personales, auditorías,
      políticas internas) ____
    - ¿Presupuesto de referencia? (Opcional) ____
14. ¿Qué damos por hecho? Ejemplo: "Todos tienen computadora en su escritorio" o "Siempre
    hay internet en la oficina". ____

---

### PARTE 4 · Quiénes van a usarlo

15. ¿Qué tipos de personas van a usar el sistema? Anota cada tipo de usuario (por puesto o
    función):

| ¿Cómo les dicen? (puesto o función) | ¿Qué hacen con el sistema? | ¿Qué NO deberían poder hacer? | ¿Cuántas personas son? |
|-------------------------------------|----------------------------|-------------------------------|------------------------|
| Ej.: Recepcionista | Registrar clientes nuevos | Borrar registros | 5 |
| | | | |

16. ¿Alguien de fuera de tu empresa lo usará (clientes, proveedores)? ¿Qué podrán ver o
    hacer? ____
17. ¿Quién se encargará de dar acceso a las personas (agregar a alguien nuevo, quitar a
    quien se va, recuperar contraseñas)? ____

---

### PARTE 5 · Cada tarea, a detalle

> 🔁 Repite esta parte por **cada cosa de tu lista (pregunta 10)**, empezando por las más
> importantes. Copia y pega las veces que necesites.

**TAREA: ____** (ponle un nombre corto, por ejemplo "Registrar un cliente")

**A. ¿Para qué sirve?**
- ¿Quién la hace? ____
- ¿Qué necesita hacer? ____
- ¿Para qué? ¿Qué gana con eso? Ejemplo: "Para no tener que capturar al cliente otra vez" ____

**B. Cuéntala paso a paso.** Imagina que ya tienes el sistema ideal y me explicas cómo lo
usarías. Ejemplo: "Entro, busco al cliente por su RFC, si no está lo registro, lleno sus
datos y guardo". ____

**C. ¿Y si pasa esto?** Contesta lo que aplique:
- Si lo que buscan ya existe (por ejemplo, el cliente ya estaba registrado), ¿qué debería
  pasar? (Avisar, abrirlo para corregirlo, no permitir continuar…) ____
- Si falta un dato importante, ¿qué debería pasar? ____
- Si alguien se equivoca al escribir (un correo mal escrito, un monto con signo negativo),
  ¿qué esperas que le diga el sistema? ____
- Si no hay resultados (buscas algo y no hay nada, o una lista está vacía), ¿qué quieres ver
  en pantalla? ____
- Si se va el internet o algún otro programa falla, ¿qué debería hacer la persona? ____
- Si alguien sin autorización intenta hacerlo, ¿qué debería pasar? ____

**D. Reglas.** ¿Qué es lo que "nunca", "siempre" o "solo si…" se cumple aquí? Ejemplos: "No
se puede registrar dos veces el mismo RFC", "El descuento máximo es 20%", "Solo el gerente
puede borrar". ____

**E. ¿Hay mensajes que quieras que el sistema muestre con tus palabras?** Ejemplo: "Este
cliente ya está registrado". ____

**F. Antes y después.**
- ¿Qué debe estar listo antes de hacer esta tarea? Ejemplo: "Que la persona haya entrado con
  su usuario y contraseña" ____
- ¿Qué debe quedar guardado después? Ejemplo: "Un historial de quién lo hizo y cuándo" ____

**G. ¿Qué tan urgente es?** Marca una:
☐ Sin esto no podemos arrancar  ☐ Es importante  ☐ Puede esperar

---

### PARTE 6 · La información que se maneja

18. Haz una lista de cada dato que se escribe o se consulta (nombre, RFC, correo, teléfono,
    monto, fecha…). Si no sabes alguna columna, déjala vacía o pon "?". Aquí tienes un
    ejemplo:

| Dato | ¿Siempre hay que llenarlo? | ¿Puede haber dos iguales? (Ej.: dos clientes con el mismo RFC) | ¿Qué clase de dato es? (letras, número, fecha, dinero, sí/no) | ¿Qué tan largo o qué límites tiene? (Ej.: máx. 100 letras, de 1 a 99) | ¿Es privado o confidencial? (datos personales, dinero, contraseñas) | Un ejemplo real |
|------|----------------------------|---------------------------------------------------------------|---------------------------------------------------------------|------------------------------------------------------------------------|---------------------------------------------------------------------|-----------------|
| RFC | Sí | No | Letras y números | 13 caracteres | Sí | XAXX010101000 |
| | | | | | | |

19. ¿Hay listas de opciones fijas? Ejemplos: estado (Activo / Inactivo), tipo de cliente
    (Persona / Empresa), puestos. Anota cada lista con sus opciones. ____
20. ¿Cómo se relaciona la información entre sí? Ejemplos: "Un cliente puede tener muchos
    pedidos", "Un pedido puede llevar varios productos". Escríbelo con tus palabras o haz un
    dibujo. ____
21. ¿Ya tienes información en Excel o en otro programa que haya que pasar al sistema nuevo?
    ¿Aproximadamente cuántos registros son? ¿Está ordenada y limpia, o tiene errores y
    repetidos? ____

---

### PARTE 7 · Reglas del negocio

22. **Cálculos:** ¿hay operaciones, porcentajes, topes o redondeos que se deban aplicar?
    Ejemplo: "IVA del 16% sobre el subtotal". ____
23. **Autorizaciones:** ¿hay algo que necesite el visto bueno de alguien antes de continuar?
    Ejemplo: "No se factura sin que el gerente apruebe". ____
24. **Límites:** ¿hay máximos o mínimos de algo? Ejemplo: "Máximo 50 productos por pedido". ____
25. **Casos raros:** ¿hay alguna situación que "solo pasa a veces" pero que hay que
    contemplar? ____
26. ¿Hay reglas que solo están en la cabeza de alguien y no se han escrito en ningún lado?
    Cuéntalas, aunque te parezcan obvias. ____

---

### PARTE 8 · Pantallas, reportes y avisos

27. ¿Tienes dibujos, fotos, formatos o ejemplos de lo que imaginas? Adjúntalos. Aunque estén
    hechos a mano, nos ayudan mucho. ____
28. **Reportes o consultas:** ¿qué información necesitas ver, cómo te gustaría filtrarla y
    cada cuánto? Ejemplo: "Ventas por mes y por vendedor, cada lunes". ____
29. ¿Necesitas sacar la información en Excel, PDF o impresa? ¿Qué debe contener? ____
30. ¿Quieres que el sistema envíe correos, mensajes o avisos? ¿A quién, cuándo y qué debe
    decir? ____

---

### PARTE 9 · Dónde y cómo se va a usar

> 💡 Si alguna de estas preguntas es muy técnica, pásala a la persona que se encarga de las
> computadoras o de sistemas en tu empresa. Si no sabes quién es, escribe "No sé".

31. ¿Desde dónde van a usarlo?
    ☐ Solo dentro de la oficina  ☐ También desde fuera (casa, calle, otra sucursal)  ☐ No sé.
    ¿Desde computadora, celular o ambos? ____
32. ¿Debe conectarse con otros programas o servicios que ya usan? Ejemplos: el sistema de
    contabilidad, el correo, el SAT, el banco, carpetas compartidas. ¿Quién nos puede dar
    acceso o información sobre ellos? ____
33. ¿Cuánta gente lo usará al mismo tiempo, y cuánta información se espera que se maneje?
    Ejemplo: "20 personas a la vez, unos 500 pedidos al mes". ____
34. **Seguridad:** ¿hay algo que quieras que se cumpla? Ejemplos: que pida usuario y
    contraseña, que mande un código al celular para entrar, que quede un historial de quién
    cambió qué, o que se hagan copias de seguridad. ____
35. Si el sistema dejara de funcionar un rato, ¿cuánto tiempo puedes esperar sin que te
    afecte? ¿A quién habría que avisarle primero? ____

---

### PARTE 10 · Cómo vamos a trabajar juntos

36. ¿Quién de tu lado puede resolver dudas rápidas mientras construimos el sistema? Nombre,
    correo y horario en que se le puede encontrar. ____
37. ¿Quién va a revisar y aprobar lo que les entreguemos? ____
38. ¿Hay fechas importantes que debamos conocer? Ejemplo: "La capacitación del equipo es el
    15 de noviembre". ____

---

### PARTE 11 · Para cerrar

39. ¿Qué crees que debemos saber y no te preguntamos? ____
40. Si pudieras asegurar una sola cosa de este sistema, ¿cuál sería? ____
41. ¿Hay alguien más con quien debamos hablar o a quien debamos preguntarle algo que tú no
    sepas? ____

¡Muchas gracias! Con tus respuestas armaremos el plan del sistema y solo te buscaremos para
confirmar lo que haya quedado pendiente.

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
