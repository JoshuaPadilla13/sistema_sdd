---
inclusion: fileMatch
fileMatchPattern: 'documentacion/**'
---

# Convenciones SDD del equipo (fuente única)

Este archivo es la **única fuente** de las reglas comunes de la documentación SDD.
Las skills, plantillas e instructivos **no repiten** estas reglas: las aplican.
Si algún archivo dice algo distinto, **manda este**.

---

## 1. Las 7 fases y su código

| # | Fase | Código | Responsable |
|---|------|--------|-------------|
| 01 | Requerimientos | RQ | Product Manager |
| 02 | Plan / Diseño | PL | Arquitecto |
| 03 | Tareas | TA | Frontend y Backend |
| 04 | Desarrollo | DE | Frontend y Backend |
| 05 | Testing | TE | QA |
| 06 | Deploy | DP | Backend |
| 07 | Entrega | EN | Arquitecto / Product Manager |

**Requerimientos describe el QUÉ, nunca el CÓMO.** En la fase 01 no se escriben
endpoints, tablas, tipos de dato técnicos, librerías, stack, colores ni diseño de
pantallas: eso es de la fase 02.

---

## 2. Documentos de la fase 01 — orden y responsable único de cada dato

El número del documento **es** su orden de elaboración.

| Código | Documento | Contiene SOLO | NO contiene (y dónde va) |
|--------|-----------|---------------|---------------------------|
| RQ-01 | Checklist de Discovery | Cobertura de la sesión por bloques A–D | Pendientes (van en RQ-03) |
| RQ-02 | Cuestionario de Discovery | Respuestas del cliente en su lenguaje | Interpretación SDD, IDs de requerimientos |
| RQ-03 | Minuta de sesión de Discovery | Datos de la sesión, participantes, temas, decisiones `DEC`, suposiciones `SUP` y **todos los pendientes `PEN` del proyecto** | Requerimientos, reglas, criterios |
| RQ-04 | Documento base del proyecto | Título, problemas `P`, objetivos `OBJ`, alcance incluido `INC` / excluido `EXC`, actores `ACT`, límites no funcionales `NF` (declarados), glosario | Criterios verificables (RQ-08), reglas (RQ-06) |
| RQ-05 | Historias de usuario | `HU`: actor, Como/Quiero/Para, prioridad, dependencias, a qué `OBJ`/`INC` contribuye | Criterios de aceptación, reglas, validaciones, textos de pantalla, estados de UI, API, datos |
| RQ-06 | Reglas de negocio | `RN`: regla del dominio, tipo, origen | Mensajes al usuario (RQ-08), UI, no funcionales (RQ-04), Service/DTO/pruebas (fases 02 y 05) |
| RQ-07 | Casos de uso | `CU`: actores, disparador, pre/postcondiciones, flujo principal, alternos `FA`, excepciones `FE`, estados y transiciones | Criterios EARS (RQ-08), textos exactos de mensajes (RQ-08) |
| RQ-08 | Criterios de aceptación EARS | `REQ` con criterios `CA` en EARS, mensajes exactos, criterios verificables de los `NF` | Gherkin (es de Testing, fase 05), implementación |

### Regla de referencias (evita contradicciones)

1. Un documento **solo cita IDs de documentos anteriores** en el orden (RQ-08 cita
   RQ-04…RQ-07; RQ-05 cita RQ-04; nadie cita hacia adelante).
2. Citar = poner el ID. **Nunca copiar ni reescribir** el contenido de otro documento.
3. La trazabilidad hacia adelante no se escribe a mano: la calcula la revisión de
   consistencia (skill `rq-revision-consistencia`).
4. Gherkin (Dado/Cuando/Entonces) **no se usa en la fase 01**.

### Responsables de conceptos que se prestan a duplicarse

| Concepto | Dueño | Los demás… |
|----------|-------|------------|
| Pendientes | RQ-03 (minuta) | ponen el marcador con su `PEN-###` |
| Requisitos no funcionales | RQ-04 los **declara** (`NF-###`) | RQ-08 los vuelve **verificables** citando el `NF` |
| Actores / roles | RQ-04 (`ACT-###`) | citan el `ACT` |
| Términos del dominio | RQ-04 (glosario) | usan el término tal cual |
| Estados de una entidad | RQ-07 (estados y transiciones) | RQ-08 los escribe en MAYÚSCULAS entre comillas |
| Mensajes exactos al usuario | RQ-08 | nadie más los redacta |

---

## 3. Identificadores

- Formato: `PREFIJO-NNN` (3 dígitos). Subelementos: `PADRE.PREFIJO-NN` (2 dígitos).
- Únicos por proyecto. **Nunca se reutilizan**: si algo se elimina, su ID queda retirado.

| Prefijo | Qué identifica | Dueño | Ejemplo |
|---------|----------------|-------|---------|
| `S#` | Sesión de Discovery | RQ-03 | S1, S2 |
| `PEN` | Pendiente | RQ-03 | PEN-004 |
| `DEC` | Decisión | RQ-03 | DEC-002 |
| `SUP` | Suposición inferida en sesión | RQ-03 | SUP-001 |
| `P` | Problema | RQ-04 | P-001 |
| `OBJ` | Objetivo específico | RQ-04 | OBJ-002 |
| `INC` | Alcance incluido | RQ-04 | INC-003 |
| `EXC` | Alcance excluido | RQ-04 | EXC-001 |
| `ACT` | Actor / rol | RQ-04 | ACT-002 |
| `NF` | Límite no funcional declarado | RQ-04 | NF-001 |
| `HU` | Historia de usuario | RQ-05 | HU-007 |
| `RN` | Regla de negocio | RQ-06 | RN-012 |
| `CU` | Caso de uso | RQ-07 | CU-003 |
| `FA` / `FE` | Flujo alterno / de excepción | RQ-07 | CU-003.FE-02 |
| `REQ` | Requerimiento EARS | RQ-08 | REQ-005 |
| `CA` | Criterio de aceptación | RQ-08 | REQ-005.CA-03 |

**Cita de fuentes:** `RQ-02 P22` (pregunta 22 del cuestionario) · `RQ-03 S1 12:40`
(sesión 1, minuto 12:40).

---

## 4. Nombres de archivos

| Qué | Patrón | Ejemplo |
|-----|--------|---------|
| Código de proyecto | 3–5 letras mayúsculas, acordado al inicio | `MJG` |
| Documento de proyecto | `<COD>_RQ-NN_<nombre>.md` | `MJG_RQ-05_historias-usuario.md` |
| Documento por sesión (RQ-01, RQ-03) | `<COD>_RQ-NN_<nombre>-S#.md` | `MJG_RQ-03_minuta-discovery-S1.md` |
| Plantilla | `templates/RQ-NN_<nombre>.md` | `templates/RQ-05_historias-usuario.md` |
| Skill | `.kiro/skills/rq-NN-<nombre>/SKILL.md` | `rq-05-historias-usuario` |
| Instructivo | `instructivos/RQ-NN_<nombre>_instructivo.md` | `RQ-06_reglas-negocio_instructivo.md` |
| Agente de fase | `.kiro/agents/sdd-NN-<fase>.md` | `sdd-01-requerimientos.md` |
| Ubicación de salida | `documentacion/` | |

Nombres oficiales (`<nombre>`): `checklist-discovery`, `cuestionario-discovery`,
`minuta-discovery`, `documento-base`, `historias-usuario`, `reglas-negocio`,
`casos-uso`, `criterios-aceptacion-ears`. Minúsculas, sin acentos, palabras con guion.

Si el usuario no ha dado el código de proyecto, **pregúntalo antes de crear archivos**.

---

## 5. Evidencia y marcadores (los únicos permitidos)

| Marcador | Cuándo |
|----------|--------|
| *(sin marca)* | Dato **confirmado**: dicho en la transcripción, el cuestionario o por el usuario en el chat |
| `[Inferido]` | Deducido del contexto; nadie lo dijo explícitamente |
| `[Propuesto]` | Sugerencia del agente para completar; requiere aceptación |
| `⚠️ POR CONFIRMAR (PEN-###): <qué falta>` | Falta información o hay contradicción entre fuentes |
| `N/A` | La sección o el campo no aplica a este proyecto |

- Todo `⚠️ POR CONFIRMAR` **debe** tener su `PEN-###` registrado en una minuta RQ-03.
- Prohibidos como marcador: `[DUDA]`, `[Por definir]`, `POR DEFINIR`, `Pendiente`,
  `Supuesto`, `No disponible`, `[Métrica por definir]` o cualquier otra variante.
  ("Supuesto" sí es válido como **categoría** de un `NF` en RQ-04.)
- Nunca inventes un dato ni conviertas un `[Inferido]` o `[Propuesto]` en decisión.
- En el checklist (RQ-01) la cobertura se marca con: ✅ Cubierto · 🟡 Parcial · ❌ Falta · N/A.

---

## 6. Encabezado e historial (obligatorios en todo documento)

Al inicio:

```markdown
| Campo | Valor |
|-------|-------|
| Documento | RQ-NN · <Nombre oficial> |
| Proyecto | <Nombre del proyecto> · <COD> |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | <archivos usados, con su versión> |
```

Al final, sección `## Historial de cambios` con la tabla
`| Versión | Fecha | Cambio | Autor |`.

---

## 7. Estados del documento y cierre de pendientes

| Estado | Condición | Quién lo asigna |
|--------|-----------|-----------------|
| Draft | Tiene al menos un `⚠️ POR CONFIRMAR` | Agente |
| Pending Validation | Cero marcadores `⚠️`; listo para revisión humana | Agente |
| Validated | Revisado por PM / Analista | Persona |
| Approved | Aprobado por el responsable de la fase | Persona |

El agente **nunca** asigna `Validated` ni `Approved`.

**Cuando el usuario resuelve un pendiente con el agente:**
1. El agente reemplaza el marcador por el dato en **todos** los documentos donde aparece
   ese `PEN-###`.
2. Elimina la fila del `PEN-###` de la tabla de pendientes de la minuta.
3. Registra en el historial de cada documento tocado: `Se cierra PEN-### — <resumen>`.
4. Sube la versión (0.1 → 0.2) y recalcula el estado según la tabla de arriba.

Si un documento cambia después de `Validated` o `Approved`, regresa a `Pending Validation`.

---

## 8. Idioma

Todo en español. Palabras clave EARS en español: CUANDO, MIENTRAS, SI…ENTONCES,
DONDE, DEBERÁ.
