# Minuta de sesión de Discovery — S#

| Campo | Valor |
|-------|-------|
| Documento | RQ-03 · Minuta de sesión de Discovery |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [Transcripción de la sesión S#] |

## Datos de la sesión

| Campo | Detalle |
|-------|---------|
| Sesión | S# |
| Fecha y hora | |
| Duración | |
| Modalidad | |
| Grabación / transcripción | |

## Objetivo de la sesión

[1–2 frases con el propósito real de la sesión.]

## Participantes y roles

| Nombre | Rol | Responsabilidad en el proyecto |
|--------|-----|--------------------------------|
| | | |

## Temas tratados

| # | Tema | Minuto |
|---|------|--------|
| 1 | | |

## Decisiones

| ID | Decisión | Tomada por | Minuto |
|----|----------|------------|--------|
| DEC-001 | | | |

## Suposiciones inferidas

| ID | Suposición | Certeza (Alta / Media / Baja) | Riesgo si es incorrecta |
|----|------------|-------------------------------|-------------------------|
| SUP-001 | | | |

## Pendientes

> Única lista de pendientes del proyecto. Cada `PEN` corresponde a un marcador
> `⚠️ POR CONFIRMAR (PEN-###)` en algún documento. Al resolverse, la fila se elimina
> y el cierre queda en el historial. Si no hay pendientes abiertos, escribir:
> "Sin pendientes abiertos."

| ID | Pendiente | Prioridad (Crítico / Normal) | Origen | Responsable | Fecha límite |
|----|-----------|------------------------------|--------|-------------|--------------|
| PEN-001 | | | | | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
