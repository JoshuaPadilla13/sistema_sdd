# Historias de usuario

| Campo | Valor |
|-------|-------|
| Documento | RQ-05 · Historias de usuario |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [COD]_RQ-04_documento-base vX |

## Catálogo

| ID | Título | Actor | Prioridad | Contribuye a |
|----|--------|-------|-----------|--------------|
| HU-001 | | ACT-001 | Alta / Media / Baja | OBJ-001 · INC-001 |

---

## HU-001 — [Título breve orientado al valor]

| Campo | Valor |
|-------|-------|
| Actor | ACT-001 · [rol] |
| Prioridad | Alta / Media / Baja |
| Contribuye a | OBJ-001 · INC-001 |
| Dependencias | HU-### / Ninguna |

**Como** [rol],
**quiero** [acción que el sistema debe permitir],
**para** [beneficio de negocio].

**Notas:** [contexto funcional breve, o N/A]

<!-- Repetir el bloque "## HU-NNN" por cada historia. -->

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
