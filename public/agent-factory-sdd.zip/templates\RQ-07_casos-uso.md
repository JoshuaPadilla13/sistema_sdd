# Casos de uso

| Campo | Valor |
|-------|-------|
| Documento | RQ-07 · Casos de uso |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [COD]_RQ-04 vX; [COD]_RQ-05 vX; [COD]_RQ-06 vX |

## Catálogo

| ID | Nombre (objetivo del actor) | Actor principal | Historias |
|----|-----------------------------|-----------------|-----------|
| CU-001 | | ACT-001 | HU-001 |

---

## CU-001 — [Objetivo del actor, orientado a resultado]

### Identificación

| Campo | Valor |
|-------|-------|
| Actor principal | ACT-### |
| Actores secundarios | ACT-### / sistemas externos / Ninguno |
| Historias | HU-### |
| Objetivo | El actor necesita conseguir [X] mediante [Y] para obtener [Z]. |
| Disparador | [Evento que inicia el caso de uso] |

### Precondiciones

- [Condición observable que debe cumplirse antes de iniciar]

### Flujo principal

| Paso | Actor / Sistema | Acción |
|------|-----------------|--------|
| 1 | [Actor] | |
| 2 | Sistema | |

### Flujos alternos

| ID | Desde el paso | Condición | Comportamiento | Regresa a / Termina |
|----|---------------|-----------|----------------|---------------------|
| CU-001.FA-01 | | | | |

### Flujos de excepción

| ID | Desde el paso | Condición que la provoca | Respuesta del sistema | Estado final | ¿El actor puede corregir? | Regresa a / Termina |
|----|---------------|--------------------------|-----------------------|--------------|---------------------------|---------------------|
| CU-001.FE-01 | | | | | | |

### Estados y transiciones

> N/A si el comportamiento no depende de estados.

| Estado inicial | Evento | Condición | Estado nuevo |
|----------------|--------|-----------|--------------|
| | | | |

**Transiciones no permitidas:** [ej. de "CERRADO" no se puede volver a "ABIERTO"]

### Reglas de negocio aplicadas

| Regla | Paso o flujo donde aplica |
|-------|---------------------------|
| RN-### | Paso # / CU-001.FE-01 |

### Postcondiciones

- **Éxito:** [qué queda cierto al cumplirse el objetivo]
- **Fallo:** [estado en que queda si el objetivo no se cumple]

### Dependencias y fuera de alcance

- **Depende de:** CU-### / Ninguna
- **No cubre:** [lo que este caso de uso no incluye; citar EXC-### si aplica]

<!-- Repetir el bloque "## CU-NNN" por cada caso de uso (un objetivo = un caso de uso). -->

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
