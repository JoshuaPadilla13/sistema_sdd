---
name: rq-03-minuta-discovery
description: Genera el documento RQ-03 Minuta de sesión de Discovery de una sesión (S1, S2…) usando templates/RQ-03_minuta-discovery.md, y administra la lista única de pendientes PEN del proyecto. Úsalo después del cuestionario de cada sesión, y cada vez que se resuelva o detecte un pendiente.
---

# Skill — RQ-03 Minuta de sesión de Discovery

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
- Transcripción de la sesión S#, RQ-01 y RQ-02 de esa sesión.
- Plantilla `templates/RQ-03_minuta-discovery.md`.

## Procedimiento por sección

**Datos de la sesión**
- Hora: las transcripciones de Teams traen dos horas: la del nombre técnico del archivo
  (`AAAAMMDD_HHMMSS`, hora local) y una línea de texto (suele venir en UTC, +6 h respecto
  a México). Usa **siempre la del nombre técnico**. Si solo tienes la línea de texto,
  réstale el desfase y márcala `[Inferido]`.
- Dato que no aparezca: `⚠️ POR CONFIRMAR (PEN-###)`.

**Objetivo:** 1–2 frases. Si no se declaró, redáctalo y márcalo `[Inferido]`.

**Participantes:** solo quienes tuvieron un rol o aporte relevante. Omite a quienes solo
asistieron o solo manejaron la reunión (iniciar la transcripción, dar la palabra). No
dejes filas con rol desconocido: omítelas.

**Temas tratados:** en el orden en que ocurrieron, con minuto. Solo temas realmente
discutidos.

**Decisiones (`DEC-###`):** solo resoluciones firmes y atribuibles, con quién y minuto.
Una propuesta o un "creo que…" no es decisión: va a suposiciones.

**Suposiciones (`SUP-###`):** lo que se asumió sin confirmar, con certeza y riesgo.

**Pendientes (`PEN-###`):** esta tabla es la **única** lista de pendientes del proyecto.
Registra aquí:
- los 🟡 y ❌ del checklist RQ-01 que no se cerraron;
- los `⚠️ POR CONFIRMAR` del cuestionario RQ-02;
- los pendientes abiertos en la conversación.

Si un pendiente se detecta **después**, al elaborar RQ-04 a RQ-08, regístralo en la minuta
de la sesión más reciente con `Origen: RQ-0N`. Responsable y fecha solo si se dijeron; si
no, `Sin asignar`.

## Cierre de pendientes
Cuando el usuario resuelve un `PEN`: elimina su fila, registra el cierre en el historial
y recalcula el estado (`sdd-convenciones` §7). Si no quedan abiertos, escribe "Sin
pendientes abiertos." y el documento pasa a `Pending Validation`.

## ¿Se necesita otra sesión?
Al terminar, reporta cuántos `PEN` **Críticos** siguen abiertos. Si hay al menos uno,
recomienda una sesión S(n+1) y entrega la lista de preguntas ordenadas por impacto.

## Checklist final
Hora del nombre técnico · solo participantes relevantes · decisiones firmes con autor y
minuto · cada `⚠️` de cualquier documento tiene su fila `PEN` · prioridad en cada `PEN` ·
nombre `<COD>_RQ-03_minuta-discovery-S#.md` · encabezado e historial completos.
