# Reglas de negocio

| Campo | Valor |
|-------|-------|
| Documento | RQ-06 · Reglas de negocio |
| Proyecto | [Nombre del proyecto] · [COD] |
| Versión | 0.1 |
| Estado | Draft |
| Fecha | AAAA-MM-DD |
| Elaboró | sdd-01-requerimientos |
| Validó | — |
| Fuentes | [COD]_RQ-02 vX; [COD]_RQ-03 S# vX; [COD]_RQ-05 vX |

## Catálogo de reglas

| ID | Regla de negocio | Tipo | Origen | Aplica a | Notas |
|----|------------------|------|--------|----------|-------|
| RN-001 | | Validación / Cálculo / Autorización / Flujo / Restricción | RQ-02 P## · RQ-03 S# mm:ss | HU-### | |

---

## Historial de cambios

| Versión | Fecha | Cambio | Autor |
|---------|-------|--------|-------|
| 0.1 | AAAA-MM-DD | Creación | |
