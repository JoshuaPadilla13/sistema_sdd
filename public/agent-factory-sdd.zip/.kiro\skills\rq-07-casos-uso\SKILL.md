---
name: rq-07-casos-uso
description: Genera el documento RQ-07 Casos de uso (CU-###) a nivel funcional (QUÉ, no CÓMO) usando templates/RQ-07_casos-uso.md, a partir de historias de usuario y reglas de negocio. Úsalo cuando se pidan casos de uso, flujos, excepciones o estados del sistema.
---

# Skill — RQ-07 Casos de uso

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).

## Insumos
RQ-04 (actores, alcance), RQ-05 (historias), RQ-06 (reglas) y RQ-02 Parte 5 (B, C, F).
Plantilla `templates/RQ-07_casos-uso.md`.

## Regla de oro: QUÉ, no CÓMO
Describe actores, eventos, acciones, respuestas, condiciones y estados funcionales.
Nada de código, APIs, endpoints, bases de datos, arquitectura ni infraestructura (salvo que
sea una restricción funcional declarada en un `NF`).

## Procedimiento
1. **Un objetivo del actor = un caso de uso.** Agrupa las `HU` que persiguen el mismo
   objetivo. Toda `HU` debe quedar en al menos un `CU`.
2. **Objetivo:** "El actor necesita conseguir X mediante Y para obtener Z".
3. **Disparador y precondiciones:** observables, sin infraestructura.
4. **Flujo principal:** pasos numerados que alternan actor y sistema; máximo ~10 pasos.
5. **Flujos alternos (`FA`):** caminos válidos distintos al principal, no errores.
6. **Flujos de excepción (`FE`):** condición, respuesta concreta, estado final, si el actor
   puede corregir y si termina o continúa. Prohibido "el sistema manejará el error".
7. **Casos límite:** revisa cada uno y cúbrelo con un `FA` o `FE`, o genera un `PEN`. No van
   en una tabla aparte:
   dato inexistente · duplicado · incompleto o inválido · operación repetida · cancelación ·
   estado que no permite la acción · múltiples resultados · sin autorización.
8. **Estados y transiciones:** si el comportamiento depende de estados, defínelos aquí
   (este documento es su dueño). Nómbralos en MAYÚSCULAS. Indica las transiciones no
   permitidas.
9. **Reglas aplicadas:** cita el `RN` y el paso o flujo donde aplica; no la reescribas.
10. Si dos fuentes se contradicen, no decidas: `⚠️ POR CONFIRMAR (PEN-###)`.

## Lo que NO va aquí
Criterios EARS ni referencias a `REQ`/`CA` (RQ-08 viene después y es el que cita a RQ-07) ·
textos exactos de mensajes (RQ-08) · tablas de "preguntas pendientes" (los `PEN` viven en
RQ-03) · trazabilidad repetida (las `HU` se citan una sola vez, en Identificación).

## Checklist final
Objetivo real del actor · disparador claro · flujo principal completo · cada caso límite
cubierto por un `FA`/`FE` o con `PEN` · excepciones con respuesta concreta · estados en
MAYÚSCULAS cuando aplique · cada `RN` citado existe · toda `HU` cubierta · se entiende sin
conocer la tecnología · encabezado e historial completos.
