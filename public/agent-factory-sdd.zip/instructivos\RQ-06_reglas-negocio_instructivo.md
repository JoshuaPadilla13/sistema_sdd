# Instructivo — RQ-06 Reglas de negocio

> Guía para llenar `templates/RQ-06_reglas-negocio.md`: qué va en cada columna, de dónde
> sale la información y qué hace que una regla esté bien escrita.
>
> **Quién la llena:** el agente `sdd-01-requerimientos` genera el borrador y el
> **PM / Analista** valida que refleje el dominio.
> **Convenciones comunes** (IDs, marcadores, estados): `.kiro/steering/sdd-convenciones.md`.

---

## 1. ¿Qué es una regla de negocio (y qué NO lo es)?

Una **regla de negocio** es una restricción, cálculo o condición del **dominio** que el
sistema debe respetar siempre, sin importar la pantalla o la tecnología.

- ✅ **Sí es regla:** "No se permite registrar dos clientes con el mismo RFC", "El descuento
  máximo es 20 %", "Solo el gerente puede aprobar una factura".
- ❌ **No es regla:** "El botón Guardar es azul" (es UI, fase 02) · "La consulta debe responder
  en menos de 2 s" (es un límite no funcional `NF`, va en RQ-04) · "Usamos Oracle" (es
  decisión técnica, fase 02) · "Mostrar el mensaje 'RFC duplicado'" (es un mensaje, va en
  RQ-08).

> Regla de oro: una regla de negocio se puede enunciar **sin hablar de pantallas ni de
> código**, y sigue siendo cierta aunque cambie la tecnología.

---

## 2. Insumos

- **RQ-02 Cuestionario:** sobre todo la Parte 7 (Reglas del negocio), la Parte 5 D de cada
  tarea, la Parte 6 (datos) y la Parte 4 (quién puede hacer qué).
- **RQ-03 Minutas** de las sesiones.
- **RQ-05 Historias de usuario**, para saber a qué historias aplica cada regla.

> Frases que suelen esconder una regla: **"no se puede…", "siempre…", "solo si…",
> "máximo/mínimo…", "solo el [rol] puede…", "antes de… hay que…", "se calcula como…"**.

---

## 3. Columna por columna

| ID | Regla de negocio | Tipo | Origen | Aplica a | Notas |
|----|------------------|------|--------|----------|-------|

### `ID`
`RN-001`, `RN-002`… consecutivo. Si una regla se elimina, su ID queda retirado y no se
reasigna. Es el ID que después citan Casos de uso, Criterios EARS, Diseño y Pruebas.

### `Regla de negocio`
Verificable: se debe poder responder "se cumple / no se cumple".
- ✅ "Un cliente no puede registrarse con un RFC ya existente."
- ❌ "Validar bien el RFC." (vago: ¿validar qué?)
- Con su **valor concreto**: "El descuento máximo permitido es 20 %", no "el descuento tiene
  un tope".
- **Una idea por fila.** Si la frase tiene "y / además / también", sepárala.
- Si el valor no está confirmado:
  "El pedido admite máximo ⚠️ POR CONFIRMAR (PEN-007): número máximo de productos".

### `Tipo`
Uno de los 5 tipos de la sección 4.

### `Origen` (obligatorio)
Dónde se dijo: `RQ-02 P24` (pregunta 24 del cuestionario) o `RQ-03 S1 12:40` (sesión 1,
minuto 12:40). Si no se puede rastrear, no es un hecho: márcala `[Inferido]` o `[Propuesto]`.

### `Aplica a`
Las historias donde aplica: `HU-003, HU-004`.

### `Notas`
Excepciones o contexto del dominio: "Aplica solo a clientes tipo Empresa", "El cálculo
redondea a 2 decimales". **No** pongas aquí mensajes para el usuario (van en RQ-08).

---

## 4. Los 5 tipos de regla

| Tipo | Qué es | Pistas en el texto | Ejemplo |
|------|--------|--------------------|---------|
| **Validación** | Condiciones que deben cumplir los datos | "no se permite", "debe ser", "no puede estar vacío", "formato" | "El correo debe tener formato válido." |
| **Cálculo** | Fórmulas o derivaciones | "se calcula", "porcentaje", "IVA", "total", "redondeo" | "El IVA es 16 % sobre el subtotal." |
| **Autorización** | Quién puede hacer qué | "solo el [rol]", "requiere permiso de", "únicamente el admin" | "Solo el gerente puede eliminar registros." |
| **Flujo** | Orden o condiciones de un proceso | "antes de", "no se puede … hasta que", "primero … luego" | "No se factura sin aprobación previa del gerente." |
| **Restricción** | Límites del dominio | "máximo", "mínimo", "hasta", "no más de" | "Máximo 50 productos por pedido." |

> Si una frase tiene dos tipos, divídela: "solo el gerente aprueba montos mayores a $10,000"
> = una regla de **Autorización** (quién) + una de **Restricción** (el umbral).

---

## 5. ¿Y la trazabilidad hacia Diseño y Pruebas?

**No se escribe en este documento.** Los documentos de la fase 02 (Diseño) y de la fase 05
(Test Cases) **citan** el `RN-###` que implementan o prueban. Así cada documento contiene
solo lo suyo y la trazabilidad se arma siguiendo los IDs.

---

## 6. Ejemplo bien llenado

| ID | Regla de negocio | Tipo | Origen | Aplica a | Notas |
|----|------------------|------|--------|----------|-------|
| RN-001 | Un cliente no puede registrarse con un RFC ya existente. | Validación | RQ-02 P18 | HU-001 | |
| RN-002 | El descuento máximo permitido en un pedido es 20 %. | Restricción | RQ-03 S1 18:05 | HU-004 | Se aplica sobre el subtotal, antes de IVA. |
| RN-003 | El IVA se calcula como 16 % del subtotal. | Cálculo | RQ-02 P22 | HU-004 | Redondeo a 2 decimales. |
| RN-004 | Solo un usuario con rol Gerente puede eliminar un cliente. | Autorización | RQ-02 P15 | HU-002 | |
| RN-005 | No se puede facturar un pedido que no esté aprobado. | Flujo | RQ-03 S2 07:30 | HU-005 | La aprobación la hace el Gerente. |

---

## 7. Errores comunes

- ❌ Mezclar **límites no funcionales** (rendimiento, seguridad técnica) con reglas: van en
  RQ-04 como `NF`.
- ❌ Describir la **UI** o el **mensaje** en vez de la regla.
- ❌ Escribir **dónde se implementa** (Service, DTO, endpoint): es de la fase 02.
- ❌ Reglas **duplicadas** con distinto ID.
- ❌ Reglas **sin origen**.
- ❌ Varias reglas **apiladas** en una fila.
- ❌ Valores vagos ("un tope razonable") en vez de `⚠️ POR CONFIRMAR (PEN-###)`.

---

## 8. Checklist final

- [ ] Cada regla tiene ID único `RN-###`.
- [ ] Cada regla es verificable y atómica.
- [ ] Cada regla tiene tipo (uno de los 5) y origen, o está marcada `[Inferido]` / `[Propuesto]`.
- [ ] Los valores están puestos o con `⚠️ POR CONFIRMAR (PEN-###)`.
- [ ] No hay mensajes, UI, no funcionales ni implementación.
- [ ] No hay reglas duplicadas.
- [ ] El PM / Analista validó que las reglas reflejan el dominio real.
