# Instructivo — RQ-08 Criterios de aceptación EARS

| | |
|---|---|
| **Propósito** | Explicar a cualquier persona del equipo cómo se llena `templates/RQ-08_criterios-aceptacion-ears.md` |
| **Formato obligatorio** | EARS (Easy Approach to Requirements Syntax) en español |
| **Fase** | 01 Requerimientos — último documento de la fase |
| **Convenciones comunes** | `.kiro/steering/sdd-convenciones.md` |

> **Objetivo:** que los criterios sean correctos y verificables, para que de ellos salgan el
> Diseño (fase 02), las Tareas (fase 03) y los Test Cases (fase 05) sin ambigüedad.

---

## 1. Qué es EARS

EARS es una forma de escribir requisitos en lenguaje natural pero con plantillas fijas y
palabras clave que eliminan la ambigüedad. Es el formato que propone Kiro para SDD; por
consistencia, el equipo lo usa en **toda** la fase 01. Gherkin (Dado/Cuando/Entonces) no se
usa en Requerimientos: se reserva para los Test Cases de la fase 05.

---

## 2. Reglas que nunca se rompen

1. Todo criterio termina en **"el sistema DEBERÁ [acción observable]"**.
2. Un criterio = una sola regla verificable. Nada de "guardar y notificar" juntos.
3. Nunca "debería", "podría", "rápido", "fácil", "correctamente". Usa valores exactos.
4. Describe **comportamiento**, no implementación (nada de endpoints, tablas, librerías, cron).
5. Mensajes de error o confirmación **entre comillas y con el texto exacto**. RQ-08 es el
   único documento que redacta mensajes.
6. El sujeto siempre es **"el sistema"**; el actor va dentro del evento ("CUANDO el
   administrador…").

---

## 3. Los 5 patrones

| Si la situación es… | Patrón | Forma |
|---------------------|--------|-------|
| Pasa siempre, sin condición | Ubicuo | El sistema DEBERÁ [respuesta]. |
| La dispara un evento o acción | Evento | CUANDO [evento], el sistema DEBERÁ [respuesta]. |
| Depende de un estado continuo | Estado | MIENTRAS [estado], el sistema DEBERÁ [respuesta]. |
| Es validación, error o caso límite | No deseado | SI [condición], ENTONCES el sistema DEBERÁ [respuesta]. |
| Solo existe si una opción está activa | Opcional | DONDE [opción habilitada], el sistema DEBERÁ [respuesta]. |

---

## 4. De dónde sale cada criterio

RQ-08 no inventa comportamiento: lo **formaliza** a partir de los documentos anteriores.

| Insumo | Se convierte en |
|--------|-----------------|
| Flujo principal de un `CU` (RQ-07) | Criterios CUANDO (camino feliz) |
| Cada flujo de excepción `FE` (RQ-07) | Un criterio SI…ENTONCES |
| `RN` de Validación o Restricción (RQ-06) | Un criterio SI…ENTONCES |
| `RN` de Autorización (RQ-06) | Un criterio de permisos |
| Estados y transiciones del `CU` (RQ-07) | Criterios MIENTRAS, con el estado en MAYÚSCULAS y entre comillas |
| `NF` verificable (RQ-04) | Un `REQ` no funcional con valor medible |

---

## 5. Cómo llenar cada requerimiento

### 5.1 Encabezado del requerimiento
`## REQ-001 — Título corto` (3 a 6 palabras), por ejemplo "Acceso a la maquinita".

### 5.2 Origen
Solo IDs, **sin reescribir** la historia ni el caso de uso:
`**Origen:** HU-003 · CU-002 · RN-007, RN-008`

### 5.3 Criterios
Tabla con `REQ-001.CA-01`, `REQ-001.CA-02`… Cobertura mínima por requerimiento:
1. Al menos **1 camino feliz** (CUANDO).
2. Un criterio de **error por cada validación** relevante (SI…ENTONCES).
3. Criterios de **permisos** si la función no es pública.

### 5.4 Validaciones de entrada (por cada campo que captura el usuario)

| Caso | Forma |
|------|-------|
| Vacío / obligatorio | SI [campo] está vacío, ENTONCES el sistema DEBERÁ mostrar "[campo] es obligatorio". |
| Formato | SI [campo] tiene formato inválido, ENTONCES el sistema DEBERÁ mostrar "[mensaje]". |
| Longitud / rango | SI [campo] está fuera de [rango], ENTONCES el sistema DEBERÁ mostrar "[mensaje]". |
| Duplicado | SI [registro] ya existe, ENTONCES el sistema DEBERÁ mostrar "[mensaje]". |

### 5.5 Lo que falta
Si un valor o mensaje no está confirmado: `⚠️ POR CONFIRMAR (PEN-###): <qué falta>`. Si el
agente sugiere el texto: márcalo `[Propuesto]`.

---

## 6. Anti-patrones

| Si detectas… | Corrige a… |
|--------------|-----------|
| "…DEBERÁ guardar y notificar" (dos reglas) | Dos criterios separados |
| "El colaborador DEBERÁ…" (actor como sujeto) | "CUANDO el colaborador…, el sistema DEBERÁ…" |
| "SI el juego está cerrado…" (sin respuesta) | Agrega "ENTONCES el sistema DEBERÁ…" |
| "…mostrar un error" (genérico) | Mensaje exacto entre comillas |
| "…usando un trigger de BD" (implementación) | Comportamiento observable |
| "el sistema debería…" | "el sistema DEBERÁ…" |

---

## 7. Ejemplo bien llenado

## REQ-001 — Acceso a la maquinita

**Origen:** HU-003 · CU-002 · RN-007, RN-008

| ID | Criterio |
|----|----------|
| REQ-001.CA-01 | CUANDO el colaborador ingresa número de empleado y fecha de nacimiento correctos, el sistema DEBERÁ redirigirlo a la pantalla de la maquinita. |
| REQ-001.CA-02 | SI el número de empleado no está en la base de check-in, ENTONCES el sistema DEBERÁ mostrar "No estás registrado para participar en esta rifa". |
| REQ-001.CA-03 | SI la fecha de nacimiento no coincide con el número de empleado, ENTONCES el sistema DEBERÁ mostrar "Los datos ingresados no son correctos". |
| REQ-001.CA-04 | MIENTRAS el juego está "CERRADO", el sistema DEBERÁ mostrar la pantalla "El juego ya no está disponible". |
| REQ-001.CA-05 | El sistema DEBERÁ registrar fecha y hora de cada intento de acceso. |

---

## 8. Checklist final

**Por cada criterio**
- [ ] Usa un patrón EARS correcto y termina en "el sistema DEBERÁ…".
- [ ] Es una sola regla verificable.
- [ ] Sin palabras vagas; con valores y mensajes exactos.
- [ ] No describe implementación.

**Por cada requerimiento**
- [ ] Cita su origen solo con IDs.
- [ ] Cubre camino feliz, cada excepción del caso de uso y cada validación.
- [ ] Cubre permisos si aplica.
- [ ] No contradice RQ-04 a RQ-07.

**Del documento**
- [ ] Cada `NF` verificable de RQ-04 tiene su `REQ`.
- [ ] No hay Gherkin.

---

## 9. ¿Cómo se aplica esto automáticamente?

- El agente `sdd-01-requerimientos` carga la skill `rq-08-criterios-aceptacion-ears` y el
  steering `sdd-convenciones` mediante su campo `resources`.
- Fuera del agente, el steering `sdd-convenciones` (`inclusion: always`) hace que Kiro use
  EARS en español también en el chat normal y en sus specs nativas.
