# AGENT FACTORY — Fase 01 Requerimientos (SDD)

## Estructura

```text
.kiro/
  steering/sdd-convenciones.md          ← reglas comunes (fuente única)
  agents/sdd-01-requerimientos.md       ← agente de la fase
  skills/rq-01 … rq-08, rq-revision-consistencia
templates/RQ-01 … RQ-08                 ← solo estructura, sin instrucciones
instructivos/                           ← guías para personas
documentacion/                          ← estado de la fase y documentos generados
transcripciones discovery/              ← insumos
```

Los documentos de cada proyecto se guardan en `docs/01-requerimientos/` con el nombre
`<COD>_RQ-NN_<nombre>.md` (por ejemplo, `MJG_RQ-05_historias-usuario.md`).

## Cambios respecto a la versión anterior

| Antes | Ahora |
|-------|-------|
| Historia de usuario con Gherkin, reglas, UI y API | Solo actor, Como/Quiero/Para, prioridad, dependencias y a qué objetivo o alcance contribuye |
| Criterios EARS reescribían la historia e incluían introducción y glosario | Solo citan `HU` / `CU` / `RN`; el glosario vive en RQ-04 y los estados en RQ-07 |
| Reglas de negocio con trazabilidad a Service/DTO y mensajes en notas | Solo la regla; Diseño y Pruebas citan el `RN` |
| Caso de uso citaba las historias 3 veces, criterios hacia adelante y pendientes propios | Cita una vez, solo hacia atrás; casos límite cubiertos por flujos; pendientes en la minuta |
| Pendientes en checklist, acta y cuestionario | Solo en la minuta RQ-03 (`PEN-###`) |
| 7 marcadores de información faltante | Uno solo: `⚠️ POR CONFIRMAR (PEN-###): …` + `[Inferido]`, `[Propuesto]`, `N/A` |
| IDs `US-`, `HU-`, `ID-US-`, `CA-`, `Req-` | Un solo esquema `PREFIJO-NNN` (ver steering §3) |
| Nombres de archivo y skills sin patrón | `RQ-NN_<nombre>` en plantillas y `rq-NN-<nombre>` en skills |
| La skill del acta prohibía indicar el estado | Todo documento lleva encabezado, estado e historial; el estado cambia al cerrar pendientes |
| Regla de evidencia copiada en el agente y en cada skill | Una sola vez, en el steering |
| El agente no declaraba `resources` | Carga el steering y las 9 skills por `resources` |
| Sin control de calidad final | Skill `rq-revision-consistencia` |
| Documento base con instrucciones de IA dentro de la plantilla | Plantilla limpia; las instrucciones viven en la skill |
| Cuestionario con tabla de uso interno | El mapa interno vive en la skill `rq-02` |

## Cómo usar el agente

`sdd-01-requerimientos` está definido como **subagente** (en `.kiro/agents/`). Esto
significa que **no aparece en el selector de la barra de chat ni se activa con `@`**: lo
invoca por ti el agente principal con el que estás chateando.

Para usarlo, escríbele al chat un prompt que **le pida explícitamente invocar al
subagente** `sdd-01-requerimientos` (ver el prompt de abajo). La línea clave es
"Invoca al subagente sdd-01-requerimientos…"; con eso el agente principal delega en él
en lugar de activar solo una skill suelta.

> Si solo ves "Activated Skill rq-02…" y nunca "invocando agente", es señal de que **no**
> se delegó al subagente: faltó la instrucción de invocarlo. Agrega esa línea y reintenta.

**Sobre la transcripción:** el subagente solo lee texto (`tools: ["read", "write"]`), así
que trabaja con un archivo **`.txt`** guardado en `transcripciones discovery/txt/`. La
conversión de `.docx` a `.txt` es un **paso previo**: lo puedes hacer tú, o pedírselo al
agente principal en el mismo prompt (él sí puede convertir y guardar el `.txt` en esa
carpeta antes de invocar al subagente). El subagente nunca abre el `.docx`.
Se detiene si no hay transcripción y pregunta el código de proyecto si no lo das.

Tiene tres modos:

- **Modo 1 — Después de cada sesión (S1, S2…):** genera RQ-01, RQ-02 y RQ-03 de la
  sesión y reporta los pendientes críticos. Si quedan críticos, recomienda otra sesión.
- **Modo 2 — Documentación (sin pendientes críticos):** genera RQ-04 a RQ-08 y la
  revisión de consistencia.
- **Modo 3 — Resolución de pendientes:** cierra los `PEN` que respondas y propaga el
  cierre a todos los documentos, subiendo versiones y recalculando estados.

### Prompt universal

```text
Invoca al subagente sdd-01-requerimientos (fase 01 Requerimientos, metodología SDD)
para esta tarea.

Contexto del proyecto:
- Código de proyecto: <3–5 letras que YO asigno para nombrar los archivos, p.ej. ESR>
- Nombre del proyecto: <nombre legible>
- Sesión de Discovery: <S1 / S2 / ...>
- Transcripción a usar: #<archivo de la sesión>
- Salida esperada en: documentacion/01-requerimientos

Si la transcripción está en .docx, primero conviértela a .txt y guárdala en
"transcripciones discovery/txt/"; el subagente trabaja sobre ese .txt.

Lo que necesito en esta corrida:
<elige UNA>
- MODO 1 (después de una sesión): genera RQ-01 Checklist, RQ-02 Cuestionario
  (crea en S1, actualiza en S2+), RQ-03 Minuta con decisiones, suposiciones y
  pendientes PEN; cierra con el reporte de PEN críticos y el siguiente paso.
- MODO 2 (documentación, sin PEN críticos abiertos): genera en orden
  RQ-04 → RQ-05 → RQ-06 → RQ-07 → RQ-08 y termina con la revisión de consistencia.
- MODO 3 (resolver pendientes): te respondo los siguientes PEN: <lista PEN-### + respuesta>.
  Actualiza todos los documentos afectados, cierra los PEN en la minuta y recalcula
  versiones y estados.

Reglas:
- Respeta sdd-convenciones (orden de documentos, IDs, nombres de archivo, marcadores,
  encabezado/historial y estados). La fase 01 describe el QUÉ, nunca el CÓMO.
- No inventes datos: usa [Inferido], [Propuesto] o ⚠️ POR CONFIRMAR (PEN-###) según corresponda.
- Si falta la transcripción o el código de proyecto, pídemelo y detente.
- Al terminar: lista los archivos creados/actualizados con versión y estado, los PEN
  abiertos (marca los críticos) y el siguiente paso recomendado.
```

### Ejemplo de primera sesión (Modo 1)

```text
Invoca al subagente sdd-01-requerimientos.
Código de proyecto: ESR
Nombre: Programa ESR
Sesión: S1
Transcripción: #Contexto General – Programa ESR.txt   (en transcripciones discovery/txt/)
Salida en: documentacion/
MODO 1: genera RQ-01, RQ-02 y RQ-03 de S1 y dame el reporte de PEN críticos.
```

> El código de proyecto (ESR, MJG, …) lo asignas tú: es una etiqueta de 3–5 letras que
> se usa como prefijo de todos los archivos del proyecto. Si no lo das, el agente lo pide.
