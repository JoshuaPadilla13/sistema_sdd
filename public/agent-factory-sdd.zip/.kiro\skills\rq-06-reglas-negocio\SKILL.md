---
name: rq-06-reglas-negocio
description: Genera el documento RQ-06 Reglas de negocio (RN-###, tipos Validación, Cálculo, Autorización, Flujo y Restricción) usando templates/RQ-06_reglas-negocio.md, a partir del cuestionario, las minutas y las historias de usuario. Úsalo cuando se pida el catálogo de reglas de negocio.
---

# Skill — RQ-06 Reglas de negocio

Aplica las convenciones de `sdd-convenciones` (IDs, marcadores, encabezado, estados).
Guía extendida para personas: `instructivos/RQ-06_reglas-negocio_instructivo.md`.

## Insumos
RQ-02 (Partes 4, 5 D, 6 y 7), minutas RQ-03, RQ-04 y RQ-05.
Plantilla `templates/RQ-06_reglas-negocio.md`.

## Qué es una regla de negocio
Una restricción, cálculo o condición **del dominio** que el sistema respeta siempre,
enunciable sin hablar de pantallas ni de código. Frases que suelen esconder una:
"no se puede…", "siempre…", "solo si…", "máximo/mínimo…", "solo el [rol] puede…",
"antes de… hay que…", "se calcula como…".

| Tipo | Qué es | Ejemplo |
|------|--------|---------|
| Validación | Condición que deben cumplir los datos | "No se permiten dos clientes con el mismo RFC." |
| Cálculo | Fórmula o derivación | "El IVA es 16 % del subtotal." |
| Autorización | Quién puede hacer qué | "Solo el gerente puede eliminar un cliente." |
| Flujo | Orden o condición de un proceso | "No se factura un pedido sin aprobación." |
| Restricción | Límite del dominio | "Máximo 50 productos por pedido." |

Si una frase mezcla dos tipos ("solo el gerente aprueba montos mayores a $10,000"),
sepárala en dos reglas (Autorización + Restricción).

## Columnas
- **Regla:** verificable (se cumple / no se cumple), atómica, con el valor concreto o
  `⚠️ POR CONFIRMAR (PEN-###)`.
- **Origen (obligatorio):** `RQ-02 P##` o `RQ-03 S# mm:ss`. Si no se puede rastrear, es
  `[Inferido]` o `[Propuesto]`: márcalo así.
- **Aplica a:** las `HU` donde aplica.
- **Notas:** excepciones o contexto del dominio.

## Lo que NO va aquí (y a dónde va)

| No escribir | Va en |
|-------------|-------|
| Mensajes que ve el usuario | RQ-08 |
| Detalles de UI | Fase 02 |
| Rendimiento, seguridad técnica, disponibilidad | RQ-04 (`NF`) |
| Service, DTO, endpoint o caso de prueba donde se implementa | Fases 02 y 05 (ellas citan el `RN`) |

## Checklist final
ID único · verificable · atómica · un tipo · origen rastreable o marcada · sin
duplicados · sin mensajes, UI ni implementación · encabezado e historial completos.
